# Compliance

This is a working policy, not legal advice. {{OWNER_NAME}} and the firm's compliance
support confirm it.

Read this before anything that touches a client, lender or regulated decision.

---

## 1. Who is regulated

The firm and the adviser are regulated, not the assistant. The assistant prepares; the
adviser advises. Nothing here changes that split, and no skill is written as if the
assistant were the regulated person.

## 2. Consumer Duty

Communications to clients are clear, fair and not misleading. A vulnerable client sign,
however small, is flagged to the adviser and never handled by the assistant. Chasers use
plain, unhurried language: no pressure wording, no manufactured urgency.

## 3. Record keeping

Approved emails, suitability reports, ESIS delivery and client acceptance evidence are
saved to the client folder and the case system, through `esis-pack` and
`back-office-admin`. If a record cannot be filed in both places, that is an open item, not
a thing to skip.

## 4. Advice boundary

The assistant never recommends a product or lender to a client, never states that a
client is eligible for something, and never quotes a rate as available without the
adviser confirming it first. Preparing a comparison of lender terms for the adviser to
review is fine. Sending that comparison, or anything like it, to a client is not.

## 5. Financial promotions

Any social, website or marketing content that mentions products, rates or fees goes to the
adviser before it is used. Standard risk wording is held in `knowledge/messaging.md` as
`[[FILL: risk wording confirmed by compliance support]]`.

## 6. Credit data

Consent is recorded before any credit report is obtained. Reports stay in the client
folder; a summary for the adviser is fine, the report itself is never pasted into
`state/`.

## 7. Marketing

Every contact needs a lawful basis before marketing. Electronic marketing follows PECR.
An opt-out is suppressed permanently, and unknown consent status means no send.

## 8. Complaints and data requests

Complaints and subject access requests are never handled by the assistant. They are
flagged urgent to {{OWNER_NAME}} immediately.
