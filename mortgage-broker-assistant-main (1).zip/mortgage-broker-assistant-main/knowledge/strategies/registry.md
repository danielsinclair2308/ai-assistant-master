# Strategies registry

The map from product mix to product pack, and what each pack is aiming at. Read this
after onboarding, alongside `state/enabled-packs.md`, to decide which packs under
`.claude/packs/` to load. Unused packs stay in the repo and stay unloaded.

**The second goal for every pack, not repeated in the table below, is adviser hours
saved.** North star is the headline; hours saved is tracked alongside it for all of them.

| Pack | Enable when | North star | Skills most used |
|---|---|---|---|
| `residential` | Firm advises first-time buyers, home movers or residential remortgage | Cases completed per month | `esis-pack`, `client-documents`, `case-tracking` |
| `btl` | Firm advises buy-to-let, portfolio landlords or limited company purchases | Cases completed per month | `lender-requirements`, `client-documents`, `case-tracking` |
| `bridging` | Firm advises bridging finance | Days from enquiry to offer | `lender-requirements`, `case-tracking`, `client-documents` |
| `commercial` | Firm advises commercial mortgages | Cases completed per month | `lender-requirements`, `client-documents`, `case-tracking` |
| `development` | Firm advises development finance | Days from enquiry to offer | `lender-requirements`, `case-tracking`, `back-office-admin` |
