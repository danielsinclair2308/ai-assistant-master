# Business

Written by a human, once at onboarding, and kept current by hand afterwards. If a value
here still reads `[[FILL]]`, that fact does not exist yet: say so and ask rather than
guessing.

## Firm

- Firm name: `[[FILL]]`
- Trading name, if different: `[[FILL]]`
- FCA firm reference number: `[[FILL]]`
- Network or directly authorised: `[[FILL: network name, or "directly authorised"]]`
- Enquiries email address, the one `move-to-email` invites people to use: `[[FILL]]`

## People

| Name | Role | Adviser qualifications |
|---|---|---|
| `[[FILL]]` | {{OWNER_NAME}}, adviser | `[[FILL: e.g. CeMAP]]` |
| `[[FILL]]` | {{OPERATOR_NAME}}, case administrator | `[[FILL]]` |
| `[[FILL]]` | `[[FILL]]` | `[[FILL]]` |

## Product mix

Which product areas this firm actually advises on. Only enable a pack in
`state/enabled-packs.md` for a product mix that appears here.

- `[[FILL: e.g. residential, buy-to-let, bridging, commercial, development]]`

## Lead sources

Where new enquiries come from, in order of volume.

- `[[FILL]]`
- `[[FILL]]`
- `[[FILL]]`
