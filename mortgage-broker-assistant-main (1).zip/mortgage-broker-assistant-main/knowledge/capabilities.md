# Capabilities

What a skill can need. Each skill lists these in `needs` (will not run without) and
`better-with` (runs, but with gaps). Onboarding maps each capability to a real tool and
records it in `state/connections.md`. Nothing here names a product.

| Capability | Meaning | Typical ways to connect |
|---|---|---|
| `case-system` | The CRM / back office holding clients and cases | MCP, API script, Zapier, browser |
| `email` | The adviser's mailbox: read, draft, send after approval | MCP (Outlook, Gmail) |
| `whatsapp` | WhatsApp Business messages to and from clients and the adviser | MCP, WhatsApp Business API |
| `sms` | Text messages | Zapier, provider API |
| `social` | Instagram, Facebook, LinkedIn, TikTok accounts, recorded per platform | Platform APIs, Zapier, browser |
| `client-folders` | The client folder root on this machine or a synced drive | Local path |
| `word-pdf` | Creating Word documents and converting to PDF | python-docx plus Word or LibreOffice |
| `bank-feed` | Read-only view of the business account to see payments | Open banking, accounting software |
| `calendar` | Reminders and tasks with dates | MCP (Outlook, Google Calendar) |
| `browser` | Driving websites with no connection, lender portals included | Browser tools |
| `credit-provider` | Obtaining a client's credit report with their consent | Provider API or portal |
| `video-tools` | Editing short-form video and adding captions | Editing tool API or local tools |
| `speech-to-text` | Turning voice notes into text | Transcription service |
| `marketing-email` | Sending campaigns with unsubscribe handling | Email marketing platform |
| `website` | Editing the website and landing pages | CMS or site repository |
