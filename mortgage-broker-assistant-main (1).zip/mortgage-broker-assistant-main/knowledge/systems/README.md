# Connected systems

One note per system connected at onboarding: how the connection actually works, day to
day, past the surface level of `state/connections.md`. Written by a human once the
connection is live, not guessed in advance.

For each system, cover:

- How the connection works (MCP, API script, Zapier, browser)
- Field mapping quirks: anything that does not map cleanly onto the tracked fields in
  section 4 of the design spec
- Document categories the system uses, so uploads land in the right place
- Rate limits, so a script does not get throttled or blocked

This file has no entries yet. Onboarding adds a heading per system once it is connected.
