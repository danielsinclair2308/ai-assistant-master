<!--
One file per lender on the panel. Copy this template, rename it to the lender's own
file (e.g. `some-lender.md`), and fill it in. This file itself is never picked up by
scripts/index-knowledge.py: files starting with `_` or containing `.template.` are
skipped, so the index only ever lists real lenders.
-->

# `[[FILL: lender name]]`

| Products | Submission route | Notes |
|---|---|---|
| `[[FILL]]` | `[[FILL]]` | `[[FILL]]` |

## Contacts

Roles only. Never a personal mobile number here.

| Role | Contact | Notes |
|---|---|---|
| `[[FILL: e.g. BDM]]` | `[[FILL: work email or office line]]` | `[[FILL]]` |
| `[[FILL: e.g. underwriting desk]]` | `[[FILL]]` | `[[FILL]]` |

## Portal notes

`[[FILL: quirks of the submission portal, login arrangement, upload limits]]`

## Criteria notes

Dated and sourced. Never presented as current without checking: criteria are always
fetched fresh at the point of use, this is only a memory aid for what has been seen or
told before.

| Date | Note | Source |
|---|---|---|
| `[[FILL: YYYY-MM-DD]]` | `[[FILL]]` | `[[FILL: who said it, or where it was read]]` |

## Case history summary

Counts only. Never a client name, reference to an individual's circumstances, or credit
detail.

| Period | Cases submitted | Cases completed | Notes |
|---|---|---|---|
| `[[FILL]]` | `[[FILL]]` | `[[FILL]]` | `[[FILL]]` |
