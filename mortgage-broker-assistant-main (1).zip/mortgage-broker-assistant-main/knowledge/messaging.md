# Messaging

The only source for anything the firm says about itself in public. **Social replies and
marketing copy draw only from this file.** If a claim is not here, it does not get made up
to fill a gap: it gets flagged instead.

## Introduction

`[[FILL: how the firm introduces itself in one or two sentences]]`

## Experience

`[[FILL: years trading, cases completed, notable specialisms in the adviser's own words]]`

## Credentials

`[[FILL: qualifications, FCA authorisation status, professional memberships]]`

## Specialisms

`[[FILL: e.g. first-time buyers, portfolio landlords, complex income, adverse credit]]`

## Fees

See `fees.md` for the actual figures. This section is only the line used publicly to
describe how fees work.

`[[FILL]]`

## Service principles

`[[FILL: how this firm says it works, e.g. response times, single point of contact]]`

## Contact link

`[[FILL: the one link used everywhere, e.g. booking page or contact form]]`

## Keywords

The words `lead-generation` and `social-engagement` search for, one line per area. Written
by humans; the assistant suggests additions monthly and adds only the exact words a named
human gives.

- Mortgages: `[[FILL]]`
- Bridging: `[[FILL]]`
- Buy-to-let: `[[FILL]]`
- Property investment: `[[FILL]]`
- Portfolio landlords: `[[FILL]]`
- Development: `[[FILL]]`
- Refinancing: `[[FILL]]`
- Commercial: `[[FILL]]`

## Standard risk wording

`[[FILL: the firm's standard mortgage risk warning, exactly as compliance requires it]]`

## Phrases never to use

`[[FILL: anything that has caused a complaint, a misunderstanding, or a compliance concern before]]`
