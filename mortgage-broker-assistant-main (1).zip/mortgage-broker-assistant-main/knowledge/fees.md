# Fees

Written by a human. The assistant never invents or adjusts a fee.

**The fee an invoice actually uses comes from the case's ESIS, not this file.** This table
exists only so the assistant can cross-check: if what the ESIS says does not match the
row below, that is flagged to {{OWNER_NAME}} or {{OPERATOR_NAME}} and never quietly
corrected either way. The ESIS wins, but a mismatch is still worth a human's attention.

| Product | Broker fee | When charged | Refundable? |
|---|---|---|---|
| Residential | `[[FILL]]` | `[[FILL]]` | `[[FILL]]` |
| Buy-to-let | `[[FILL]]` | `[[FILL]]` | `[[FILL]]` |
| Commercial | `[[FILL]]` | `[[FILL]]` | `[[FILL]]` |
| Bridging | `[[FILL]]` | `[[FILL]]` | `[[FILL]]` |
| Development | `[[FILL]]` | `[[FILL]]` | `[[FILL]]` |
| Remortgage | `[[FILL]]` | `[[FILL]]` | `[[FILL]]` |
| Product transfer | `[[FILL]]` | `[[FILL]]` | `[[FILL]]` |

## Payment terms

When an invoice asks to be paid, for example "on receipt" or "within 14 days", as
{{OWNER_NAME}} states it. `invoicing` reads the terms from here and shows them in the fee
approval. There is no default: while this line is `[[FILL]]`, `invoicing` asks
{{OWNER_NAME}} for the terms on each invoice.

Payment terms: `[[FILL: e.g. within 14 days of the invoice date]]`
