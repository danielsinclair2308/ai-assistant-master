# Short-form video rules

Supplied by the broker. Nothing here until they give it: an empty section stays
`[[FILL]]` rather than being guessed from a generic playbook.

## Hooks

`[[FILL: supplied by the broker]]`

## Opening structure

`[[FILL: supplied by the broker]]`

## Pacing

`[[FILL: supplied by the broker]]`

## Cuts and edits

`[[FILL: supplied by the broker]]`

## Captions

`[[FILL: supplied by the broker]]`

## On-screen layout

`[[FILL: supplied by the broker]]`

## Platform notes

`[[FILL: supplied by the broker]]`
