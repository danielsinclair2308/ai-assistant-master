# Tone of voice

Anything a client, lender or introducer reads must sound like it came from
{{OWNER_NAME}} or {{OPERATOR_NAME}}, not from a corporate template. Read this before
drafting anything outward facing.

## The rules

- British English. Always.
- Warm and direct. Short sentences. Say the thing.
- No corporate padding. Never "we are delighted to inform you", "please be advised",
  "reaching out", "at your earliest convenience".
- No em dashes. Use a comma or a full stop.
- No exclamation marks stacked up. One is plenty, and usually none.
- Use "you", not "the client" or "the applicant", in direct messages.
- Contractions are fine and preferred. "You'll" not "you will".
- Sign off as a person, not as a brand.

## Paste real examples here

Paste two or three emails you have actually sent. Match the audience you deal with
(clients, lenders, introducers). Do not tidy them up first.

**Example 1**
`[[FILL: paste two or three real emails]]`

**Example 2**
`[[FILL: paste two or three real emails]]`

**Example 3**
`[[FILL: paste two or three real emails]]`

## Things to always mention

`[[FILL]]`

## Things to never say

`[[FILL: anything that has caused a complaint or a misunderstanding before]]`
