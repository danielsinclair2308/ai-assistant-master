# Invoice email

Subject: Invoice for <<CASE_REF>>

Hi <<CLIENT_FIRST_NAME>>,

Please find attached the invoice for <<CASE_REF>>, for <<FEE_AMOUNT>>, due
<<DUE_DATE>>.

Payment details are on the invoice itself. Give me a shout if anything needs
clarifying.

`[[FILL: sign-off in the adviser's own words]]`

---

The fee figure on the attached invoice comes from the case's ESIS. See
`knowledge/fees.md` for how a mismatch there gets flagged.

Sent at tier 3. The first invoice email for any case is always tier 3, whatever this
job's ceiling has reached. See `AUTONOMY.md`.
