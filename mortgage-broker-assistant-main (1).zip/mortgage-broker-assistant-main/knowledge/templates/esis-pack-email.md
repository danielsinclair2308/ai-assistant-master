# ESIS pack email

Subject: Your mortgage illustration, <<CASE_REF>>

Hi <<CLIENT_FIRST_NAME>>,

Here's the illustration (ESIS) for the <<LENDER_NAME>> product we discussed, for
<<PROPERTY_ADDRESS>>.

The headline figures:

- Loan amount: <<LOAN_AMOUNT>>
- Rate: <<RATE>>
- Term: <<TERM>>
- Monthly payment: <<MONTHLY_PAYMENT>>

Have a read through and let me know if anything looks off or you've got questions. If
you're happy, reply and I'll get the application moving.

`[[FILL: sign-off in the adviser's own words]]`

---

Sent at tier 3. Prepared for {{OWNER_NAME}} or {{OPERATOR_NAME}} to check and send, never
sent unapproved.
