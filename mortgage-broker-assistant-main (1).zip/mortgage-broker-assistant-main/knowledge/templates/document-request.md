# Document request

Subject: Documents needed, <<CASE_REF>>

Hi <<CLIENT_FIRST_NAME>>,

To keep <<CASE_REF>> moving, could you send over:

<<DOCUMENT_LIST>>

Whatever's easiest works: a photo, a scan, or a download from your bank or portal.
Just make sure everything is fully visible in the frame.

Any questions, just ask.

`[[FILL: sign-off in the adviser's own words]]`

---

Sent at tier 3. Prepared for {{OWNER_NAME}} or {{OPERATOR_NAME}} to check and send, never
sent unapproved. Routine document requests may reach tier 2 only as `AUTONOMY.md` allows,
including {{OWNER_NAME}}'s named exemption for unapproved email.
