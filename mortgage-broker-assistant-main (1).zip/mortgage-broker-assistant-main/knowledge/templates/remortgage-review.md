# Remortgage review email

Subject: Your deal ends <<DEAL_END_DATE>>, worth a look

Hi <<CLIENT_FIRST_NAME>>,

Your current rate on <<PROPERTY_ADDRESS>> ends <<DEAL_END_DATE>>, so it's a good time
to look at what's out there before you drop onto the lender's standard variable rate.

Current balance: <<LOAN_AMOUNT>>
Current rate: <<CURRENT_RATE>>

Let me know if you'd like me to pull together some options, no obligation.

`[[FILL: sign-off in the adviser's own words]]`

---

Sent at tier 3. Prepared for {{OWNER_NAME}} or {{OPERATOR_NAME}} to check and send, never
sent unapproved. Rates and options quoted to the client are always fetched fresh, never
read off a stored figure.
