# Invoice chaser

Subject: Outstanding invoice, <<CASE_REF>>

Hi <<CLIENT_FIRST_NAME>>,

Just flagging that the invoice for <<CASE_REF>>, <<FEE_AMOUNT>>, was due
<<DUE_DATE>> and doesn't look to have come through yet.

Let me know if it's been sent and I've missed it, or if anything's holding it up.

`[[FILL: sign-off in the adviser's own words]]`

---

Sent at tier 3, unless {{OWNER_NAME}} has named this job as an exemption in
`state/decisions.md`, in which case it may reach tier 2 once twenty consecutive correct
outputs have been reviewed. See `AUTONOMY.md`.
