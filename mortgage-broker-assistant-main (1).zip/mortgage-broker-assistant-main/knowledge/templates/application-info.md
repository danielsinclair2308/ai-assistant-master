# Application information skeleton

Case: <<CASE_REF>>

Gathered facts for the application, laid out ready for the adviser to check before
anything is entered into a lender portal. The assistant never submits an application:
see `AUTONOMY.md`.

## Applicants

<<APPLICANTS>>

## Addresses (3 years)

<<ADDRESSES_3_YEARS>>

## Employment and income

<<EMPLOYMENT_AND_INCOME>>

## Commitments

<<COMMITMENTS>>

## Credit

From credit-review, verbatim flags. Never a summary that decides what does or does not
need declaring: that decision is always a human's. See `AUTONOMY.md`.

<<CREDIT_FLAGS_VERBATIM>>

## Property

<<PROPERTY>>

## Loan

<<LOAN>>

## Deposit source

<<DEPOSIT_SOURCE>>

## Lender questions

<<LENDER_QUESTIONS>>

## Open questions

<<OPEN_QUESTIONS>>
