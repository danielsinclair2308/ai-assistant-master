# Document chaser

Subject: Quick nudge, <<CASE_REF>>

Hi <<CLIENT_FIRST_NAME>>,

Just chasing the last bits for <<CASE_REF>>. Still outstanding:

<<OUTSTANDING_DOCUMENT_LIST>>

No rush if today's not good, but the sooner these land the sooner <<CASE_REF>> can move
forward.

`[[FILL: sign-off in the adviser's own words]]`

---

Sent at tier 3, unless {{OWNER_NAME}} has named this job as an exemption in
`state/decisions.md`, in which case it may reach tier 2 once twenty consecutive correct
outputs have been reviewed. See `AUTONOMY.md`.
