# Suitability report skeleton

Case: <<CASE_REF>>

The assistant fills facts only. Recommendation and Reasons are always left for the
adviser: this is a regulated document and the assistant does not write the advice.

## Needs and circumstances

<<NEEDS_AND_CIRCUMSTANCES>>

## Recommendation

`[[ADVISER]]`

## Reasons

`[[ADVISER]]`

## Alternatives considered

<<ALTERNATIVES_CONSIDERED>>

## Costs and fees

<<COSTS_AND_FEES>>

See `knowledge/fees.md` for the firm's fee table used to cross-check this section.

## Risks

<<RISKS>>

---

Stays at tier 3 permanently. Never sent or filed without {{OWNER_NAME}} having written
the Recommendation and Reasons sections themselves. See `AUTONOMY.md`.
