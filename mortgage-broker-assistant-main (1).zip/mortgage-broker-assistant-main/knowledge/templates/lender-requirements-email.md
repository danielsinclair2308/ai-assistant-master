# Lender requirements email

Subject: What <<LENDER_NAME>> need for <<CASE_REF>>

Hi <<CLIENT_FIRST_NAME>>,

<<LENDER_NAME>> have come back with a few requirements for <<CASE_REF>>. Paste the
lender's requirements here exactly as written. Do not summarise, reword or reorder.

<<LENDER_REQUIREMENTS_VERBATIM>>

Let me know if anything above isn't clear and I'll check with them.

`[[FILL: sign-off in the adviser's own words]]`

---

Lender wording is always verbatim. Sent at tier 3, always. See `AUTONOMY.md`.
