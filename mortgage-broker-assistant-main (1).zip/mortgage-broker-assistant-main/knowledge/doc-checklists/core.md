# Document checklist, core

Prompts, not advice. Packs add to this list under their own "Extra documents" section.
**The adviser's version always wins.** If a checklist here disagrees with what the
adviser has asked for on a specific case, the adviser's word stands and the assistant
says so rather than insisting.

## Per applicant

- Photo ID
- Proof of address
- 3 months' payslips (employed)
- 2 years' SA302s or accounts (self-employed)
- 3 months' personal bank statements
- Deposit evidence

## Per company applicant

- 3 months' business bank statements
- Company accounts

## Per property

- Property schedule, for portfolio landlords
- Tenancy agreement, for a BTL remortgage
