# Pack: residential

**Id:** `residential`
**Covers:** first-time buyers, home movers, and residential remortgage.

## What this pack is

The core residential caseload: people buying their first home, moving house, or
remortgaging the home they already live in. Straightforward compared to the other packs,
but the volume tends to be highest here, so the chasing and document flow matter more
than anything exotic.

## Extra documents

Added to `knowledge/doc-checklists/core.md`:

- Gifted deposit letter, where any part of the deposit is a gift
- Help to Buy redemption statement, where an existing Help to Buy equity loan is being
  redeemed

## Lender questions that commonly come up

Prompts, not advice: always check the actual criteria fresh, never off a stored note.

- How is the gifted deposit evidenced and from whom
- Whether the Help to Buy redemption figure is final or an estimate
- Porting versus new lending, on a home mover with an existing deal mid-term

## Fee line

See `knowledge/fees.md` for the residential and remortgage rows. This pack does not set
its own fee logic.

## Skills this pack leans on

`esis-pack`, `client-documents`, `case-tracking`, `inbox-triage`

## Metrics columns it cares about

`enquiries_new`, `docs_requested`, `docs_received`, `offers_issued`, `completions`

## Onboarding follow-ups

- What proportion of your residential caseload is remortgage versus purchase?
- Do you regularly see gifted deposits, and if so, what evidence do you ask for today?
- Do any of your lenders on panel need anything unusual for Help to Buy redemptions?
