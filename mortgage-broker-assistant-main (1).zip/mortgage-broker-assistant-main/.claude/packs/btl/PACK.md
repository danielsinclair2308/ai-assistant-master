# Pack: btl

**Id:** `btl`
**Covers:** buy-to-let, portfolio landlords, and limited company purchases.

## What this pack is

Investment lending rather than a home to live in, so the paperwork leans on the
property and the numbers rather than the applicant's own income alone. Portfolio
landlords and limited company structures both add extra documents beyond core.

## Extra documents

Added to `knowledge/doc-checklists/core.md`:

- Portfolio landlords, meaning 4 or more mortgaged buy-to-lets: property schedule,
  business plan, cash flow
- Limited company purchases: SPV documents, personal guarantees
- Rental figures, taken from the letting agent rather than estimated

## Lender questions that commonly come up

Prompts, not advice: always check the actual criteria fresh, never off a stored note.

- Stress test rate and rental cover ratio the lender is using this month
- Whether the SPV needs to be a new company or an existing one
- Top-slicing from personal income, where the lender allows it

## Fee line

See `knowledge/fees.md` for the buy-to-let row. This pack does not set its own fee logic.

## Skills this pack leans on

`lender-requirements`, `client-documents`, `case-tracking`

## Metrics columns it cares about

`enquiries_new`, `docs_requested`, `docs_received`, `applications_prepared`,
`offers_issued`, `completions`

## Onboarding follow-ups

- How many of your BTL clients are portfolio landlords, meaning 4 or more mortgaged BTLs?
- Do you place limited company purchases regularly, and with which lenders?
- Where do rental figures usually come from: a letting agent, or the client's own
  estimate?
- Do you have a standard cash flow template you already use, or should one be built?
