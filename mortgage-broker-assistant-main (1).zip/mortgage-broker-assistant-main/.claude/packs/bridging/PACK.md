# Pack: bridging

**Id:** `bridging`
**Covers:** short-term bridging finance.

## What this pack is

Speed matters more here than anywhere else in the panel. A bridging case lives or dies
on how fast the exit strategy stands up and how fast everyone else, lender, solicitor,
valuer, keeps moving. This pack leans on daily chasing rather than weekly.

## Extra documents

Added to `knowledge/doc-checklists/core.md`:

- Exit strategy evidence, whatever form the exit actually takes (sale, refinance,
  development completion)
- Refurbishment schedule of works, where refurbishment is part of the plan
- Valuation turnaround expectations, tracked per case since speed is the whole point

## Lender questions that commonly come up

Prompts, not advice: always check the actual criteria fresh, never off a stored note.

- How firm the exit strategy needs to be at application stage versus at drawdown
- Retained interest versus serviced interest, and what that does to the numbers
- Valuer panel and expected turnaround for this specific lender

## Fee line

See `knowledge/fees.md` for the bridging row. This pack does not set its own fee logic.

## Skills this pack leans on

`lender-requirements`, `case-tracking`, `client-documents`

## Metrics columns it cares about

`cases_waiting_lender`, `cases_overdue`, `docs_requested`, `docs_received`,
`offers_issued`

## Onboarding follow-ups

- What is your typical target from enquiry to offer on a bridge, and where does it
  usually slip?
- Which solicitors and valuers do you work with most, and do any need chasing more than
  others?
- Should chasing on bridging cases run daily rather than at the normal cadence?
