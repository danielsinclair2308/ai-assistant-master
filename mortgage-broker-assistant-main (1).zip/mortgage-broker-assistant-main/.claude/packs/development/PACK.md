# Pack: development

**Id:** `development`
**Covers:** development finance.

## What this pack is

Funding a build rather than a purchase, released in stages against progress. The
paperwork tracks the build as much as the borrower, and a monitoring surveyor sits
between the lender and the site.

## Extra documents

Added to `knowledge/doc-checklists/core.md`:

- Planning consent
- Build costs
- Contractor details
- Monitoring surveyor appointment
- Drawdown schedule

## Lender questions that commonly come up

Prompts, not advice: always check the actual criteria fresh, never off a stored note.

- Day one land value versus gross development value, and what loan-to-cost the lender
  will go to
- Who the monitoring surveyor is, and whether the lender has an approved panel
- How drawdowns are triggered: fixed stages or surveyor sign-off per stage

## Fee line

See `knowledge/fees.md` for the development row. This pack does not set its own fee
logic.

## Skills this pack leans on

`lender-requirements`, `case-tracking`, `back-office-admin`

## Metrics columns it cares about

`cases_waiting_lender`, `cases_overdue`, `docs_requested`, `docs_received`,
`offers_issued`

## Onboarding follow-ups

- Do you have a preferred monitoring surveyor, or does it vary by lender?
- How are drawdown requests usually tracked today?
- What is your typical target from enquiry to offer on a development case?
