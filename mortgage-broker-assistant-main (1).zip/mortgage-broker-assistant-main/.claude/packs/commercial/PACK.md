# Pack: commercial

**Id:** `commercial`
**Covers:** commercial mortgages.

## What this pack is

Lending against a trading business or its premises rather than a residential property.
The paperwork is heavier on the business side: trading history, lease terms and a plan
for how the business intends to use the money.

## Extra documents

Added to `knowledge/doc-checklists/core.md`:

- Trading accounts
- Lease details, where the property is leasehold or the business operates under one
- Business plan

## Lender questions that commonly come up

Prompts, not advice: always check the actual criteria fresh, never off a stored note.

- Minimum trading history the lender wants to see
- How the lender treats owner-occupied versus semi-commercial or investment use
- Lease length remaining, and any break clauses

## Fee line

See `knowledge/fees.md` for the commercial row. This pack does not set its own fee logic.

## Skills this pack leans on

`lender-requirements`, `client-documents`, `case-tracking`

## Metrics columns it cares about

`enquiries_new`, `docs_requested`, `docs_received`, `applications_prepared`,
`completions`

## Onboarding follow-ups

- What proportion of commercial cases are owner-occupied versus investment?
- Do you have a standard set of questions you ask about the trading business before
  approaching a lender?
- Which lenders on your panel are strongest for commercial, and for what sectors?
