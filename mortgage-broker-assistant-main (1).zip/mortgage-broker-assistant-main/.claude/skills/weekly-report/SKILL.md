---
name: weekly-report
description: The Monday morning report for {{OWNER_NAME}} and {{OPERATOR_NAME}}.
group: core
tier: 1
ceiling: 1
mode: sequence
needs: []
better-with: [email, case-system]
---

# Weekly report

Runs weekly, Monday 07:00, last in the weekly run after attribution, learning and the
connections check. Tier 1: drafted, then sent to {{OWNER_NAME}} and {{OPERATOR_NAME}} only.
Nobody outside the business ever receives it.

Load: `data/metrics.csv`, `state/open-items.md`, `state/decisions.md`, `state/outcomes.md`,
`state/cases.md`, `state/chasers.md`, `state/approvals.md`, `state/processes.md`, `state/connections.md`,
`data/baseline.md`, `state/enabled-packs.md`, and each enabled pack's `PACK.md` for what
it cares about.

Five minutes to read. {{OWNER_NAME}} wants headlines and decisions. {{OPERATOR_NAME}}
wants enough detail to act. Headlines first. Case references throughout, never client
names.

## Structure

**1. The number.** The north-star metric for each enabled pack, from
`knowledge/strategies/registry.md`, for the week, against last week and against the same
week last year if the data exists. If a pack is not enabled, omit its metric. If the
figure cannot be retrieved, say so.

**2. Cases by stage, and who they wait on.** Every live case, grouped by stage (pre-offer,
pre-completion) and by who it is waiting on (client, lender, adviser, other). The list
and the counts come from the live cases CSV, fetched once for this report through the
`case-system` skill's bulk route, `scripts/cases_fetch.py` (see "Bulk reads and counts"
in `case-system`), into a temporary file outside this folder. Never call the case system
directly and never read every case into the report: count the CSV in a script. The CSV
already merges in `state/cases.md` for fields the system cannot hold. Where the two
disagree, say so rather than picking one. If the fetch fails, say so and report from
`state/cases.md` alone, marked as possibly stale.

**3. Overdue.** Run `python scripts/chase_due.py --cases-input <the same temp file>`
(without `--cases-input` if the fetch failed) and report what it prints: chasers due,
cases OVERDUE, chase dates arrived. Case references only. If it prints "case dates not
checked", say that, not "nothing overdue". Delete the temporary file once sections 2 and
3 are written, whether they succeeded or not.

**4. Lender quotes outstanding.** Run `python scripts/quote_tracker.py` and report which
cases are waiting on which lenders, for how long, and which are READY for the adviser.
Never rank the lenders or suggest one.

**5. Invoices unpaid.** Open `job:invoicing` lines in `state/chasers.md`, checked against
the bank feed if it is connected. Amounts only as retrieved, never as remembered.

**6. Approvals pending.** Open lines in `state/approvals.md`, oldest first, with how long
each has waited and whether it was chased. Silence is not a yes, so these stay here until
answered.

**7. Remortgages due.** From the latest `python scripts/expiry_scan.py` run: DUE, PASSED
and CHECK, by case reference. If no expiry data could be fetched, say so.

**8. Did recent decisions work.** From `state/outcomes.md`, written by attribution just
before this. Decisions checked, worked, did not work, cannot tell. Name the misses.

**9. Needs a person.** From `state/open-items.md`, including any `case-system-sync` items
still waiting. Be specific.

**10. Dormant processes, and one tool suggestion.** Every process in `state/processes.md`
marked `status:dormant`, with the capability it is missing. Then at most **one** tool
suggestion, from the `connections` skill's weekly check: what to connect, what it would
unlock, and what leaving it costs. Never a suggestion declined in the last 90 days.

**11. Settings still on their defaults.** One line listing every setting a skill is
running on its default because the key is absent from that job's latest line in
`state/processes.md`, with the default in use, for example `case-tracking overdue-days
(default 2)` or `remortgage-watch lead-days (default 180)`. Gather these from each
active skill whose steps say to "mention it in each weekly report while the key is
absent" (at the time of writing `case-tracking`, `client-documents`, `email-marketing`,
`esis-pack`, `invoicing`, `lender-quotes`, `lender-requirements`, `remortgage-watch`,
`social-engagement` and `whatsapp-command`). If none, one line saying so. The general
rule holds regardless of this list: every active skill running any setting on its
default belongs in this section, even one not named here.

**12. Three recommendations, ranked.** Each with a real figure behind it, or no figure and
an honest gap.

**13. One question, at the very bottom, only if worth asking.** From
`.claude/skills/learning/`. If nothing cleared the bar this week, ask nothing.

If more than one pack is enabled, give each pack its own short line under section 1 rather
than one blended KPI.

## Rules

- British English. Warm, direct, no em dashes. See `knowledge/tone-of-voice.md`.
- No invented figures. A gap in the report is fine. A plausible fake number is not.
- Scripts print the counts. Do not read raw trackers or the whole case book into the
  report to reach a number a script already prints. See `EFFICIENCY.md`.
- No client names, contact details or financial detail beyond what the case reference
  needs. See `DATA-HANDLING.md`.
- If a section has nothing in it, one line saying so. Do not pad.
