# The question bank

Every question you may need to ask in onboarding phases 2 to 7, with wording, a default,
why it matters, and what to do if they skip or do not know.

Product-specific questions live in each pack's `PACK.md`. Ask those only when that pack
is enabled.

**Rules for all of them:**
- Ask one at a time. Wait for the answer.
- Always offer the default. It is far easier to correct an answer than to produce one.
- No jargon. Say "connected to your email", never the name of the plumbing.
- If they do not know, say that is fine, log it as `[[FILL: ...]]` and in the open items,
  and move on. Never press twice.
- Write the answer to the file immediately and say what you saved.
- If they agreed to a default, that counts as their answer. If they went quiet, it does
  not. Leave the gap.
- Never invent a number, a name or a rule to fill a gap.
- Never ask for a password, a card number or bank details. Never.

---

## Phase 2: The business

### Role
**Writes to `knowledge/business.md` and the role line in `state/enabled-packs.md`.**

> Are you the adviser, the person who runs the cases day to day, or both?

Default: the adviser.
Why it matters: it sets how much detail you give and who approvals go to.
If they skip: treat them as the adviser until corrected, and ask again at phase 4 when
approvals come up.

### The firm
**Writes to `knowledge/business.md`.**

> What's the firm called, and does it trade under a different name?

> Is the firm directly authorised, or part of a network? If it's a network, which one?

> Do you have the firm's FCA reference number to hand? If not, that's fine, we can add it
> later.

> Which email address should people use for enquiries? When someone messages about a
> mortgage on social media or by text, I'll invite them to email it.

Default: none. These are facts only they have.
If they skip: `[[FILL]]` each one. Nothing else waits on them.

### People
**Writes to `knowledge/business.md`.**

> Who else works on cases, and what does each person do? First names and roles are plenty.

Default: just the two of you, the adviser and the case administrator.
If they skip: leave the placeholders and ask again in the first weekly report.

### Staff email addresses
**Writes to `state/connections.md`, `email` row Notes, as `staff-email: <role> | <address>`.**

> When I ask you or {{OPERATOR_NAME}} to approve something by email, which address will
> you each answer from? I'll only take a yes from exactly that address.

Default: none. Their business addresses only, never a guess from an email signature.
Why it matters: `approvals`' email answer rule relies only on addresses recorded here,
and an emailed approval counts only from the recorded address.
An address is recorded only once {{OWNER_NAME}} has confirmed it in their own words,
the same as the WhatsApp question.
If the person answering is not {{OWNER_NAME}}: record nothing, and save the question for
{{OWNER_NAME}} in `state/open-items.md`.
If they skip: approvals by email cannot be accepted from that person until it is
recorded. Log it as an open item.

### Fees
**Writes to `knowledge/fees.md`.**

> What's your broker fee for a residential mortgage, when do you charge it, and is it
> refundable?

Then the same for each product they advise on, one at a time. Then:

> When you send an invoice, when do you ask to be paid? On receipt, within 14 days,
> something else?

Default: none. Never suggest a fee.
Why it matters: every invoice is cross-checked against this. The invoice itself always
takes its fee from the case's ESIS.
If they skip: `[[FILL]]`. Invoicing still works from the ESIS, and a mismatch cannot be
flagged until this is filled. With no payment terms recorded, invoicing asks
{{OWNER_NAME}} for the terms on each invoice rather than assuming any.

### Product mix
**Writes to `knowledge/business.md` and `state/enabled-packs.md`.**

> Which kinds of mortgage do you mostly arrange? Residential, buy-to-let, bridging,
> commercial, development, or a mix?

Default: residential, if nothing they have said so far points elsewhere.
Why it matters: it decides which product packs load. Everything product-specific hangs
off this.
If mixed: enable each matching pack and record the rough split if they offer one.
If they do not know: ask what kind of case took most of their time last month, and map
from that.

---

## Phase 3: A normal week

### Tools
**Writes to the Register in `state/connections.md`.**

> In a normal week, what do you actually open? Your email, your case system, WhatsApp,
> your banking, sourcing tools, lender portals. A rough list is fine.

Then prompt for the ones people forget, one short line at a time:

> Anything for credit reports? A calendar? Instagram, Facebook, LinkedIn or TikTok?
> Anything for editing videos? Who looks after the website? Any spreadsheets you keep
> yourself?

Default: start from email and the case system, then ask what you missed.
Why it matters: a tool that is not connected is a job that cannot exist.
If they do not know: ask them to glance at their phone's home screen or their browser
bookmarks.

---

## Phase 4: Processes

For each process, say the sentence below, then ask the three questions:

> Do you want this?

> Should it run at set times, or when something happens? I'd normally [default from the
> skill's mode, in plain words].

> Who should approve what it sends? I'd normally ask {{OWNER_NAME}}.

Do not ask how often to chase, how long before a case is overdue, how far ahead to look
for product end dates, or how long lenders get to reply. Each process has a sensible
default. If they mention one of these anyway ("chase every 5 days", "look 120 days
ahead"), record it on that process's line as the optional setting, in their number:
`every`, `overdue-days`, `lead-days`, `deadline-days`, `max-age-days`, `daily-limit`,
`batch-size` or `stale-hours` (see `state/processes.template.md`).

If they skip a process: record `want:no` for now, add it to "Still outstanding", and move
on. It is not offered again during setup, only later through the weekly report.

| Process | The one sentence |
|---|---|
| `client-documents` | When a new case starts, I set up the client's folder, work out which documents are still missing, draft the request and chase it until everything's in. |
| `esis-pack` | When a case reaches ESIS stage, I put the ESIS, privacy notice and fee agreement together in one email for you to check, then keep the client's acceptance on file. |
| `lender-requirements` | When a lender or underwriter asks for something, I copy their exact words into an email to the client for you to check, and track it until it's answered. |
| `lender-quotes` | When you've asked several lenders for terms, I keep track of who's come back and who hasn't, and tell you when you've heard from enough to decide. |
| `invoicing` | When an offer arrives, I draft the invoice using the fee on the ESIS, for you to check and send, then watch for the payment and chase if it doesn't come. |
| `application-pack` | I pull everything we know about the client into one document, with where each answer came from and a list of anything still unclear. |
| `lender-portals` | I fill in the lender's online application from that document once you've signed in, stop at anything I'm not sure of, and leave it for you to check and submit. |
| `case-tracking` | Every day I check where each case is, who it's waiting on and what's overdue, and keep the case system up to date. |
| `back-office-admin` | I file ESIS documents, applications and offers in the right place, and draft suitability reports with the facts filled in and the recommendation left for you. |
| `credit-review` | Once the client has agreed and you've got their credit report into their folder, I summarise everything on it for you to discuss with them. |
| `remortgage-watch` | Each week I look for past clients whose deal is ending soon and draft a note to them for you to check. |
| `inbox-triage` | Twice a day I read everything that's come in, on every channel, and send you one short list of what needs you. |
| `move-to-email` | When someone asks about a mortgage by text or on social media, I draft a friendly reply inviting them to email, so their details stay safe. |
| `whatsapp-command` | You can message or voice-note me on WhatsApp to chase someone, update a case or draft an email, and I'll check with you before anything goes out. |
| `social-engagement` | I look for posts where people are asking for a mortgage broker and draft replies for you to check. |
| `short-form-video` | You send me raw video, I edit it to your rules, add captions and get it ready for you to approve. |
| `email-marketing` | I draft campaigns for groups of past clients who've agreed to hear from you, for you to approve before anything goes. |
| `lead-generation` | I keep an eye on where your enquiries come from and log new ones in the case system. |
| `website` | I draft changes to your website and landing pages for you to approve before they go live. |

Defaults for "Do you want this?": yes for `client-documents` through `move-to-email`;
yes for `whatsapp-command` if they said they use WhatsApp for work, otherwise "not yet";
"not yet" for `social-engagement` through `website`, unless they have already said they
do that work.

---

## Phase 5: Connections

Wording for each gap, in plain words:

> To [process in their words], I'd need to be connected to [the tool, as they name it].
> That would mean [what it unlocks]. We can connect it directly, through a go-between
> service, or I can do it slowly through the browser. Without it, [the cost].

Connecting, one at a time:

> Could you press [the button], then sign in as you normally would? I'll wait.

Default: connect now if it is on the connect-now list.
If they skip or a login is missing: five minutes, then park it as blocked with what is
needed and who can get it. Never ask them to tell you a password.

---

## Phase 6: Case system

### Which system
**Writes to `state/connections.md` and `knowledge/systems/`.**

> Which system do you keep your cases in?

Default: none. Whatever they say is right, including a spreadsheet.

### How it connects
> Shall we connect it now? You'll sign in, and I'll tell you which buttons to press.

Default: yes, now.
If it cannot connect today: park it, and tell them which processes will wait for it.

### The 14 fields
**Writes to the Field mapping in `state/connections.md`.**

One field at a time:

> Where do you keep the [field]? In the case system, or somewhere else?

Default: "in the case system, if there's a field for it". If the system is connected, look
first and ask them to confirm what you found.
If there is nowhere for it:
- For waiting on, date requested, chase date, pre-offer or pre-completion, submission
  date, valuation date, case status, and lead source: record `state/cases.md` and say
  that's where you'll keep it, by case reference only.
- For outstanding actions: record `state/cases.md` too, but only as a short non-personal
  action label, such as `docs-outstanding` or `awaiting-valuation`, never as free text
  that could carry a client's name or detail.
- For anything else, including client name, property address, loan amount, proc fee and
  broker fee: record "client folder only". Never keep it in this folder. Say:
  > Your case system doesn't have a place for that, so it'll stay in the client's folder.
  > I'll flag it for {{OWNER_NAME}} in case there's a better home for it.

  Then write an open item for {{OWNER_NAME}}.
If they do not know: `[[FILL]]`, and look again during the overnight audit.

---

## Phase 7: Knowledge

### Tone
**Writes to `knowledge/tone-of-voice.md`.**

> Rather than describing how you write, could you paste in two or three emails you've
> actually sent? An ordinary one to a client and one to a lender is perfect.

Remove client names and details before saving.
If they will not: fall back on the rules already in the file and show a draft to correct.

### Messaging
**Writes to `knowledge/messaging.md`.**

> How do you usually introduce the firm, in a sentence or two?

Then experience, credentials, specialisms, service principles and the contact link, one at
a time.
Default: none. Their words only.
If they skip: `[[FILL]]`. Social replies and marketing cannot draw on a section that is
empty, and will say so.

### Fee agreement
**Writes to `knowledge/fees.md`.**

> Where do you keep the fee agreement you send clients?

Default: none.
If they skip: `[[FILL]]`, and the ESIS pack waits on it.

### Invoice template
> Could you open the invoice template in Word and replace the lines marked FILL with your
> firm's details and payment details? I'll show you where it is. I don't type bank details
> myself, ever.

Default: now, while we're here.
If they skip: invoices cannot be produced until it is done. Log it as an open item.

### Document checklists
**Writes to `knowledge/doc-checklists/`.**

> Here's the list of documents I'd ask for on a normal case. What would you add or take
> away?

Default: the list as it stands.

### Lender panel
**Writes one file per lender in `knowledge/lenders/`.**

> Which lenders do you use most? We'll do one at a time: what you use them for, and how you
> submit to them.

Default: start with the three they use most. The rest can come later.
If they skip: fine. A lender with no file is looked up when a case needs it.

### Client folder root
**Writes to `state/connections.md` and `DATA-HANDLING.md`.**

> Where on this computer, or on your shared drive, do you keep client folders?

Default: none.
If the path is inside this assistant's folder: say that client documents must never sit
in here, because this folder is backed up somewhere else, and ask for another place.
If they skip: client folders cannot be created. Log it as an open item.

### Short-form video rules (only if `short-form-video` is wanted)
**Writes to `knowledge/content/short-form-rules.md`.**

> How do you like your videos to open, and how fast should they move? Anything you always
> or never do with captions?

Default: none. Nothing guessed from a generic playbook.
If they skip: the process stays switched off until the rules exist.

### Raw video folder (only if `short-form-video` is wanted)
**Writes to `state/connections.md`, `video-tools` row Notes, as `raw-folder:<path>`.**

> Where will you drop the videos you record for me? A folder on this computer or your
> shared drive is perfect.

Default: none.
If the path is inside this assistant's folder: say video must not sit in here, because
this folder is backed up somewhere else, and ask for another place.
If they skip: the process stays switched off until there is a folder.

### WhatsApp instructions (only if `whatsapp-command` is wanted)
**Writes to `state/connections.md`, `whatsapp` row Notes, and to `state/decisions.md`.
Asked of {{OWNER_NAME}} only.**

> So I only ever take instructions from you, could you save your own number as a contact
> in the WhatsApp account I'm connected to, and tell me the contact's name? Then tell me
> the last four digits of your number yourself, so I can check the contact against it.
> Should {{OPERATOR_NAME}} be able to give me instructions too?

Record `command-sender: <role> | contact:<saved contact name> | ends:<last four digits>`
for each, never the whole number. The four digits are the ones {{OWNER_NAME}} says, never
read off the contact. Check the name matches exactly one saved contact whose number ends
in those digits; if not, say so and ask again.
Default: {{OWNER_NAME}} only.
If the person answering is not {{OWNER_NAME}}: record nothing, and save the question for
{{OWNER_NAME}} in `state/open-items.md`. Until a sender is recorded, nothing on WhatsApp
is treated as an instruction.

### Suspense commissions (only if `back-office-admin` is wanted)
**Writes to `knowledge/business.md`, under "Back office rules". Asked of
{{OPERATOR_NAME}}.**

> When a commission payment comes in and can't be matched to a case, what do you do with
> it, and who needs to know?

Default: none.
If they skip: `[[FILL]]`, and unmatched commissions are flagged to {{OPERATOR_NAME}} rather
than handled.

### Social posting rule (only if `social-engagement` is wanted)
**Writes to `knowledge/messaging.md`, under "Social posting rule", and to
`state/decisions.md`.**

> When I draft a reply to a post, should every one come to you first?

Default: yes, every reply comes to {{OWNER_NAME}} first.
If they want something looser: record it as the goal, and explain it applies only once
replies have been right twenty times in a row.

### Invoice chasers (only if `invoicing` is wanted)
**Writes to `AUTONOMY.md` under Exemptions and to `state/decisions.md`, only if
{{OWNER_NAME}} names the exemption.**

> The first invoice email always goes from you, after you've checked it. After that, if it
> isn't paid, I'd chase every 3 days. Should each chaser come to you first, or are you
> happy for the chasers alone to go without asking you?

Default: each chaser comes to {{OWNER_NAME}} first.
If {{OWNER_NAME}} says the chasers can go without asking: confirm it back in one sentence
naming the job and whether they are copied in, then record it. If the person answering is
not {{OWNER_NAME}}, keep the default and save the question for {{OWNER_NAME}}.

---

## Questions to never ask when a connected system can answer

Ask the system or the file, not them:

- How many live cases they have, or what stage each is at
- Which lenders a case is with, or when a case was submitted
- Client details of any kind
- Current rates, products or criteria. Those are always fetched fresh, never stored

If you find yourself about to ask one of these, look it up first. Every answer you fetch
rather than ask saves their attention for something only they know.
