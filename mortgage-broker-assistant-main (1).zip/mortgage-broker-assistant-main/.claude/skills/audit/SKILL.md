---
name: audit
description: Excavate what already exists. Read the case system and mailbox history the night after setup, backfill the trackers, and report what they show. Runs once, unattended.
group: core
tier: 1
ceiling: 1
mode: once
needs: []
better-with: [case-system, email]
---

# The audit

Runs once, overnight, the night after the setup session. Expect several hours. Tier 1:
reads everything, and changes nothing outside `state/` and `data/`.

This business has been running cases for years. Every enquiry, every lender, every
document chased and every offer is already recorded somewhere, in the case system and in
the mailbox. Nobody has ever read it end to end.

They are not short of data. They are short of anyone having read it.

**Do not do this during the setup session.** It takes hours and it does not need anyone
watching. Run it overnight, alone, and present the findings afterwards. That is also what
makes it valuable: they wake up to a picture of their own caseload that nobody has ever
assembled, and to trackers that already know where every live case stands.

Change nothing in their systems. Read everything. Write findings and tracker lines only.

Every read of the case system goes through the `case-system` skill: its `find_case`,
`read_case` and `list_missing` verbs for single cases, and its bulk route, `scripts/cases_fetch.py`
(see "Bulk reads and counts" in `case-system`): the live cases CSV for listing and
counting live cases, and for history a pull written into the same script, on the same
recorded route, with the same rule of case references and non-personal fields only, into
a temporary file outside this folder that is deleted after the run. This job
never calls the case system directly. Scripts do the fetching and counting throughout, and
print case references and counts, never client names.

---

## Part 1: What has been configured

Settings added by different people at different times, some contradicting each other,
none reviewed since. Record what is actually there, not what anyone thinks is there.

**Case system**
- Case stages and statuses in use, and which are never used
- Which of the 14 tracked fields in the Field mapping section of `state/connections.md`
  are actually filled in on live cases, and which are mostly blank
- Document categories, and whether documents land in them consistently
- Automated tasks or reminders, which are on, and who they go to
- Lead sources recorded, and how consistently

**Mailbox**
- Templates and signatures in use for document requests, chasers, ESIS packs and invoices
- Folders and rules, and whether any rule quietly files lender or client email away
- Which lenders and underwriters write in, and from which addresses

**Client folders**
- Whether the folder structure is consistent across cases
- Cases in the case system with no folder, and folders with no case

**Then find the contradictions.** These are the most useful findings and nobody can see
them from inside. A case marked offered in the case system with no offer in the folder. A
case marked waiting on the client where the client replied a fortnight ago. Two templates
for the same chaser saying different things.

## Part 2: What has actually happened

**This is the part that matters most, and the part nobody has ever done.**

Pull the case history as far back as the system holds, through the `case-system` skill's
bulk route. Do not sample. Do this in a script, print the conclusions, and never read the
raw cases into the conversation.

Work out, by product type where the case system records it:

**Enquiry to submission.** How long it really takes, and where the time goes.

**Submission to offer.** By lender, where the data allows. Which lenders are quick and which
routinely come back with further requests.

**Where cases wait.** On the client, on the lender, on the adviser. Which documents are
chased most often, and how many chases they take.

**Cases that went nowhere.** Enquiries that never reached submission, and at what stage
they stopped.

**Lead sources over time.** Where enquiries and completions actually came from.

**Remortgage book.** How many past clients have a product or ERC end date coming up, as a
count by month, from the case system. By reference only.

## Part 3: Backfill the trackers

**Do not start the trackers from empty.** A live case the trackers do not know about is a
case nobody will chase.

- **`state/cases.md`**: one line per live case, **only for the tracker fields (waiting
  on, date requested, chase date, stage, submission date, valuation date, case status,
  lead source, and outstanding actions as a short non-personal label) that the case
  system cannot hold**, per the Field mapping in `state/connections.md`. If the system
  holds a field, it is not copied here. A field marked "client folder only" is never
  copied here either. If the system holds every field, this file stays empty. Case
  reference only, in the tracker format.
- **`state/chasers.md`**: one line per chase that is genuinely in progress, found in the
  mailbox: a document request or lender requirement still unanswered, an invoice unpaid.
  `last:` is the date of the most recent chase actually sent. Nothing is sent tonight.
- **`state/lender-quotes.md`**: one line per lender on each case where the adviser has
  asked several lenders for terms and the thread is still open. `replied:` only where a
  reply is actually in the mailbox. Never treat silence as a decline.

Every backfilled line is marked in its note or in `state/decisions.md` as backfilled by the
audit, so a later reader can tell it from a line written live.

**The metrics ledger.** Where the case history allows, reconstruct past rows of counts,
marked clearly as backfilled rather than measured live. The backfill goes into
`data/archive/metrics-YYYY.csv`, one file per year, and is then summarised into
`data/metrics-monthly.csv`. Only the last 90 days belong in `data/metrics.csv`. Run
`python scripts/rollup.py` afterwards to confirm everything has landed where it should.
Where a column cannot be reconstructed, write NA. Never estimate a historic figure.

## Part 4: The findings report

One document, by email to {{OWNER_NAME}} and {{OPERATOR_NAME}} only. Written for
{{OWNER_NAME}}, who does not want detail, with the detail underneath for {{OPERATOR_NAME}}.

Structure it as:

1. **The ten things worth knowing**, ranked by how much time or how many cases they
   affect. Lead with the most surprising one.
2. **What is stuck right now.** Live cases waiting longest, and on whom.
3. **What is broken or contradictory**, with what it is costing in time or cases.
4. **What the history actually shows.** Enquiry to offer, where cases wait, which
   documents are chased most, lead sources.
5. **What is quietly working** that they should do more of. Include this. An audit that is
   entirely bad news reads as a sales document.
6. **What still cannot be measured**, and what would be needed.
7. **The ten things I would fix first**, in order, with the reasoning.

Case references only. No client names, contact details or financial detail.

## Rules

- **Findings only. Fix nothing.** Even the obviously broken things. This run is read only
  outside `state/` and `data/`, and its credibility depends on that being true. No emails
  to clients or lenders, no case system writes, no chasers sent.
- **Backfill only what the case system lacks.** Copying fields the system already holds
  into `state/` creates two versions of the truth.
- **Never assume a setting is wrong because it is unusual.** Years of a working business
  means most odd-looking things had a reason. Ask rather than assert. "Cases with one
  lender always skip the valuation stage in the case system. Deliberate?"
- **Quantify everything you can.** "Some cases wait on payslips" is a fact. "Payslips were
  chased on 40% of cases, on average three times" is a finding. Every figure comes from a
  script, never from the model's head.
- **Say what you could not see.** A system you could not reach, history that does not go
  back far enough, a field nobody filled in. The gaps are part of the picture.
- **Do not editorialise about how it has been run.** These people built something that
  works. The framing is what the data shows, never what they should have been doing.
- **Personal data stays in the case system and the client folder.** See
  `DATA-HANDLING.md`. The audit reads it there and writes only references and counts.
- Scripts do the fetching and counting throughout. Read conclusions, not records. Reading
  years of cases and email into a conversation would be the single most expensive thing
  this assistant could ever do.
