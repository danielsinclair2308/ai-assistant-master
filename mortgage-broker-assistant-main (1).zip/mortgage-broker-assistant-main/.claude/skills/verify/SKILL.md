---
name: verify
description: Check that what was logged actually happened: filed documents, sent emails, sent chasers.
group: core
tier: 1
ceiling: 1
mode: sequence
needs: []
better-with: [case-system, email]
---

# Verify

Runs in the 23:00 nightly run. Tier 1: it reads and reports, and changes nothing.

Load: `state/decisions.md`, `state/runs.log`, `state/approvals.md`, `state/chasers.md`

`runs.log` keeps 7 days, which is more than this job needs: everything here is about today.
Older lines are in `state/archive/`.

The assistant writes down what it did. Until something checks that against reality, the log
is a record of intentions rather than actions. A document logged as filed that never
reached the case system, or a chaser logged as sent that is still sitting in drafts, looks
identical to one that worked, and the first sign of trouble would be a client or a lender
asking why nobody replied.

## Nightly

1. **Every document marked filed today** was confirmed by the `case-system` skill's
   `upload_document`, which reads the document back and checks it is attached to the right
   client and case. A filing logged without that confirmation is a mismatch. Ask
   `case-system` to check it now rather than taking the log's word for it.

2. **Every approved email was actually sent.** For each line in `state/approvals.md`
   answered approve today, check the mailbox's sent folder for that email, to that
   recipient, with the attachments that were approved. An approved email still in drafts,
   or sent with different wording or attachments from what was approved, is a mismatch.

3. **Every chaser marked sent appears in the sent folder.** For each `state/chasers.md`
   line whose `last:` date is today, find the chaser in the sent folder. If it is not
   there, the chase did not happen, whatever the tracker says.

4. **Every other decision logged today as APPLIED** gets checked against the live system.
   Was the case field actually updated? Was the task actually created for the named
   person? Is the draft actually there?

5. **Every expected run** in `SCHEDULE.md` should appear in `runs.log` for today. Anything
   missing means a scheduled job did not fire.

6. **Any mismatch is reported by email to {{OPERATOR_NAME}} tonight,** copying
   {{OWNER_NAME}} where it concerns a client or lender email. Not saved for Monday. A
   chaser that silently stopped means a case that silently stalled, and the whole point of
   this job is that nobody has to remember to look. Each mismatch also goes to
   `state/open-items.md`, by case reference.

7. **Log the session count** for the day, from `EFFICIENCY.md`. If it is above what the
   schedule expects, something is retrying in a loop.

8. **Run `python scripts/guard.py`.** It checks whether anything in `state/` or `data/` has
   grown past the threshold and writes one open item if so. It never deletes anything and
   it never rolls anything up. If it flags a file, the monthly rollup will deal with it, or
   a human will decide to. Do not start moving history around at 23:00.

## Rules

- **A mismatch is reported, never quietly retried.** If a document did not land, or an
  email did not go, say so. Do not just try again, because if it failed for a reason then
  trying again in the dark makes it worse, and a client email sent twice is its own
  problem.
- **Do not mark something verified you could not actually check.** Unverifiable is a
  distinct outcome from verified, and it gets recorded as such. If the case system or the
  mailbox cannot be reached tonight, every check that depends on it is unverifiable.
- If verification itself cannot run, that is the most important thing to report, because
  everything else here depends on it.
- Report by case reference, never by client name.
- Keep this cheap. It is a handful of lookups against things logged today, not a re-read of
  the business. Where the lookups are repetitive, a script in `scripts/` does them.
