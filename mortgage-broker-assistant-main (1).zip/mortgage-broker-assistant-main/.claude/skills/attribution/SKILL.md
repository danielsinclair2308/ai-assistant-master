---
name: attribution
description: Check whether the decisions actually worked. Closes the loop between what was done and what happened.
group: core
tier: 1
ceiling: 1
mode: sequence
needs: []
better-with: []
---

# Attribution

First job in the Monday weekly run. Tier 1: reads and records, and changes nothing.

Load: `state/decisions.md`, `state/outcomes.md`, `data/metrics.csv`, `data/baseline.md`

**Everything you need for the weekly pass is in `decisions.md`, whatever its age.** A
decision is only archived once it has a verdict, so a decision waiting to be checked is
never somewhere else. You will never have to open an archive to do the weekly job, and if
you find yourself wanting to, something has gone wrong: say so rather than working around
it.

Without this job the assistant tracks cases and acts on them, but never finds out whether
its own actions were any good. Six months in, the only honest answer to "did this work"
would be "cases are moving faster and I cannot tell you how much of that was me". That is
the question the whole engagement gets judged on, so it gets its own job.

## Weekly

1. **Find the decisions due.** Every entry in `decisions.md` with a `Check on` date of
   today or earlier that has no matching entry in `outcomes.md` yet.

2. **Look up what happened.** Use `data/metrics.csv`, the trackers in `state/`, and the
   case system through the `case-system` skill. Check the specific expectation, not the
   general picture. If the decision said the client on C-1042 would send the payslips
   within three days of the chaser, check whether the payslips arrived within three days.

3. **Compare against the holdout** where there was one. A comparable case left on the old
   approach over the same period is the only thing that separates the decision working
   from the case simply moving on its own.

4. **Write the verdict** to `outcomes.md`. WORKED, DID NOT WORK, NO EFFECT, or CANNOT TELL.

5. **Be honest about CANNOT TELL.** If a client sent documents the day after a chaser, they
   might have sent them anyway. If a landing page went live in April and enquiries rose in
   June, that is not proof. Say so. Confident attribution that does not survive scrutiny is
   worse than no attribution, because it destroys the credibility of the numbers that are
   real.

6. **Report the hit rate** in the weekly report. Decisions checked, worked, did not work,
   cannot tell. Include the misses by name, by case reference.

7. **Watch the backlog.** Decisions past their check date with no verdict stay in
   `decisions.md` for ever, by design, so that none is ever lost. That means the size of
   that file is a direct measure of how well this job is being done. If the monthly rollup
   has written an `attribution-backlog` item to `state/open-items.md`, work through them,
   and use CANNOT TELL honestly rather than leaving them open. An unclosed decision is not
   a tidy problem, it is a decision nobody ever found out about.

## Quarterly, the proof pack

Once a quarter, produce the honest picture against `data/baseline.md`. Read the summary
at the top of each archive file first, and open a full archive only when a summary raises
something you need the detail for. Longer run figures come from `data/metrics-monthly.csv`
rather than the daily ledger:

- Every measured baseline figure, then, now, and the change
- What the assistant did that plausibly contributed, and what the evidence is
- Where holdout cases ended up against the ones the assistant worked
- Days from enquiry to submission and to offer, then and now, where both were measured
- Adviser and case administrator hours given back, where there is evidence for it
- **What did not work.** Include it. A report with no failures in it is not believable, and
  it is the failures that make the successes credible.
- What is still not measurable, and what would be needed to measure it

This is the document that decides whether month six is a renewal conversation or a shrug.

## Adoption

Track these weekly as well, because they predict a problem long before anyone mentions one:

| Signal | Why it matters |
|---|---|
| Approvals asked, answered, ignored | Ignored approvals are the first sign of disengagement |
| Drafts reviewed against drafts left sitting | If drafts pile up, the assistant has become a thing that emails on Mondays |
| Corrections given per week | Corrections falling to zero is bad news, not good news. It means nobody is checking |
| Days since {{OPERATOR_NAME}} last started a conversation | The clearest single number |

If any of these drift for two weeks running, say so plainly in the report. Not passively.
"Fourteen drafts have been waiting for review since the 3rd" is useful. Silence is not.

## Rules

- **Never claim credit that is not evidenced.** The bar is what would survive
  {{OWNER_NAME}} asking a sharp question.
- **Never revise an outcome** because a later one looked better.
- **Correlation gets named as correlation.** Enquiries rising after a landing page went
  live is not the page working, it is consistent with the page working.
- **Case references, never client names,** in `outcomes.md` and in the report.
- If the honest answer to a quarter is "completions are up and most of it was the market",
  that is what the report says.
