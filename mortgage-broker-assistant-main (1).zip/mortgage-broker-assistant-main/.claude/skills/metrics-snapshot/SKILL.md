---
name: metrics-snapshot
description: Write one row of numbers to the metrics ledger. The most important scheduled job.
group: core
tier: 1
ceiling: 1
mode: sequence
needs: []
better-with: [case-system]
---

# Metrics snapshot

Runs daily at 23:00. Tier 1: free to do.

This is the quietest job here and the most valuable. From the day this starts running you
are manufacturing the time series that makes year-on-year comparison possible later.
Never skip it.

**This runs as a script** once one exists for the install, for example
`scripts/snapshot.py`. The script appends one row to `data/metrics.csv` and prints OK or
the error. You read one line, not a wide table.

**Case counts come from the live cases CSV,** fetched through the `case-system` skill's
bulk route, `scripts/cases_fetch.py` (see "Bulk reads and counts" in `case-system`), into
a temporary file outside this folder, and deleted at the end of the run whether it
succeeded or not. This job never calls the case system directly. Mailbox counts come from
the connected mailbox, and tracker counts from `state/` and the tracker scripts.

**Until a snapshot script exists,** write the row by hand, carefully, from only what can
be counted without reading records into the conversation:

- From the live cases CSV, counted in a short script or one-line command, not read row by
  row: `cases_live`, `cases_waiting_client`, `cases_waiting_lender`, and `offers_issued`
  and `completions` only where the CSV's status and dates show them for today.
- From `python scripts/chase_due.py --cases-input <the same temp file>`: `cases_overdue`,
  the count of OVERDUE lines.
- From `state/`: `invoices_outstanding` (open `job:invoicing` chasers in
  `state/chasers.md`) and `approvals_pending` (open lines in `state/approvals.md`).

Every other column is `NA` until the script exists or a source for it is connected.
Never estimated, never carried over from yesterday. If the fetch fails, the case columns
are `NA` too.

## The columns

The header is the one in `data/metrics.template.csv`, and every enabled pack uses the same
row. Every figure is a count, retrieved from a connected system or a tracker file. Never
people.

| Column | Where the count comes from |
|---|---|
| `date` | Today |
| `enquiries_new` | New enquiries logged in the case system today |
| `cases_live` | Cases open in the case system |
| `cases_waiting_client` | Live cases waiting on the client, from the case system plus `state/cases.md` |
| `cases_waiting_lender` | Live cases waiting on a lender, from the same sources |
| `cases_overdue` | Cases `scripts/chase_due.py` reports as OVERDUE today |
| `docs_requested` | Document requests sent today, from the sent folder or `state/chasers.md` |
| `docs_received` | Client documents received and filed today, as confirmed by `upload_document` |
| `applications_prepared` | Application packs or portal entries prepared today and left for review |
| `offers_issued` | Mortgage offers received today |
| `completions` | Cases completed today |
| `invoices_outstanding` | Open `job:invoicing` chasers in `state/chasers.md` |
| `chasers_sent` | Chasers confirmed in the sent folder today |
| `approvals_pending` | Open lines in `state/approvals.md` |
| `messages_triaged` | Messages the inbox runs handled today |

A column with no connected source is `NA` until one exists. A pack whose metric is not
in the row does not get an invented column: see `knowledge/strategies/registry.md` and the
pack's `PACK.md`, and raise it with {{OPERATOR_NAME}} if a pack needs something the row
does not hold.

Never edit a past row. If a figure cannot be retrieved, write `NA`, never a guess.

## Rules

- Pull everything live. Nothing from cache.
- One row per day, no duplicates. Check the last row's date first.
- If the job misses a day, write the missed row with `NA` where you cannot backfill, and
  note it.
- Counts only. If a client could be identified from a row, it does not belong here. See
  `DATA-HANDLING.md`.
- Never invent a figure to fill a cell. Not a loan amount, not a fee, not a count.
