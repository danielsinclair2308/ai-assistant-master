---
name: knowledge-review
description: Quarterly check that the rules the assistant works from are still true.
group: core
tier: 1
ceiling: 1
mode: sequence
needs: []
better-with: []
---

# Knowledge review

Runs quarterly, folded into a Monday weekly run. Tier 1: asks, and never edits a knowledge
file itself.

Load: everything in `knowledge/`, reaching the lenders through `knowledge/lenders/index.md`
rather than opening every lender file at once

Fees change. A lender leaves the panel or changes how it takes submissions. A document
checklist gains an item the adviser now always asks for. The firm's risk wording is
updated by compliance support. None of it announces itself, so without this job the
assistant is quietly working off March's fee table in November and nobody has noticed.

This is the slowest failure mode in the whole system and the hardest to spot from outside,
because everything keeps running and the answers just get gradually wronger.

## What to do

Go through each knowledge file and produce **one email to {{OPERATOR_NAME}}**, copying
{{OWNER_NAME}} where a fee, the risk wording or anything regulated is involved, with a
short list. Not a file per section, not a conversation. One list they can answer in five
minutes.

For each figure that is actually filled in (not still `[[FILL]]`), show what is held and
ask whether it still holds. Match the enabled packs:

> The residential broker fee is recorded as the figure in `knowledge/fees.md`. Still right?
> One lender file says applications go through its portal. Still the route you use?
> The core document checklist asks for 3 months' payslips. Still what you ask for?

**Ask about the things most likely to have moved first.** Fees, the lender panel and how
each lender takes submissions, document checklists, the risk wording in
`knowledge/messaging.md`, the invoice template, and connected tools.

## Also check

- Any `[[FILL: ...]]` markers still outstanding, and whether they now matter
- Lenders appearing in recent cases with no file in `knowledge/lenders/`, or a file for a
  lender nobody has used in a year
- Whether the lenders index is current. Run `python scripts/index-knowledge.py --check`,
  and if it reports drift, run it without `--check` to rebuild. Never edit an index by hand
- Whether the notes in `knowledge/systems/` still describe how the case system actually
  connects
- Whether the exemptions under Exemptions in `AUTONOMY.md` are still wanted
- Whether the product mix in `knowledge/business.md` still matches the packs enabled in
  `state/enabled-packs.md`

## Rules

- **Never edit a knowledge file yourself.** These are the humans' rules. Propose the
  change with the exact wording; a human applies it. Log the proposal and the answer in
  `state/decisions.md`.
- Lender criteria notes are what the broker was told at the time. Never present one as
  current criteria. Say when it was recorded.
- If {{OPERATOR_NAME}} does not reply, ask once more the following week, then carry the
  outstanding items into the weekly report until they are dealt with. Do not keep working
  off a figure they have been told is stale without saying so each time.
- Where a figure has changed materially, say what it means. "A fee change means every
  invoice drafted since would have been flagged as a mismatch against the ESIS."
- Also check `state/` for personal data heavier than a first name that has crept in,
  per `DATA-HANDLING.md`, and flag it to {{OPERATOR_NAME}} as a mistake to correct going
  forward. Nothing in `state/` is deleted or rewritten: the fix is to stop it recurring.
