# Data handling

Brokers must hold client documents and personal data, and it must be tempting to extract
personal details into local files while working a case. That is personal data under UK
GDPR, and {{BUSINESS_NAME}} is the controller for it.

Read this before anything that touches a client, lender or underwriter record.

**This is a practical working policy, not legal advice.** {{OWNER_NAME}} should have the
privacy notice and the lawful basis for marketing confirmed by the firm's compliance
support. What follows is how the assistant behaves in the meantime, and it is
deliberately cautious.

---

## The principle

Hold the least personal data, for the shortest time, in the fewest places.

Every file this assistant writes is a place personal data can end up by accident. The
default is that it does not go in. **The case system and the client folder are the only
homes for personal data.** `state/` and `data/` hold case references, dates, statuses and
counts, and a client's first name only where a note genuinely needs it. A full name never
goes into `state/` or `data/`, because those files are append only and every entry is
archived, never edited or deleted: a name written there stays for good.

## What may be written to files

| Data | Allowed in `state/` or `data/`? |
|---|---|
| Case reference | Yes |
| Client first name, where a note genuinely needs it | Yes, sparingly, but never in `state/decisions.md` or `state/open-items.md`, which take the case reference only |
| Client full name | Never in `state/` or `data/`. Client folder and case system only |
| Client email address | Never in `state/` or `data/`. It lives in the client folder and case system only |
| Staff business email address | Only as a `staff-email` note in the `email` row of `state/connections.md`, recorded at onboarding for checking approval answers. Staff, not client data. Nowhere else |
| Phone number | Never in `state/` or `data/`. Client folder and case system only |
| Postal address | Never in `state/` or `data/`. Client folder and case system only |
| Date of birth | Never in `state/` or `data/`. Client folder and case system only |
| Income | Never in `state/` or `data/`. Client folder and case system only |
| Account numbers | Never in `state/` or `data/`. Client folder and case system only |
| Credit entries | Never in `state/` or `data/`. Client folder and case system only |
| Loan amounts, property values, fees, balances and rates | Never in `state/` or `data/`. Case system, client folder and the documents themselves only; fetched fresh when a job needs them |
| Card details, even partial | Never. Not anywhere, for any reason |

**Metrics are counts, never people.** `data/metrics.csv` holds numbers. If a client could
be identified from a row, it does not belong there.

## Client folder root

Client folders live outside this repository, at a path set at onboarding:
`[[FILL: client folder root path]]`.

That path must sit outside this folder. `scripts/case_folder.py` refuses to create a
client folder inside this repository, and `scripts/backup.py` refuses to back up a client
document, whatever the gitignore says. The client folder and the case system are the
controller's own systems, and this repository never becomes a third home for the same
data.

## Scripts

Any script reading email, WhatsApp, the case system or a lender portal must print case
references and figures, not client names, phone numbers or addresses. The same rule
applies to any script written later: personal data does not get printed unless the job
genuinely cannot work without it.

## Marketing segments

Segments are built from case data, so a client can be in "remortgage due in 90 days"
without their details sitting in a file here. Hold the segment as a query against the
case system, not as a stored list.

Before any campaign:

- Confirm the recipients have a lawful basis to be emailed. If that cannot be confirmed,
  do not send and say why.
- Suppress anyone who has unsubscribed, ever, permanently.
- Suppress anyone with an open complaint.
- Never email someone whose consent status you cannot see.

## Retention

| Where | How long |
|---|---|
| `state/open-items.md` | Kept until the item is closed, then archived. Case reference only, never a name |
| `state/decisions.md` and `outcomes.md` | Keep. They should contain no personal data in the first place |
| `data/metrics.csv` | Keep indefinitely. Counts only |
| Client folder and case system | The firm's normal retention, not the assistant's concern |

`state/` is append only and archived to the business's own private repository, never
edited and never deleted, which is exactly why a full name must never be written there in
the first place: there is no later point at which it gets quietly removed. Once a quarter,
check `state/` for any personal data heavier than a first name that has crept in despite
that, and flag it to {{OPERATOR_NAME}} as a mistake to correct going forward. Nothing in
`state/` is deleted retrospectively; the fix is to stop it recurring, not to rewrite
history.

## Credit reports

Credit reports are special care. They are saved to the client folder only, never pasted
into `state/`, and summarised for the adviser rather than reproduced.

## Subject access requests and breaches

A subject access request, a deletion request, or any question about what is held. **Do
not answer it.** Flag it to {{OWNER_NAME}} immediately and mark it urgent. There are legal
time limits and it needs a person.

Same for anything that looks like a data breach. Say so loudly and immediately, and do not
attempt to fix it quietly.

## Things never to do

- Never move client data to a tool nobody agreed to
- Never put personal data in a URL, a search query, or anything sent to a third party
- Never compile a profile of an individual beyond what the immediate case needs
- Never use client data for anything outside running the case and, with consent, marketing
  {{BUSINESS_NAME}}
- Never include a client's name, photo or story on social or the website without their
  permission being on record

## Where this lives

The client folder sits on a machine in the office, or a synced drive the firm controls.
That is fine, and it means the practical protections are ordinary ones: the machine has a
password, the drive is encrypted, and the sync folder is not shared with anyone outside
the business.

`[[FILL: confirm at setup that the machine is password protected and the drive encrypted]]`
