# AI Assistant, master template

The reusable build behind {{BUSINESS_NAME}}'s mortgage broker AI assistant. This
repository is the **master template only**, for UK mortgage and finance brokers. It never
holds a client's live case folder and it never holds client data.

Each broker install is issued into **that firm's own private GitHub account**. Nothing
phones home.

---

## The important rule

**Client data never enters this repository.** Client folders live outside it, at a path
set at onboarding. `state/` and `data/` in a live install contain operational memory:
case references, dates, statuses and counts, never a client's contact details or
financial detail. The firm is the controller of the client folder and the case system.
`.gitignore` on this template keeps working `state/` and `data/` out; `.gitignore.client`
is swapped in by the issuer so the firm's own private repo backs up their memory. Do not
weaken that design.

---

## Read these first

| File | What it covers |
|---|---|
| `START-HERE.md` | Client-facing first page |
| `CLAUDE.md` | Router loaded every session |
| `AUTONOMY.md` | Permission tiers |
| `COMPLIANCE.md` | Working compliance policy |
| `DATA-HANDLING.md` | Personal data rules |
| `EFFICIENCY.md` | Why the schedule is batched |
| `SCHEDULE.md` | Timetable, completed at onboarding |
| `PACKAGE.md` / `VERSION` | Issuer fingerprints |

---

## Building a client from this

Issuing is done by the issuer, which copies this template into the firm's GitHub account
and applies package fingerprints (`PACKAGE.md`, `VERSION`, the `CLAUDE.md` comment,
`.claude/settings.json`, the commit message, and the gitignore swap).

Placeholders such as `{{BUSINESS_NAME}}`, `{{OWNER_NAME}}` and `{{OPERATOR_NAME}}` may be
filled at issue time or during onboarding.

On the firm's machine: put the issued package on the machine as a complete folder, open
**that folder itself** in Claude (Code, New, Open folder), say hello, complete onboarding.
Opening a parent folder or a new empty folder does not work: Claude only loads
`CLAUDE.md` from the folder it is opened on and the folders above it, never from
subfolders, so without it there is no onboarding.

**Build every client from this template, never from the last client.**

---

## What is in here

```
CLAUDE.md                 Router. Broker rules, onboarding check, routing table
AUTONOMY.md               Permission tiers
COMPLIANCE.md             Working compliance policy, not legal advice
DATA-HANDLING.md          Personal data rules for brokers
EFFICIENCY.md / SCHEDULE.md
START-HERE.md             Client-facing first page
.claude/skills/           Process and core skills loaded on demand
.claude/packs/            Product pack briefs (enable via onboarding)
knowledge/                Human rules; capabilities.md, business.md blank until discovery
knowledge/strategies/     Registry
state/                    Templates only in this repo
data/                     Metrics templates only in this repo
scripts/                  backup, rollup, guard, index-knowledge, chase_due, quote_tracker,
                          expiry_scan, case_folder, invoice, make_invoice_template,
                          trackers, lint_template
PACKAGE.md / VERSION      Issuer provenance
```

---

## Versioning

`VERSION` holds the current template version. Bump it when the structure changes, not for
a typo.

- **Major** when onboarding contract, pack layout, or `state/` / `data/` shape changes in
  a way that existing installs cannot ignore.
- **Minor** for new skills, pack depth, schedule or autonomy tweaks.
- **Patch** for copy fixes that do not change behaviour.

Run `python -m pytest` and `python scripts/lint_template.py` before any release. Both
should come back clean.
