#!/usr/bin/env python3
"""
case_folder.py - create the standard client folder for a case.

The client folder root is set at onboarding and lives OUTSIDE this assistant folder, so
client documents never reach git. This script refuses a root inside it.

Safe to run again: it only creates what is missing. Refuses if the case reference is
already used by a folder with a different client name, because filing a document into
the wrong client's folder is the mistake that matters most here.

Usage:
  python scripts/case_folder.py --root "D:/Clients" --ref C-1042 --name "Smith, Jane"
"""

import argparse
import re
import sys
from pathlib import Path

SUBFOLDERS = (
    "01 ID",
    "02 Income",
    "03 Bank statements",
    "04 Property",
    "05 ESIS and offers",
    "06 Application",
    "07 Credit",
    "08 Correspondence",
    "09 Invoices",
    "10 Compliance",
)
UNSAFE = re.compile(r'[<>:"/\\|?*]')
REF_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*$")


def folder_name(name, ref):
    clean = UNSAFE.sub(" ", name)
    clean = re.sub(r"\s+", " ", clean).strip().rstrip(".")
    clean = clean.replace(" ,", ",")
    return "%s (%s)" % (clean, ref)


def ensure_case_folder(root, ref, name, repo):
    if not REF_RE.match(ref) or ".." in ref:
        raise ValueError("case reference %r may only contain letters, numbers, dot, dash and underscore" % ref)
    clean_name = UNSAFE.sub(" ", name)
    clean_name = re.sub(r"\s+", " ", clean_name).strip().rstrip(".")
    if not clean_name:
        raise ValueError("client name %r has no usable characters" % name)
    root, repo = Path(root).resolve(), Path(repo).resolve()
    if not root.is_dir():
        raise ValueError("client folder root does not exist: %s" % root)
    if root == repo or repo in root.parents:
        raise ValueError("client folder root is inside the assistant folder, so documents "
                         "would reach git: %s" % root)
    target = root / folder_name(name, ref)
    suffix = "(%s)" % ref
    for existing in root.iterdir():
        if existing.is_dir() and existing.name.lower().endswith(suffix.lower()):
            if existing.name.lower() != target.name.lower():
                raise ValueError("case %s is already used by '%s'" % (ref, existing.name))
    created = []
    for sub in SUBFOLDERS:
        path = target / sub
        if not path.is_dir():
            path.mkdir(parents=True)
            created.append(sub)
    return target, created


def main():
    ap = argparse.ArgumentParser(description="Create a standard client case folder.")
    ap.add_argument("--root", required=True)
    ap.add_argument("--ref", required=True)
    ap.add_argument("--name", required=True)
    args = ap.parse_args()
    repo = Path(__file__).resolve().parent.parent
    try:
        folder, created = ensure_case_folder(args.root, args.ref, args.name, repo)
    except ValueError as exc:
        print("case_folder: %s" % exc, file=sys.stderr)
        return 1
    if created:
        print("case_folder: %s, created %d subfolders" % (folder, len(created)))
    else:
        print("case_folder: %s already complete" % folder)
    return 0


if __name__ == "__main__":
    sys.exit(main())
