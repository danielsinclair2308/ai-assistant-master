#!/usr/bin/env python3
"""
guard.py - the size guard. Runs nightly, as part of the 23:00 run.

If a working file in state/ or data/ has grown past the threshold, write one open
item saying which file and that a rollup is due. That is all it does.

It never deletes anything and it never rolls anything up itself. A file growing past
the threshold is information for a human or for the monthly job, not licence to start
moving someone's history around at 23:00.

Archives are excluded. data/archive/metrics-2026.csv is supposed to be large, that is
the entire point of it, and warning about it nightly would train everyone to ignore
the warnings.

It writes the same warning only once. An open item that is already open is not made
more true by being written again, and duplicating it would grow the very file the
guard exists to keep small.

Usage:
  python scripts/guard.py --dry-run
  python scripts/guard.py
"""

import argparse
import datetime as dt
import sys
from pathlib import Path

THRESHOLD_BYTES = 40 * 1024

WATCH = [
    ("state", ("*.md", "*.log")),
    ("data", ("*.csv", "*.md")),
]

MARKER = "size-guard"


def watched_files(root):
    for folder, patterns in WATCH:
        base = root / folder
        if not base.exists():
            continue
        for pattern in patterns:
            for path in sorted(base.glob(pattern)):
                if ".template." in path.name:
                    continue
                yield path


def existing_warnings(text):
    """Files already named in an open size-guard item."""
    named = set()
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith("- [ ]") and MARKER in stripped:
            for token in stripped.replace("|", " ").split():
                token = token.strip("`.,")
                if "/" in token:
                    named.add(token)
    return named


def main():
    ap = argparse.ArgumentParser(description="Flag files that have outgrown their window.")
    ap.add_argument("--root", default=str(Path(__file__).resolve().parent.parent))
    ap.add_argument("--threshold", type=int, default=THRESHOLD_BYTES,
                    help="bytes, default %d" % THRESHOLD_BYTES)
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--today", default=None, help="YYYY-MM-DD, for testing")
    args = ap.parse_args()

    root = Path(args.root).resolve()
    today = args.today or dt.date.today().isoformat()
    items_path = root / "state/open-items.md"
    text = items_path.read_text(encoding="utf-8") if items_path.exists() else ""
    already = existing_warnings(text)

    over = []
    for path in watched_files(root):
        size = path.stat().st_size
        if size > args.threshold:
            over.append((path.relative_to(root).as_posix(), size))

    if not over:
        print("guard: ok. Nothing in state/ or data/ is over %dKB." % (args.threshold // 1024))
        return 0

    new_lines = []
    for rel, size in over:
        if rel in already:
            print("guard: %s is %dKB, already flagged." % (rel, size // 1024))
            continue
        new_lines.append(
            "- [ ] %s | %s | `%s` is %dKB, over the %dKB threshold. A rollup is due: "
            "run `python scripts/rollup.py --dry-run` to see what would move.\n"
            % (today, MARKER, rel, size // 1024, args.threshold // 1024))
        print("guard: %s is %dKB, over threshold. Open item written." % (rel, size // 1024))

    if new_lines and not args.dry_run:
        if text and not text.endswith("\n"):
            text += "\n"
        items_path.parent.mkdir(parents=True, exist_ok=True)
        items_path.write_text(text + "".join(new_lines), encoding="utf-8", newline="\n")
    if new_lines and args.dry_run:
        print("guard: dry run, nothing was written.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
