#!/usr/bin/env python3
"""
rollup.py - move history out of the working files and into archives.

Run monthly, on the 1st, before anything else that month. See SCHEDULE.md.

Why this is a script and not a job the model does by hand: moving two thousand rows
of history means reading two thousand rows of history. Doing that in a conversation
costs more than the problem it solves. The script moves the bytes and prints the
counts. The model reads the counts.

What it does, per the windows in EFFICIENCY.md:

  state/decisions.md    keeps every OPEN decision whatever its age, plus closed ones
                        from the last 30 days. Everything else to
                        state/archive/decisions-YYYY-MM.md
  state/outcomes.md     keeps the last 30 days -> state/archive/outcomes-YYYY-MM.md
  state/learned.md      keeps the last 90 days, anything marked permanent, and
                        anything still awaiting a human
                        -> state/archive/learned-YYYY-Qn.md
  state/runs.log        keeps 7 days -> state/archive/runs-YYYY-MM.log
  state/open-items.md   keeps every open item whatever its age, plus items closed in
                        the last 30 days -> state/archive/open-items-YYYY-MM.md
  state/cases.md, chasers.md, lender-quotes.md, approvals.md, processes.md
                        keep every open line whatever its age, plus closed lines from
                        the last 30 days -> state/archive/<name>-YYYY-MM.md
  data/metrics.csv      keeps 90 days. Older rows go to data/archive/metrics-YYYY.csv
                        in full, and are aggregated into data/metrics-monthly.csv

Nothing is ever deleted. Every entry that leaves a working file lands in an archive
file, unchanged. Each archive gets a factual summary at the top, rewritten from the
file's own contents every run, so it is always true and never drifts.

Usage:
  python scripts/rollup.py --dry-run
  python scripts/rollup.py
"""

import argparse
import csv
import datetime as dt
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

# The windows, in days. Changing these changes what the assistant can see without
# opening an archive, so change them deliberately and say why in the changelog.
DECISIONS_DAYS = 30
OUTCOMES_DAYS = 30
LEARNED_DAYS = 90
RUNS_DAYS = 7
OPEN_ITEMS_DAYS = 30
METRICS_DAYS = 90
TRACKER_DAYS = 30
TRACKER_FILES = ("cases", "chasers", "lender-quotes", "approvals", "processes")

# A decision stays in the working file until it is closed, however old it is. That is
# deliberate: attribution must never lose one. The side effect is that the file is
# bounded by how diligently decisions get checked, not by the window, so count the ones
# that have gone past their check date and say so. Neglect that nobody can see is the
# failure this whole design exists to prevent.
OVERDUE_GRACE_DAYS = 14
OVERDUE_LIMIT = 50

ID_RE = re.compile(r"^##\s+([A-Z])-(\d{8})-(\d+)\s*\|(.*)$")
CHECK_ON_RE = re.compile(r"^-\s*Check on:\s*(\S+)", re.M)
STATUS_RE = re.compile(r"^-\s*Status:\s*(\S+)", re.M)
PERMANENT_RE = re.compile(r"^-\s*Permanent:\s*yes\b", re.M | re.I)
WHY_RE = re.compile(r"^-\s*Why:\s*(.+)$", re.M)
VERDICT_RE = re.compile(r"^-\s*Verdict:\s*([A-Z ]+)", re.M)
CHECKED_RE = re.compile(r"\|\s*checked\s+(\d{4}-\d{2}-\d{2})")
ITEM_RE = re.compile(r"^-\s*\[( |x|X)\]\s*(\d{4}-\d{2}-\d{2})\s*\|(.*)$")

GENERATED = "Written by scripts/rollup.py on {today}. Assistant generated, not a human record."


# ----------------------------------------------------------------- helpers ---

def read(path):
    return path.read_text(encoding="utf-8") if path.exists() else ""


def write(path, text, dry):
    if dry:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8", newline="\n")


def parse_date(s):
    for fmt in ("%Y-%m-%d", "%Y%m%d"):
        try:
            return dt.datetime.strptime(s.strip(), fmt).date()
        except ValueError:
            pass
    return None


def quarter(d):
    return "%d-Q%d" % (d.year, (d.month - 1) // 3 + 1)


def split_entries(text):
    """Return (preamble, [(header_line, body, date, ident), ...])."""
    lines = text.splitlines(keepends=True)
    starts = [i for i, ln in enumerate(lines) if ID_RE.match(ln)]
    if not starts:
        return text, []
    preamble = "".join(lines[: starts[0]])
    entries = []
    for n, start in enumerate(starts):
        end = starts[n + 1] if n + 1 < len(starts) else len(lines)
        chunk = "".join(lines[start:end])
        m = ID_RE.match(lines[start])
        ident = "%s-%s-%s" % (m.group(1), m.group(2), m.group(3))
        entries.append((lines[start], chunk, parse_date(m.group(2)), ident))
    return preamble, entries


def archive_body(existing, new_chunks):
    """Existing archive text minus its summary block, plus the new entries."""
    kept = ""
    if existing:
        pre, entries = split_entries(existing)
        kept = "".join(c for _, c, _, _ in entries)
    return kept + "".join(new_chunks)


def summarise_decisions(text, outcomes_by_id, today):
    _, entries = split_entries(text)
    if not entries:
        return "No decisions in this period."
    status = Counter()
    jobs = Counter()
    whys = Counter()
    reversed_ids = []
    verdicts = Counter()
    for header, body, _, ident in entries:
        parts = [p.strip() for p in header.lstrip("# ").split("|")]
        if len(parts) > 1:
            jobs[parts[1]] += 1
        if len(parts) > 2:
            status[parts[2].upper()] += 1
            if "REVERSED" in parts[2].upper():
                reversed_ids.append(ident)
        why = WHY_RE.search(body)
        if why:
            whys[why.group(1).strip()[:45].rstrip(" ,.")] += 1
        if ident in outcomes_by_id:
            verdicts[outcomes_by_id[ident]] += 1

    bits = ["%d decisions logged" % len(entries)]
    if status:
        bits.append(", ".join("%d %s" % (n, s.lower()) for s, n in status.most_common()))
    lines = ["**Summary.** " + ". ".join(bits) + "."]
    if jobs:
        lines.append("Most active job: %s (%d)." % jobs.most_common(1)[0])
    repeated = [(w, n) for w, n in whys.most_common(3) if n > 1]
    if repeated:
        lines.append("Recurring reasons: " + "; ".join("%s (%d times)" % (w, n) for w, n in repeated) + ".")
    if verdicts:
        lines.append("Checked: " + ", ".join("%d %s" % (n, v.strip().lower()) for v, n in verdicts.most_common()) + ".")
    else:
        lines.append("No outcomes recorded against these yet.")
    if reversed_ids:
        lines.append("Reversed later: " + ", ".join(reversed_ids) + ".")
    else:
        lines.append("None marked reversed.")
    lines.append(GENERATED.format(today=today))
    return "\n".join(lines)


def summarise_outcomes(text, today):
    _, entries = split_entries(text)
    if not entries:
        return "No outcomes in this period."
    verdicts = Counter()
    for _, body, _, _ in entries:
        m = VERDICT_RE.search(body)
        if m:
            verdicts[m.group(1).strip()] += 1
    total = sum(verdicts.values()) or 1
    worked = verdicts.get("WORKED", 0)
    lines = ["**Summary.** %d outcomes recorded. " % len(entries)
             + ", ".join("%d %s" % (n, v.lower()) for v, n in verdicts.most_common()) + "."]
    lines.append("Hit rate %d%% of those with a verdict." % round(100.0 * worked / total))
    lines.append("The misses are the useful part of this file. They are listed below in full.")
    lines.append(GENERATED.format(today=today))
    return "\n".join(lines)


def summarise_learned(text, today):
    _, entries = split_entries(text)
    if not entries:
        return "No learnings in this period."
    status = Counter()
    topics = Counter()
    for header, body, _, _ in entries:
        parts = [p.strip() for p in header.lstrip("# ").split("|")]
        if len(parts) > 1:
            topics[parts[1]] += 1
        m = STATUS_RE.search(body)
        if m:
            status[m.group(1).upper()] += 1
    lines = ["**Summary.** %d observations." % len(entries)]
    if status:
        lines.append("Status: " + ", ".join("%d %s" % (n, s.lower()) for s, n in status.most_common()) + ".")
    repeated = [(t, n) for t, n in topics.most_common(3) if n > 1]
    if repeated:
        lines.append("Most observed: " + "; ".join("%s (%d)" % (t, n) for t, n in repeated) + ".")
    lines.append("Everything here is an inference the assistant made, never a rule it was given.")
    lines.append(GENERATED.format(today=today))
    return "\n".join(lines)


def summarise_lines(kind, lines_moved, today, extra=""):
    return "**Summary.** %d %s.%s\n%s" % (len(lines_moved), kind,
                                          (" " + extra) if extra else "",
                                          GENERATED.format(today=today))


def emit_archive(path, title, summary, body, dry, report, root=None):
    text = "# %s\n\n> %s\n\n---\n\n%s" % (title, summary.replace("\n", "\n> "), body)
    if not text.endswith("\n"):
        text += "\n"
    write(path, text, dry)
    report.append("  archive %s" % (path.relative_to(root).as_posix() if root else path.name))


# ------------------------------------------------------------ entry files ---

def roll_entry_file(root, rel, days, archive_pattern, summarise, today, dry, report,
                    keep_open=None, extra_keep=None):
    path = root / rel
    text = read(path)
    if not text.strip():
        return 0
    preamble, entries = split_entries(text)
    if not entries:
        return 0

    keep, move = [], []
    for header, body, date, ident in entries:
        if date is None:
            keep.append((header, body, date, ident))
            continue
        if keep_open and keep_open(ident, body, header):
            keep.append((header, body, date, ident))
            continue
        if extra_keep and extra_keep(body):
            keep.append((header, body, date, ident))
            continue
        if (today - date).days <= days:
            keep.append((header, body, date, ident))
        else:
            move.append((header, body, date, ident))

    if not move:
        return 0

    by_bucket = defaultdict(list)
    for header, body, date, ident in move:
        by_bucket[archive_pattern(date)].append((header, body, date, ident))

    for bucket, chunks in sorted(by_bucket.items()):
        apath = root / bucket
        merged = archive_body(read(apath), [c for _, c, _, _ in chunks])
        title = "%s, %s" % (rel.split("/")[-1].replace(".md", "").capitalize(), bucket.split("-", 1)[1].replace(".md", ""))
        emit_archive(apath, title, summarise(merged, today), merged, dry, report, root)

    write(path, preamble + "".join(c for _, c, _, _ in keep), dry)
    report.append("  %-22s %d moved, %d kept" % (rel, len(move), len(keep)))
    return len(move)


# --------------------------------------------------------------- log lines ---

def roll_line_file(root, rel, days, archive_pattern, kind, today, dry, report, is_open=None):
    path = root / rel
    text = read(path)
    if not text.strip():
        return 0
    lines = text.splitlines(keepends=True)
    keep, move = [], []
    for ln in lines:
        d = None
        m = ITEM_RE.match(ln)
        if m:
            if is_open and m.group(1) == " ":
                keep.append(ln)
                continue
            d = parse_date(m.group(2))
        else:
            m2 = re.match(r"^(\d{4}-\d{2}-\d{2})[ T]", ln)
            if m2:
                d = parse_date(m2.group(1))
        if d is None:
            keep.append(ln)
        elif (today - d).days <= days:
            keep.append(ln)
        else:
            move.append(ln)

    if not move:
        return 0

    by_bucket = defaultdict(list)
    for ln in move:
        m = ITEM_RE.match(ln) or re.match(r"^(\d{4}-\d{2}-\d{2})[ T]", ln)
        d = parse_date(m.group(2) if ITEM_RE.match(ln) else m.group(1))
        by_bucket[archive_pattern(d)].append(ln)

    for bucket, moved in sorted(by_bucket.items()):
        apath = root / bucket
        existing = read(apath)
        body = existing.split("---\n", 1)[-1] if existing.startswith("#") else existing
        merged = body + "".join(moved)
        title = bucket.split("/")[-1].replace(".md", "").replace(".log", "")
        if apath.suffix == ".log":
            write(apath, merged, dry)
            report.append("  archive %s" % apath.relative_to(root).as_posix())
        else:
            emit_archive(apath, title, summarise_lines(kind, moved, today), merged, dry, report, root)

    write(path, "".join(keep), dry)
    report.append("  %-22s %d moved, %d kept" % (rel, len(move), len(keep)))
    return len(move)


# ----------------------------------------------------------------- metrics ---

SUM_COLS = ["enquiries_new", "docs_requested", "docs_received", "applications_prepared",
            "offers_issued", "completions", "chasers_sent", "messages_triaged"]
MEAN_COLS = []
LAST_COLS = ["cases_live", "cases_waiting_client", "cases_waiting_lender", "cases_overdue",
             "invoices_outstanding", "approvals_pending"]


def num(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def aggregate_month(rows, header):
    out = {}
    for col in header:
        if col == "date":
            continue
        vals = [num(r.get(col)) for r in rows]
        vals = [v for v in vals if v is not None]
        if col in SUM_COLS:
            out[col] = round(sum(vals), 2) if vals else "NA"
        elif col in MEAN_COLS:
            out[col] = round(sum(vals) / len(vals), 2) if vals else "NA"
        elif col in LAST_COLS:
            last = [num(r.get(col)) for r in rows if num(r.get(col)) is not None]
            out[col] = round(last[-1], 2) if last else "NA"
        else:
            out[col] = "NA"
    for col in SUM_COLS + LAST_COLS:
        if col in out and isinstance(out[col], float) and out[col].is_integer():
            out[col] = int(out[col])
    return out


def roll_metrics(root, today, dry, report):
    path = root / "data/metrics.csv"
    if not path.exists():
        return 0
    with path.open(encoding="utf-8", newline="") as fh:
        reader = csv.DictReader(fh)
        header = reader.fieldnames or []
        rows = [r for r in reader]
    if not header or not rows:
        return 0

    keep, move = [], []
    for r in rows:
        d = parse_date(r.get("date", "") or "")
        (keep if d is None or (today - d).days <= METRICS_DAYS else move).append(r)
    if not move:
        return 0

    # Full raw detail into the yearly archive, deduplicated by date.
    by_year = defaultdict(list)
    for r in move:
        by_year[parse_date(r["date"]).year].append(r)
    for year, yrows in sorted(by_year.items()):
        apath = root / ("data/archive/metrics-%d.csv" % year)
        existing = {}
        if apath.exists():
            with apath.open(encoding="utf-8", newline="") as fh:
                for r in csv.DictReader(fh):
                    existing[r.get("date")] = r
        for r in yrows:
            existing[r["date"]] = r
        if not dry:
            apath.parent.mkdir(parents=True, exist_ok=True)
            with apath.open("w", encoding="utf-8", newline="") as fh:
                w = csv.DictWriter(fh, fieldnames=header)
                w.writeheader()
                for d in sorted(existing):
                    w.writerow(existing[d])
        report.append("  archive data/archive/metrics-%d.csv (%d rows total)" % (year, len(existing)))

    # Rebuild the monthly file from everything we hold, for complete months only.
    all_rows = {}
    for apath in sorted((root / "data/archive").glob("metrics-*.csv")) if (root / "data/archive").exists() else []:
        with apath.open(encoding="utf-8", newline="") as fh:
            for r in csv.DictReader(fh):
                all_rows[r.get("date")] = r
    for r in move + keep:
        all_rows[r["date"]] = r
    this_month = today.strftime("%Y-%m")
    by_month = defaultdict(list)
    for d in sorted(all_rows):
        month = (d or "")[:7]
        if month and month < this_month:
            by_month[month].append(all_rows[d])
    mpath = root / "data/metrics-monthly.csv"
    if not dry:
        mpath.parent.mkdir(parents=True, exist_ok=True)
        with mpath.open("w", encoding="utf-8", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=header)
            w.writeheader()
            for month in sorted(by_month):
                row = aggregate_month(by_month[month], header)
                row["date"] = month
                w.writerow(row)
    report.append("  data/metrics-monthly.csv rebuilt, %d months" % len(by_month))

    if not dry:
        with path.open("w", encoding="utf-8", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=header)
            w.writeheader()
            for r in keep:
                w.writerow(r)
    report.append("  %-22s %d moved, %d kept" % ("data/metrics.csv", len(move), len(keep)))
    return len(move)


# -------------------------------------------------------------------- main ---

def load_outcome_verdicts(root):
    """Decision ID -> verdict, from the current outcomes file and every outcomes archive."""
    out = {}
    paths = [root / "state/outcomes.md"]
    adir = root / "state/archive"
    if adir.exists():
        paths += sorted(adir.glob("outcomes-*.md"))
    for p in paths:
        _, entries = split_entries(read(p))
        for _, body, _, ident in entries:
            m = VERDICT_RE.search(body)
            out[ident] = m.group(1).strip() if m else "no verdict"
    return out


def learning_still_live(body):
    """Keep a learning in the window if it is marked permanent, or if a human still
    owes it an answer. Windowing by status, not by age alone, is the same rule that
    keeps an unchecked decision out of the archive."""
    if PERMANENT_RE.search(body):
        return True
    m = STATUS_RE.search(body)
    return bool(m) and m.group(1).upper() in ("ASKED", "UNANSWERED")


def overdue_open_decisions(root, today, is_open):
    """Open decisions whose check date passed more than the grace period ago."""
    _, entries = split_entries(read(root / "state/decisions.md"))
    overdue = []
    for header, body, _, ident in entries:
        if not is_open(ident, body, header):
            continue
        m = CHECK_ON_RE.search(body)
        if not m:
            continue
        due = parse_date(m.group(1))
        if due and (today - due).days > OVERDUE_GRACE_DAYS:
            overdue.append((ident, (today - due).days))
    return sorted(overdue, key=lambda x: -x[1])


def flag_backlog(root, overdue, today, dry, report):
    """One open item, once, when the unchecked backlog gets large enough to matter."""
    marker = "attribution-backlog"
    path = root / "state/open-items.md"
    text = read(path)
    for line in text.splitlines():
        if line.strip().startswith("- [ ]") and marker in line:
            report.append("  %d decisions overdue for a check, already flagged" % len(overdue))
            return
    line = ("- [ ] %s | %s | %d decisions are open past their check date, the oldest by %d days. "
            "They stay in `state/decisions.md` until attribution gives them a verdict, so the file "
            "keeps growing until it does. Either the attribution job is not running, or these need "
            "closing as CANNOT TELL.\n"
            % (today.isoformat(), marker, len(overdue), overdue[0][1]))
    if not dry:
        if text and not text.endswith("\n"):
            text += "\n"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text + line, encoding="utf-8", newline="\n")
    report.append("  %d decisions overdue for a check, open item written" % len(overdue))


def run(root, today, dry):
    report = []
    verdicts = load_outcome_verdicts(root)

    def decision_is_open(ident, body, header):
        if "DECLINED" in header.upper():
            return False
        m = CHECK_ON_RE.search(body)
        if m and m.group(1).lower().rstrip(".") == "none":
            return False
        return ident not in verdicts

    moved = 0
    moved += roll_entry_file(
        root, "state/decisions.md", DECISIONS_DAYS,
        lambda d: "state/archive/decisions-%s.md" % d.strftime("%Y-%m"),
        lambda text, t: summarise_decisions(text, verdicts, t),
        today, dry, report, keep_open=decision_is_open)

    moved += roll_entry_file(
        root, "state/outcomes.md", OUTCOMES_DAYS,
        lambda d: "state/archive/outcomes-%s.md" % d.strftime("%Y-%m"),
        summarise_outcomes, today, dry, report)

    moved += roll_entry_file(
        root, "state/learned.md", LEARNED_DAYS,
        lambda d: "state/archive/learned-%s.md" % quarter(d),
        summarise_learned, today, dry, report, extra_keep=learning_still_live)

    moved += roll_line_file(
        root, "state/runs.log", RUNS_DAYS,
        lambda d: "state/archive/runs-%s.log" % d.strftime("%Y-%m"),
        "run lines", today, dry, report)

    moved += roll_line_file(
        root, "state/open-items.md", OPEN_ITEMS_DAYS,
        lambda d: "state/archive/open-items-%s.md" % d.strftime("%Y-%m"),
        "closed items", today, dry, report, is_open=True)

    for name in TRACKER_FILES:
        moved += roll_line_file(
            root, "state/%s.md" % name, TRACKER_DAYS,
            lambda d, n=name: "state/archive/%s-%s.md" % (n, d.strftime("%Y-%m")),
            "closed tracker lines", today, dry, report, is_open=True)

    moved += roll_metrics(root, today, dry, report)

    overdue = overdue_open_decisions(root, today, decision_is_open)
    if len(overdue) > OVERDUE_LIMIT:
        flag_backlog(root, overdue, today, dry, report)
    elif overdue:
        report.append("  %d decisions overdue for a check, under the limit of %d"
                      % (len(overdue), OVERDUE_LIMIT))
    return moved, report


def main():
    ap = argparse.ArgumentParser(description="Move history into archives. See EFFICIENCY.md.")
    ap.add_argument("--root", default=str(Path(__file__).resolve().parent.parent),
                    help="the assistant folder. Defaults to the parent of scripts/")
    ap.add_argument("--dry-run", action="store_true", help="say what would move, move nothing")
    ap.add_argument("--today", default=None, help="YYYY-MM-DD, for testing")
    args = ap.parse_args()

    root = Path(args.root).resolve()
    today = parse_date(args.today) if args.today else dt.date.today()
    if today is None:
        print("rollup: --today must be YYYY-MM-DD", file=sys.stderr)
        return 2
    if not (root / "state").exists():
        print("rollup: no state/ folder under %s" % root, file=sys.stderr)
        return 2

    moved, report = run(root, today, args.dry_run)
    label = "would move" if args.dry_run else "moved"
    if moved == 0:
        print("rollup: nothing to move. Everything is inside its window.")
        for line in report:
            print(line)
        return 0
    print("rollup: %s %d entries as at %s" % (label, moved, today))
    for line in report:
        print(line)
    if args.dry_run:
        print("rollup: dry run, nothing was written.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
