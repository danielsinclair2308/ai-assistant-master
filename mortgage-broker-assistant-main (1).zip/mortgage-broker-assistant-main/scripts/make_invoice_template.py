#!/usr/bin/env python3
"""
make_invoice_template.py - regenerate knowledge/templates/invoice.docx.

Template maintainers only. A client's broker edits the generated file in Word to add
their letterhead and payment details, replacing each [[FILL]] line. Fields in <<...>>
are filled by invoice.py and must stay in one piece.
"""

from pathlib import Path

from docx import Document

OUT = Path(__file__).resolve().parent.parent / "knowledge/templates/invoice.docx"


def build(path=OUT):
    doc = Document()
    doc.add_heading("Invoice", level=0)
    doc.add_paragraph("[[FILL: your business name, address and FCA number]]")
    doc.add_paragraph("Invoice number: <<INVOICE_NUMBER>>")
    doc.add_paragraph("Date: <<INVOICE_DATE>>")
    doc.add_paragraph("Payment due by: <<DUE_DATE>>")
    doc.add_paragraph("Case reference: <<CASE_REF>>")
    doc.add_paragraph("Billed to: <<CLIENT_NAME>>")
    table = doc.add_table(rows=2, cols=2)
    table.cell(0, 0).text = "Description"
    table.cell(0, 1).text = "Amount"
    table.cell(1, 0).text = "<<DESCRIPTION>>"
    table.cell(1, 1).text = "<<FEE>>"
    doc.add_paragraph("[[FILL: VAT wording, usually that the fee is exempt from VAT]]")
    doc.add_paragraph("[[FILL: payment details, typed by you, never by the assistant]]")
    path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(path))
    return path


if __name__ == "__main__":
    print("make_invoice_template: wrote %s" % build())
