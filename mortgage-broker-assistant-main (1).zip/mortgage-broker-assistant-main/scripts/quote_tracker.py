#!/usr/bin/env python3
"""
quote_tracker.py - which lenders have come back on a case, and which have not.

Reads state/lender-quotes.md. For each case with open quote lines, prints who replied,
who is outstanding and for how long, and whether the case is READY for the adviser to
decide: every lender asked has replied, or the deadline has passed.

It does not rank or compare rates. That is the adviser's decision, with fees and
criteria in view.

Usage:
  python scripts/quote_tracker.py
  python scripts/quote_tracker.py --case C-1042
"""

import argparse
import datetime as dt
import sys
from collections import OrderedDict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import trackers  # noqa: E402


def summary(root, today, case=None):
    entries = trackers.load(Path(root) / "state/lender-quotes.md", "quote")
    current = trackers.latest(entries, key=lambda e: (e["ref"], e.get("lender", "")))
    by_case = OrderedDict()
    for (ref, _lender), e in current.items():
        if not e["open"] or (case and ref != case):
            continue
        by_case.setdefault(ref, []).append(e)

    out = []
    for ref, quotes in by_case.items():
        replied = [q for q in quotes if trackers.as_date(q.get("replied", ""))]
        waiting = [q for q in quotes if not trackers.as_date(q.get("replied", ""))]
        deadlines = [d for d in (trackers.as_date(q.get("deadline", "")) for q in quotes) if d]
        deadline = min(deadlines) if deadlines else None
        if not waiting:
            status = "READY"
        elif deadline and today > deadline:
            status = "READY (deadline passed)"
        else:
            status = "WAITING"
        when = "deadline %s" % deadline.isoformat() if deadline else "no deadline"
        out.append("%s  %s  %d of %d replied, %s" % (ref, status, len(replied), len(quotes), when))
        if replied:
            out.append("  replied: %s" % ", ".join(q["lender"] for q in replied))
        if waiting:
            parts = []
            for q in waiting:
                asked = trackers.as_date(q.get("asked", "")) or q["date"]
                parts.append("%s (%d days)" % (q["lender"], (today - asked).days))
            out.append("  outstanding: %s" % ", ".join(parts))
    return out


def main():
    ap = argparse.ArgumentParser(description="Lender reply tracker.")
    ap.add_argument("--root", default=str(Path(__file__).resolve().parent.parent))
    ap.add_argument("--case", default=None)
    ap.add_argument("--today", default=None)
    args = ap.parse_args()
    today = trackers.as_date(args.today) if args.today else dt.date.today()
    if today is None:
        print("quote_tracker: --today must be YYYY-MM-DD", file=sys.stderr)
        return 2
    lines = summary(args.root, today, args.case)
    print("\n".join(lines) if lines else "quote_tracker: no open quote requests")
    return 0


if __name__ == "__main__":
    sys.exit(main())
