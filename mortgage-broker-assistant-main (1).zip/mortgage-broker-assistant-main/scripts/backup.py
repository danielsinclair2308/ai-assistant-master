#!/usr/bin/env python3
"""
backup.py - commit anything that changed today and push it. Runs nightly.

Everything this assistant knows lives in this folder. `state/` holds every decision it
has made and everything it has worked out; `data/` holds every night's numbers since the
day it started. None of that can be rebuilt if the machine dies, and none of it is
anywhere else.

So it goes to your own private repository, in your own GitHub account, every night.

**This runs without asking.** A backup that asks permission is a backup that does not
happen, and pushing your own files to your own repository is not a decision that needs
supervising. It is also the only job here that behaves that way, which is deliberate:
everything else that touches the outside world asks first.

It will not commit anything that looks like a credential, whatever the gitignore says.
That check is here rather than only in `.gitignore` because a gitignore can be edited by
accident and a password pushed to a repository has to be treated as burned even after it
is deleted.

Usage:
  python scripts/backup.py
  python scripts/backup.py --dry-run
"""

import argparse
import datetime as dt
import re
import subprocess
import sys
from pathlib import Path

# Anything matching these is never committed, whatever .gitignore says.
CREDENTIAL_PATTERNS = [
    re.compile(r"(^|/)\.env($|\.)", re.I),
    re.compile(r"\.(key|pem|p12|pfx|token)$", re.I),
    re.compile(r"(^|/)(credentials|secrets|service-account|client_secret)[^/]*\.json$", re.I),
]

# Client documents live in the client folder root, outside this folder. If one turns up
# here, it is a mistake, and committing it would put a client's passport in git history.
DOCUMENT_PATTERNS = [re.compile(r"\.(pdf|jpe?g|png|heic|docx?|xlsx?)$", re.I)]
DOCUMENT_ALLOWED_PREFIX = "knowledge/templates/"


def document_like(paths):
    return [p for p in paths
            if not p.startswith(DOCUMENT_ALLOWED_PREFIX)
            and any(pattern.search(p) for pattern in DOCUMENT_PATTERNS)]


OPEN_ITEM = ("- [ ] %s | backup | The nightly backup could not push to your repository. "
             "Your assistant's memory is not backed up until this is fixed. %s\n")


def git(args, cwd, check=True, timeout=180):
    result = subprocess.run(["git", *args], cwd=str(cwd), capture_output=True, text=True,
                            timeout=timeout)
    if check and result.returncode != 0:
        raise RuntimeError("git %s failed: %s" % (" ".join(args[:2]),
                                                  (result.stderr or result.stdout).strip()))
    return result.stdout.strip()


def flag(root: Path, message: str) -> None:
    path = root / "state" / "open-items.md"
    line = OPEN_ITEM % (dt.date.today().isoformat(), message)
    try:
        existing = path.read_text(encoding="utf-8") if path.exists() else ""
        if "| backup |" in existing and message[:40] in existing:
            return
        path.parent.mkdir(parents=True, exist_ok=True)
        if existing and not existing.endswith("\n"):
            existing += "\n"
        path.write_text(existing + line, encoding="utf-8", newline="\n")
    except OSError:
        pass


def credential_like(paths):
    return [p for p in paths if any(pattern.search(p) for pattern in CREDENTIAL_PATTERNS)]


def main():
    parser = argparse.ArgumentParser(description="Commit and push tonight's changes.")
    parser.add_argument("--root", default=str(Path(__file__).resolve().parent.parent))
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    root = Path(args.root).resolve()

    if not (root / ".git").exists():
        print("backup: this folder is not a git repository, so there is nothing to push to.")
        print("        Your assistant's memory is not backed up anywhere.")
        flag(root, "This folder is not a git repository.")
        return 1

    try:
        remote = git(["remote", "get-url", "origin"], root)
    except RuntimeError:
        print("backup: no origin remote, so there is nowhere to push.")
        flag(root, "There is no origin remote configured.")
        return 1

    changed = git(["status", "--porcelain", "--untracked-files=all"], root)
    if not changed:
        print("backup: nothing changed today.")
        return 0

    paths = [line[3:].strip().strip('"') for line in changed.splitlines() if line.strip()]
    risky = credential_like(paths)
    if risky:
        print("backup: refusing to commit, these look like credentials:")
        for path in risky:
            print("  %s" % path)
        print("        Move them outside this folder, or add them to .gitignore, then re-run.")
        flag(root, "Files that look like credentials are in the folder: %s" % ", ".join(risky[:3]))
        return 1

    docs = document_like(paths)
    if docs:
        print("backup: refusing to commit, these look like client documents:")
        for path in docs:
            print("  %s" % path)
        print("        Client documents belong in the client folder root, never in here.")
        flag(root, "Files that look like client documents are in the folder: %s" % ", ".join(docs[:3]))
        return 1

    stamp = dt.datetime.now().strftime("%Y-%m-%d")
    message = "Backup %s (%d file%s)" % (stamp, len(paths), "" if len(paths) == 1 else "s")

    if args.dry_run:
        print("backup: would commit %d file(s) and push to %s" % (len(paths), remote))
        for path in paths[:20]:
            print("  %s" % path)
        return 0

    try:
        git(["add", "-A", "--", "."], root)
        staged = git(["diff", "--cached", "--name-only"], root)
        if not staged:
            print("backup: everything that changed is ignored, nothing to commit.")
            return 0
        git(["-c", "user.name=Assistant", "-c", "user.email=assistant@localhost",
             "commit", "--quiet", "-m", message], root)
    except RuntimeError as exc:
        print("backup: could not commit: %s" % exc)
        flag(root, "The nightly commit failed.")
        return 1

    try:
        branch = git(["rev-parse", "--abbrev-ref", "HEAD"], root)
        git(["push", "--quiet", "origin", branch], root, timeout=300)
    except RuntimeError as exc:
        print("backup: committed locally but could not push: %s" % exc)
        print("        The commit is safe on this machine. It is not backed up until it pushes.")
        flag(root, "The push failed, so tonight's work is only on this machine. "
                   "It usually means the GitHub sign in needs renewing.")
        return 1

    print("backup: %s pushed to %s" % (message, remote))
    return 0


if __name__ == "__main__":
    sys.exit(main())
