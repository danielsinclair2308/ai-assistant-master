#!/usr/bin/env python3
"""
lint_template.py - check the template keeps its own promises.

Runs in the test suite and before every release. It checks that every skill has the
frontmatter the assistant and onboarding rely on, that the tiers in each skill agree
with AUTONOMY.md, that no skill outside the adapter names a case system, that only the
known placeholders are used, that no em dash has crept in, and that no personal data
sits in the files that ship.

Prints one problem per line. Exit 0 when clean, 1 otherwise.

Usage:
  python scripts/lint_template.py
  python scripts/lint_template.py --root PATH
"""

import argparse
import re
import sys
from pathlib import Path

REQUIRED_KEYS = ("name", "description", "group", "tier", "ceiling", "mode", "needs", "better-with")
VALID_TIERS = {"1", "2", "3", "4", "inherit"}
VALID_MODES = {"sequence", "trigger", "both", "once"}
VALID_GROUPS = {"process", "core", "adapter"}
PROCESS_HEADINGS = ("## Steps", "## Approval points", "## Never", "## Writes to")
KNOWN_PLACEHOLDERS = {"BUSINESS_NAME", "OWNER_NAME", "OPERATOR_NAME"}
VENDORS = ("Intelliflo", "Acre", "Mortgage Brain", "Twenty7tec", "Salesforce",
           "Airtable", "Xplan", "Iress")
VENDOR_ALLOWED = {"case-system", "onboarding", "connections"}
TEXT_SUFFIXES = {".md", ".py", ".csv", ".json", ".txt", ".ini"}
# docs/ holds design notes and tests/ holds deliberate bad examples; neither ships to a client
SKIP_DIRS = {".git", "__pycache__", ".pytest_cache", ".venv", "docs", "tests", ".superpowers"}
PERSONAL_DIRS = ("knowledge", "state", "data")

EM_DASH = "\u2014"
FM_RE = re.compile(r"\A---\n(.*?)\n---\n", re.S)
PLACEHOLDER_RE = re.compile(r"\{\{([A-Z_]+)\}\}")
CAP_ROW_RE = re.compile(r"^\|\s*`([a-z0-9-]+)`\s*\|")
AUT_ROW_RE = re.compile(r"^\|\s*`([a-z0-9-]+)`\s*\|\s*([^|]+?)\s*\|\s*([^|]+?)\s*\|")
EMAIL_RE = re.compile(r"\b[\w.+-]+@([\w-]+\.)+[a-z]{2,}\b", re.I)
PHONE_RE = re.compile(r"(?<!\d)(?:\+44\s?7\d{3}|07\d{3})\s?\d{3}\s?\d{3}(?!\d)")
SAFE_EMAIL_DOMAINS = ("example.com", "example.co.uk", "example.org")


def read(path):
    return path.read_text(encoding="utf-8").replace("\r\n", "\n")


def parse_frontmatter(text):
    m = FM_RE.match(text.replace("\r\n", "\n"))
    if not m:
        return None
    out = {}
    for line in m.group(1).splitlines():
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        key, sep, val = line.partition(":")
        if not sep:
            continue
        val = val.strip()
        if val.startswith("[") and val.endswith("]"):
            out[key.strip()] = [v.strip() for v in val[1:-1].split(",") if v.strip()]
        else:
            out[key.strip()] = val
    return out


def load_capabilities(root):
    path = root / "knowledge/capabilities.md"
    if not path.exists():
        return set()
    return {m.group(1) for m in map(CAP_ROW_RE.match, read(path).splitlines()) if m}


def load_autonomy(root):
    path = root / "AUTONOMY.md"
    if not path.exists():
        return {}
    rows = {}
    for line in read(path).splitlines():
        m = AUT_ROW_RE.match(line)
        if m:
            rows[m.group(1)] = (m.group(2), m.group(3))
    return rows


def skill_files(root):
    base = root / ".claude/skills"
    return sorted(base.glob("*/SKILL.md")) if base.exists() else []


def text_files(root):
    for p in sorted(root.rglob("*")):
        if p.is_file() and p.suffix in TEXT_SUFFIXES and not (SKIP_DIRS & set(p.parts)):
            yield p


def check_skills(root, problems):
    caps = load_capabilities(root)
    autonomy = load_autonomy(root)
    seen = set()
    skill_paths = skill_files(root)
    skill_names = {p.parent.name for p in skill_paths}
    for path in skill_paths:
        folder = path.parent.name
        text = read(path)
        fm = parse_frontmatter(text)
        if fm is None:
            problems.append("%s: no frontmatter" % folder)
            continue
        missing = [k for k in REQUIRED_KEYS if k not in fm]
        for k in missing:
            problems.append("%s: missing frontmatter key '%s'" % (folder, k))
        if missing:
            continue
        seen.add(folder)
        if fm["name"] != folder:
            problems.append("%s: name '%s' does not match folder" % (folder, fm["name"]))
        tier, ceiling = fm["tier"], fm["ceiling"]
        for label, val in (("tier", tier), ("ceiling", ceiling)):
            if val not in VALID_TIERS:
                problems.append("%s: invalid %s '%s'" % (folder, label, val))
        if (tier == "inherit") != (ceiling == "inherit"):
            problems.append("%s: tier and ceiling must both be inherit or neither" % folder)
        elif tier.isdigit() and ceiling.isdigit() and int(ceiling) > int(tier):
            problems.append("%s: ceiling %s is stricter than tier %s" % (folder, ceiling, tier))
        if fm["mode"] not in VALID_MODES:
            problems.append("%s: invalid mode '%s'" % (folder, fm["mode"]))
        if fm["group"] not in VALID_GROUPS:
            problems.append("%s: invalid group '%s'" % (folder, fm["group"]))
        for key in ("needs", "better-with"):
            if not isinstance(fm[key], list):
                problems.append("%s: %s must be a [list]" % (folder, key))
                continue
            for cap in fm[key]:
                if cap not in caps:
                    problems.append("%s: unknown capability '%s' in %s" % (folder, cap, key))
        if fm["group"] == "process":
            for heading in PROCESS_HEADINGS:
                if not re.search(r"^%s\s*$" % re.escape(heading), text, re.M):
                    problems.append("%s: missing heading '%s'" % (folder, heading))
        if folder not in VENDOR_ALLOWED:
            for vendor in VENDORS:
                if re.search(r"\b%s\b" % re.escape(vendor), text):
                    problems.append("%s: names a case system vendor '%s'" % (folder, vendor))
        if folder not in autonomy:
            problems.append("%s: not in AUTONOMY.md" % folder)
        elif autonomy[folder] != (tier, ceiling):
            problems.append("%s: AUTONOMY.md says %s/%s, SKILL.md says %s/%s"
                            % (folder, autonomy[folder][0], autonomy[folder][1], tier, ceiling))
    for name in sorted(set(autonomy) - seen - skill_names):
        problems.append("%s: in AUTONOMY.md but no skill" % name)


def check_text(root, problems):
    for path in text_files(root):
        rel = path.relative_to(root).as_posix()
        if rel == "scripts/lint_template.py":
            continue
        text = read(path)
        for n, line in enumerate(text.splitlines(), 1):
            if EM_DASH in line:
                problems.append("%s:%d: em dash" % (rel, n))
            for name in PLACEHOLDER_RE.findall(line):
                if name not in KNOWN_PLACEHOLDERS:
                    problems.append("%s:%d: unknown placeholder {{%s}}" % (rel, n, name))
            if rel.split("/")[0] in PERSONAL_DIRS:
                if PHONE_RE.search(line):
                    problems.append("%s:%d: phone number" % (rel, n))
                for m in EMAIL_RE.finditer(line):
                    if not m.group(0).lower().endswith(SAFE_EMAIL_DOMAINS):
                        problems.append("%s:%d: email address" % (rel, n))


def run_checks(root):
    root = Path(root)
    problems = []
    check_skills(root, problems)
    check_text(root, problems)
    return problems


def main():
    ap = argparse.ArgumentParser(description="Check the template's own contract.")
    ap.add_argument("--root", default=str(Path(__file__).resolve().parent.parent))
    args = ap.parse_args()
    problems = run_checks(Path(args.root).resolve())
    if problems:
        for p in problems:
            print(p)
        print("lint: %d problem%s" % (len(problems), "" if len(problems) == 1 else "s"))
        return 1
    print("lint: clean, %d skills" % len(skill_files(Path(args.root).resolve())))
    return 0


if __name__ == "__main__":
    sys.exit(main())
