#!/usr/bin/env python3
"""
expiry_scan.py - which clients are due a remortgage conversation.

Input is the expiries CSV written by the case-system bulk fetch (scripts/cases_fetch.py)
into a temporary file outside this folder: case_ref,product_end,erc_end. A missing
column is an error (exit 2), never a quiet empty scan. The key date is erc_end when
present, otherwise product_end. A client is DUE once the key date is within the lead
window. PASSED means the date has gone by. CHECK means a date could not be read, and it is never guessed.

Prints case references only.

Usage:
  python scripts/expiry_scan.py --input C:/temp/expiries.csv --lead-days 180
"""

import argparse
import csv
import datetime as dt
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import trackers  # noqa: E402

COLUMNS = ("case_ref", "product_end", "erc_end")


def scan(rows, today, lead_days):
    found = []
    for row in rows:
        ref = (row.get("case_ref") or "").strip()
        erc_raw = (row.get("erc_end") or "").strip()
        erc = trackers.as_date(erc_raw) if erc_raw else None

        if erc_raw and erc is None:
            found.append((dt.date.min, "CHECK  %s  erc_end unreadable: %s" % (ref, erc_raw)))
            continue

        product = trackers.as_date(row.get("product_end") or "")
        key, label = (erc, "ERC") if erc else (product, "product")
        if key is None:
            found.append((dt.date.min, "CHECK  %s  no readable product_end or erc_end" % ref))
            continue
        days = (key - today).days
        contact = key - dt.timedelta(days=lead_days)
        if days < 0:
            found.append((key, "PASSED  %s  %s ended %s, %d days ago" % (ref, label, key, -days)))
        elif contact <= today:
            found.append((key, "DUE  %s  %s ends %s (%d days), contact from %s"
                          % (ref, label, key, days, contact)))
    return [line for _, line in sorted(found, key=lambda x: x[0])]


def main():
    ap = argparse.ArgumentParser(description="Remortgage expiry scan.")
    ap.add_argument("--input", required=True)
    ap.add_argument("--lead-days", type=int, default=180)
    ap.add_argument("--today", default=None)
    args = ap.parse_args()
    if args.today:
        today = trackers.as_date(args.today)
        if today is None:
            print("expiry_scan: --today must be YYYY-MM-DD", file=sys.stderr)
            return 2
    else:
        today = dt.date.today()
    path = Path(args.input)
    if not path.exists():
        print("expiry_scan: input not found: %s" % path, file=sys.stderr)
        return 2
    with path.open(newline="", encoding="utf-8-sig") as fh:
        reader = csv.DictReader(fh)
        header = [h.strip() for h in (reader.fieldnames or [])]
        if any(c not in header for c in COLUMNS):
            print("expiry_scan: --input needs columns %s" % ",".join(COLUMNS), file=sys.stderr)
            return 2
        reader.fieldnames = header
        lines = scan(list(reader), today, args.lead_days)
    print("\n".join(lines) if lines else "expiry_scan: nobody due")
    return 0


if __name__ == "__main__":
    sys.exit(main())
