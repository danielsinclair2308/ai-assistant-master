#!/usr/bin/env python3
"""
chase_due.py - what needs chasing today.

Reads state/chasers.md and state/cases.md, plus an optional live cases CSV from the
case-system bulk fetch, and prints, by case reference only:
  CHASER      an active chase sequence whose interval has passed
  OVERDUE     a case waiting on someone for longer than the limit
  CHASE DATE  a case whose chase date has arrived

It prints conclusions and never sends anything. Whether to chase, and the message, are
decided by the skill that owns the chaser, at that skill's tier.

--cases-input takes a CSV with at least the columns case_ref,waiting,requested,chase
(values as in the tracker; blank or - means empty), written by the case-system bulk fetch
into a temporary file outside this folder. Its rows are merged with the latest open
entries in state/cases.md: for the same case reference the CSV wins field by field
wherever it holds a value. A case only in the CSV is checked too. With no CSV and no
open entry in state/cases.md, it says case dates were not checked rather than nothing due.

Usage:
  python scripts/chase_due.py
  python scripts/chase_due.py --overdue-days 2 --today 2026-09-24
  python scripts/chase_due.py --cases-input C:/temp/live-cases.csv
"""

import argparse
import csv
import datetime as dt
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import trackers  # noqa: E402


def chasers_due(root, today):
    entries = trackers.load(root / "state/chasers.md", "chaser")
    out = []
    for e in trackers.latest(entries, key=lambda e: (e["ref"], e.get("job", ""))).values():
        if not e["open"]:
            continue

        # Parse and validate every field
        every_raw = e.get("every", "")
        try:
            every = int(every_raw) if every_raw and every_raw != "-" else None
            if every is not None and every <= 0:
                every = None
        except ValueError:
            every = None

        if every is None:
            out.append("CHECK  %s  %s  chaser has no valid interval (every:%s)"
                       % (e["ref"], e.get("job", "?"), every_raw))
        else:
            last = trackers.as_date(e.get("last", "")) or e["date"]
            gap = (today - last).days
            if gap >= every:
                out.append("CHASER  %s  %s  to %s, last chased %d days ago (every %d)"
                           % (e["ref"], e.get("job", "?"), e.get("to", "?"), gap, every))
    return out


CASES_INPUT_COLUMNS = ("case_ref", "waiting", "requested", "chase")


def read_cases_input(path):
    """Read the live cases CSV. Returns {ref: {field: value}} with empty values left out.
    Raises ValueError when a required column is missing."""
    with Path(path).open(newline="", encoding="utf-8-sig") as fh:
        reader = csv.DictReader(fh)
        header = [h.strip() for h in (reader.fieldnames or [])]
        if any(c not in header for c in CASES_INPUT_COLUMNS):
            raise ValueError("missing columns")
        reader.fieldnames = header
        out = {}
        for row in reader:
            ref = (row.get("case_ref") or "").strip()
            if not ref:
                continue
            fields = out.setdefault(ref, {})
            for col in CASES_INPUT_COLUMNS[1:]:
                val = (row.get(col) or "").strip()
                if val and val != "-":
                    fields[col] = val
    return out


def merged_cases(root, live=None):
    cases = {ref: dict(e) for ref, e in
             trackers.latest(trackers.load(root / "state/cases.md", "case")).items() if e["open"]}
    for ref, fields in (live or {}).items():
        cases.setdefault(ref, {"ref": ref, "open": True}).update(fields)
    return list(cases.values())


def cases_due(root, today, overdue_days, live=None):
    out = []
    for e in merged_cases(root, live):
        waiting = e.get("waiting", "-")
        requested = trackers.as_date(e.get("requested", ""))
        if requested and waiting != "-" and (today - requested).days > overdue_days:
            out.append("OVERDUE  %s  waiting on %s for %d days (limit %d)"
                       % (e["ref"], waiting, (today - requested).days, overdue_days))
        chase = trackers.as_date(e.get("chase", ""))
        if chase and chase <= today:
            out.append("CHASE DATE  %s  chase date %s reached, waiting on %s"
                       % (e["ref"], chase.isoformat(), waiting))
    return out


def due(root, today, overdue_days, live=None):
    root = Path(root)
    return chasers_due(root, today) + cases_due(root, today, overdue_days, live)


def main():
    ap = argparse.ArgumentParser(description="What needs chasing today.")
    ap.add_argument("--root", default=str(Path(__file__).resolve().parent.parent))
    ap.add_argument("--today", default=None)
    ap.add_argument("--overdue-days", type=int, default=2)
    ap.add_argument("--cases-input", default=None)
    args = ap.parse_args()
    today = trackers.as_date(args.today) if args.today else dt.date.today()
    if today is None:
        print("chase_due: --today must be YYYY-MM-DD", file=sys.stderr)
        return 2
    live = None
    if args.cases_input:
        path = Path(args.cases_input)
        if not path.exists():
            print("chase_due: --cases-input not found: %s" % path, file=sys.stderr)
            return 2
        try:
            live = read_cases_input(path)
        except ValueError:
            print("chase_due: --cases-input needs columns %s" % ",".join(CASES_INPUT_COLUMNS),
                  file=sys.stderr)
            return 2
    lines = due(args.root, today, args.overdue_days, live)
    if live is None and not merged_cases(Path(args.root)):
        lines.append("chase_due: case dates not checked (no --cases-input and no open entries "
                     "in state/cases.md)")
        for line in lines:
            print(line)
        return 0
    if not lines:
        print("chase_due: nothing due")
        return 0
    for line in lines:
        print(line)
    print("chase_due: %d item%s" % (len(lines), "" if len(lines) == 1 else "s"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
