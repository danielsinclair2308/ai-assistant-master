# Scripts

Written by the assistant, not by hand. The rule is in `EFFICIENCY.md`: write it once, then
run it every day and read only what it prints.

## Why these exist

Reading a month of chasers, lender quotes or case files into a conversation costs tens of
thousands of tokens and does it again tomorrow. A script does the fetching and the
counting, and prints a summary small enough to reason about.

## How to add one

1. Work out what conclusion the job actually needs. Not what data, what conclusion.
2. Write a script that reaches it and prints it in under about forty lines.
3. Save it here with a header saying what it does, what it needs, and what it prints.
4. Add it to the relevant SKILL.md so the job runs it instead of doing the work by hand.
5. **Check the first run by hand.** Confirm the script's answer matches what you would have
   concluded from the raw data. After that, trust it.

## Rules

- **Print conclusions, not tables.** "3 cases overdue" beats 60 rows.
- **Never print personal data** unless the job genuinely needs it. Case references, not
  client names, wherever a reference will do.
- **Fail loudly.** If a script cannot reach a system it must say so clearly.
- **Never cache live figures to a file.** Scripts fetch fresh every time.
- Anything financial gets computed here, never in the model's head.

## Built into the template

| Script | Used by | Prints |
|---|---|---|
| `lint_template.py` | Test suite, before release | Frontmatter, placeholder and em dash problems, one per line |
| `trackers.py` | Every other tracker script | Nothing on its own; a shared library for reading `state/*.md` lines |
| `chase_due.py` | Daily run | Cases due a chase, overdue, or at their chase date, by reference. `--cases-input` takes the live cases CSV from `cases_fetch.py`; without it or an open `state/cases.md` entry it says case dates were not checked |
| `quote_tracker.py` | Case work | Which lenders on a case have replied, which are outstanding, and whether it is ready for the adviser |
| `expiry_scan.py` | Weekly run | Clients due a remortgage conversation, by reference, from the expiries CSV written by `cases_fetch.py` |
| `case_folder.py` | New case | Confirmation that the client's folder was created, or why it refused |
| `invoice.py` | Invoicing | The filled invoice, or why it refused to write one |
| `make_invoice_template.py` | Template maintainers only | Regenerates `knowledge/templates/invoice.docx` |
| `backup.py` | Nightly run | Commits and pushes; refuses credential-looking or client-document-looking paths |
| `rollup.py` | Monthly | Moves history to archives; prints counts |
| `guard.py` | Nightly | Flags oversized working files |
| `index-knowledge.py` | After lender-file edits | Rebuilds the lenders index |

## Written per install (by the assistant)

Which of these matter depends on the case system and other tools connected at onboarding.
Every install with a case system needs its bulk fetch script, `cases_fetch.py`, owned by
the `case-system` skill and checked by hand at onboarding. It writes one of two CSVs to a
temporary file outside this folder (see "Bulk reads and counts" in `case-system`):

- the **live cases CSV**, `case_ref,stage,status,waiting,requested,chase,submitted,valuation,source`,
  read by `case-tracking` (through `chase_due.py --cases-input`), `weekly-report`,
  `metrics-snapshot` and `audit`;
- the **expiries CSV**, `case_ref,product_end,erc_end`, read by `remortgage-watch`
  through `expiry_scan.py`.

Other typical ones are a daily metrics script, `snapshot.py`, for `metrics-snapshot`, and
a bank feed payment check, `paid.py`, to say which invoices have actually been paid.

Build only what the connected systems require. Do not write a fetch script for a case
system that is not in use "just in case".
