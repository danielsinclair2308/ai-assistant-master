#!/usr/bin/env python3
"""
invoice.py - fill the invoice template for one case, optionally convert to PDF.

The fee comes from the ESIS, read by the invoicing skill and confirmed before this runs.
This script validates it and formats it. It does no VAT arithmetic. It refuses a
template that still has [[FILL]] lines, because an invoice without the broker's own
payment details is not an invoice, and it refuses to overwrite an existing invoice.

Usage:
  python scripts/invoice.py --template knowledge/templates/invoice.docx \
      --out "D:/Clients/Smith, Jane (C-1042)/09 Invoices/INV-0001.docx" \
      --number INV-0001 --date 2026-09-24 --case C-1042 --client "Jane Smith" \
      --fee 595 --description "Broker fee, buy to let mortgage" --pdf
"""

import argparse
import datetime as dt
import re
import shutil
import subprocess
import sys
from decimal import Decimal, InvalidOperation
from pathlib import Path

from docx import Document

MAX_FEE = Decimal("100000")
FIELD_RE = re.compile(r"<<([A-Z_]+)>>")


def parse_fee(text):
    cleaned = (text or "").strip().replace("£", "").replace(",", "")
    if not re.fullmatch(r"\d+(\.\d{1,2})?", cleaned):
        raise ValueError("fee is not a plain amount: %r" % text)
    try:
        fee = Decimal(cleaned)
    except InvalidOperation:
        raise ValueError("fee is not a number: %r" % text)
    if fee <= 0 or fee >= MAX_FEE:
        raise ValueError("fee %s is outside 0 to %s, check the ESIS" % (fee, MAX_FEE))
    return fee


def format_gbp(amount):
    return "£{:,.2f}".format(amount)


def _paragraphs(doc):
    for p in doc.paragraphs:
        yield p
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                for p in cell.paragraphs:
                    yield p
    for section in doc.sections:
        for p in section.header.paragraphs:
            yield p
        for p in section.footer.paragraphs:
            yield p


def fill(template, out, values):
    template, out = Path(template), Path(out)
    if out.exists():
        raise ValueError("%s already exists, invoices are never overwritten" % out)
    doc = Document(str(template))
    paragraphs = list(_paragraphs(doc))
    if any("[[FILL" in p.text for p in paragraphs):
        raise ValueError("the invoice template still has [[FILL]] lines for the broker to complete")
    for p in paragraphs:
        text = p.text
        if "<<" not in text:
            continue
        new = FIELD_RE.sub(lambda m: values.get(m.group(1), m.group(0)), text)
        left = FIELD_RE.findall(new)
        if left:
            raise ValueError("no value for <<%s>>" % left[0])
        if new != text and p.runs:
            p.runs[0].text = new
            for r in p.runs[1:]:
                r.text = ""
    out.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(out))


def _docx2pdf():
    try:
        from docx2pdf import convert
        return convert
    except ImportError:
        return None


def to_pdf(docx):
    docx = Path(docx)
    convert = _docx2pdf()
    if convert:
        convert(str(docx), str(docx.with_suffix(".pdf")))
        return docx.with_suffix(".pdf")
    office = shutil.which("soffice") or shutil.which("libreoffice")
    if office:
        subprocess.run([office, "--headless", "--convert-to", "pdf", "--outdir",
                        str(docx.parent), str(docx)], check=True, timeout=120)
        return docx.with_suffix(".pdf")
    raise RuntimeError("no PDF converter: install Word with docx2pdf, or Word or LibreOffice")


def main():
    ap = argparse.ArgumentParser(description="Fill an invoice from the template.")
    for name in ("--template", "--out", "--number", "--date", "--case", "--client",
                 "--fee", "--description"):
        ap.add_argument(name, required=True)
    ap.add_argument("--terms-days", type=int, default=14)
    ap.add_argument("--pdf", action="store_true")
    args = ap.parse_args()
    try:
        fee = parse_fee(args.fee)
        date = dt.datetime.strptime(args.date, "%Y-%m-%d").date()
        values = {
            "INVOICE_NUMBER": args.number,
            "INVOICE_DATE": date.strftime("%d/%m/%Y"),
            "DUE_DATE": (date + dt.timedelta(days=args.terms_days)).strftime("%d/%m/%Y"),
            "CASE_REF": args.case,
            "CLIENT_NAME": args.client,
            "DESCRIPTION": args.description,
            "FEE": format_gbp(fee),
        }
        fill(args.template, args.out, values)
        print("invoice: %s for %s written" % (args.number, format_gbp(fee)))
        if args.pdf:
            print("invoice: PDF at %s" % to_pdf(args.out))
    except (ValueError, RuntimeError, subprocess.SubprocessError) as exc:
        print("invoice: %s" % exc, file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
