"""
trackers.py - read the one-line trackers in state/.

Format, one entry per line, compatible with rollup.py so open lines are never archived:

  - [ ] YYYY-MM-DD | kind | ref | key:value | key:value ...

An entry must start at the beginning of the line: indented lines (examples in the
templates) are never read as entries. To update an entry, tick the old line [x] and
append a new one. The last line for a key wins. A value of - means empty.
"""

import datetime as dt
import re
from pathlib import Path

LINE_RE = re.compile(r"^-\s*\[( |x|X)\]\s*(\d{4}-\d{2}-\d{2})\s*\|\s*([a-z-]+)\s*\|\s*([^|]+?)\s*\|(.*)$")


def as_date(value):
    try:
        return dt.datetime.strptime(value.strip(), "%Y-%m-%d").date()
    except (ValueError, AttributeError):
        return None


def parse_line(line):
    m = LINE_RE.match(line.rstrip())
    if not m:
        return None
    entry = {"open": m.group(1) == " ", "date": as_date(m.group(2)),
             "kind": m.group(3), "ref": m.group(4).strip()}
    for part in m.group(5).split("|"):
        key, sep, val = part.strip().partition(":")
        if sep and key.strip():
            entry[key.strip()] = val.strip()
    return entry


def load(path, kind):
    path = Path(path)
    if not path.exists():
        return []
    out = []
    for line in path.read_text(encoding="utf-8").splitlines():
        e = parse_line(line)
        if e and e["kind"] == kind:
            out.append(e)
    return out


def latest(entries, key=lambda e: e["ref"]):
    out = {}
    for e in entries:
        out[key(e)] = e
    return out
