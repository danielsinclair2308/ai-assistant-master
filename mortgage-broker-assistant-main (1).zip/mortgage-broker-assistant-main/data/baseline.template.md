# The baseline

**Captured once, on day one, and never changed afterwards.**

This is the before picture. Without it, every claim about improvement is memory against
memory. Fill only measures that match enabled packs. Leave the rest blank. Never invent
a figure to make the table look complete.

Captured on: `[[FILL: date]]`
Captured by: `[[FILL: who]]`
Product mix in scope: `[[FILL: from knowledge/business.md]]`

---

## Time and admin (always)

| Measure | Value on day one |
|---|---|
| Hours a week on admin the assistant should take | `[[FILL: what they said]]` |
| Most frustrating thing right now (their words) | `[[FILL]]` |
| Work they least want to keep doing | `[[FILL]]` |

## Case pipeline

| Measure | Value on day one | How measured |
|---|---|---|
| Days from enquiry to submission | `[[FILL]]` | |
| Days to chase a document | `[[FILL]]` | |
| Lenders not heard back from, on average | `[[FILL]]` | |
| Cases completed per month | `[[FILL]]` | |

Once written, this file is never edited. Corrections get added underneath with the date.
