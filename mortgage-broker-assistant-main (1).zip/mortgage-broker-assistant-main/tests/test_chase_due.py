import datetime as dt

import chase_due as cd

TODAY = dt.date(2026, 9, 24)


def write(tmp_path, chasers="", cases=""):
    (tmp_path / "state").mkdir()
    (tmp_path / "state/chasers.md").write_text(chasers, encoding="utf-8")
    (tmp_path / "state/cases.md").write_text(cases, encoding="utf-8")
    return tmp_path


def test_chaser_due_after_interval(tmp_path):
    root = write(tmp_path, chasers="- [ ] 2026-09-18 | chaser | C-1 | job:invoicing | to:client | every:3 | last:2026-09-21\n")
    assert cd.due(root, TODAY, 2) == ["CHASER  C-1  invoicing  to client, last chased 3 days ago (every 3)"]


def test_chaser_not_yet_due(tmp_path):
    root = write(tmp_path, chasers="- [ ] 2026-09-18 | chaser | C-1 | job:invoicing | to:client | every:3 | last:2026-09-22\n")
    assert cd.due(root, TODAY, 2) == []


def test_closed_latest_chaser_ignored(tmp_path):
    root = write(tmp_path, chasers=(
        "- [x] 2026-09-18 | chaser | C-1 | job:invoicing | to:client | every:3 | last:2026-09-01\n"
        "- [x] 2026-09-22 | chaser | C-1 | job:invoicing | to:client | every:3 | last:2026-09-01 | stop:paid\n"))
    assert cd.due(root, TODAY, 2) == []


def test_two_jobs_same_case_tracked_separately(tmp_path):
    root = write(tmp_path, chasers=(
        "- [ ] 2026-09-18 | chaser | C-1 | job:invoicing | to:client | every:3 | last:2026-09-20\n"
        "- [ ] 2026-09-18 | chaser | C-1 | job:esis-pack | to:client | every:2 | last:2026-09-23\n"))
    assert len(cd.due(root, TODAY, 2)) == 1


def test_case_waiting_on_client_overdue(tmp_path):
    root = write(tmp_path, cases="- [ ] 2026-09-20 | case | C-2 | waiting:client | requested:2026-09-21 | chase:- | stage:pre-offer\n")
    assert cd.due(root, TODAY, 2) == ["OVERDUE  C-2  waiting on client for 3 days (limit 2)"]


def test_case_waiting_on_lender_not_overdue_for_client_rule(tmp_path):
    root = write(tmp_path, cases="- [ ] 2026-09-20 | case | C-2 | waiting:lender | requested:2026-09-01 | chase:- | stage:pre-offer\n")
    assert cd.due(root, TODAY, 2) == ["OVERDUE  C-2  waiting on lender for 23 days (limit 2)"]


def test_chase_date_reached(tmp_path):
    root = write(tmp_path, cases="- [ ] 2026-09-20 | case | C-3 | waiting:adviser | requested:- | chase:2026-09-24 | stage:pre-completion\n")
    assert cd.due(root, TODAY, 2) == ["CHASE DATE  C-3  chase date 2026-09-24 reached, waiting on adviser"]


def test_nothing_due_empty(tmp_path):
    assert cd.due(write(tmp_path), TODAY, 2) == []


def test_chaser_every_empty_dash(tmp_path):
    root = write(tmp_path, chasers="- [ ] 2026-09-18 | chaser | C-1 | job:invoicing | to:client | every:-\n")
    assert cd.due(root, TODAY, 2) == ["CHECK  C-1  invoicing  chaser has no valid interval (every:-)"]


def test_chaser_missing_every_field(tmp_path):
    root = write(tmp_path, chasers="- [ ] 2026-09-18 | chaser | C-1 | job:invoicing | to:client\n")
    assert cd.due(root, TODAY, 2) == ["CHECK  C-1  invoicing  chaser has no valid interval (every:)"]


def test_chaser_bad_every_alongside_valid(tmp_path):
    root = write(tmp_path, chasers=(
        "- [ ] 2026-09-18 | chaser | C-1 | job:invoicing | to:client | every:-\n"
        "- [ ] 2026-09-18 | chaser | C-2 | job:docs | to:lender | every:2 | last:2026-09-22\n"))
    result = cd.due(root, TODAY, 2)
    assert "CHECK  C-1  invoicing  chaser has no valid interval (every:-)" in result
    assert "CHASER  C-2  docs  to lender, last chased 2 days ago (every 2)" in result
    assert len(result) == 2


def write_csv(tmp_path, text, name="live.csv"):
    p = tmp_path / name
    p.write_text(text, encoding="utf-8-sig")
    return p


def test_cases_input_merges_with_tracker_csv_wins_where_set(tmp_path):
    root = write(tmp_path, cases="- [ ] 2026-09-20 | case | C-2 | waiting:client | requested:2026-09-23 | chase:2026-09-24 | stage:pre-offer\n")
    csv_path = write_csv(tmp_path, "case_ref,waiting,requested,chase\nC-2,lender,2026-09-20,\n")
    rows = cd.read_cases_input(csv_path)
    assert cd.due(root, TODAY, 2, rows) == [
        "OVERDUE  C-2  waiting on lender for 4 days (limit 2)",
        "CHASE DATE  C-2  chase date 2026-09-24 reached, waiting on lender"]


def test_cases_input_case_only_in_csv(tmp_path):
    root = write(tmp_path)
    csv_path = write_csv(tmp_path, "case_ref,waiting,requested,chase\nC-9,-,-,2026-09-23\n")
    assert cd.due(root, TODAY, 2, cd.read_cases_input(csv_path)) == [
        "CHASE DATE  C-9  chase date 2026-09-23 reached, waiting on -"]


def test_cases_input_bad_header_exits_2(tmp_path, monkeypatch, capsys):
    root = write(tmp_path)
    csv_path = write_csv(tmp_path, "case_ref,waiting,chase\nC-9,client,-\n")
    monkeypatch.setattr("sys.argv", ["chase_due.py", "--root", str(root), "--today", "2026-09-24",
                                     "--cases-input", str(csv_path)])
    assert cd.main() == 2
    assert "chase_due: --cases-input needs columns case_ref,waiting,requested,chase" in capsys.readouterr().err


def test_no_case_source_reports_not_checked(tmp_path, monkeypatch, capsys):
    root = write(tmp_path)
    monkeypatch.setattr("sys.argv", ["chase_due.py", "--root", str(root), "--today", "2026-09-24"])
    assert cd.main() == 0
    out = capsys.readouterr().out
    assert "chase_due: case dates not checked" in out
    assert "nothing due" not in out


def test_empty_cases_input_is_a_check(tmp_path, monkeypatch, capsys):
    root = write(tmp_path)
    csv_path = write_csv(tmp_path, "case_ref,waiting,requested,chase\n")
    monkeypatch.setattr("sys.argv", ["chase_due.py", "--root", str(root), "--today", "2026-09-24",
                                     "--cases-input", str(csv_path)])
    assert cd.main() == 0
    assert capsys.readouterr().out.strip() == "chase_due: nothing due"
