from decimal import Decimal

import pytest
from docx import Document

import invoice
import make_invoice_template


def filled_template(tmp_path):
    """A copy of the template with the broker's FILL lines completed."""
    path = make_invoice_template.build(tmp_path / "t.docx")
    doc = Document(str(path))
    for p in doc.paragraphs:
        if "[[FILL" in p.text:
            for r in p.runs:
                r.text = ""
            p.runs[0].text = "Test Broker Ltd"
    doc.save(str(path))
    return path


VALUES = {"INVOICE_NUMBER": "INV-0001", "INVOICE_DATE": "24/09/2026", "DUE_DATE": "08/10/2026",
          "CASE_REF": "C-1", "CLIENT_NAME": "Jane Smith",
          "DESCRIPTION": "Broker fee", "FEE": "£595.00"}


def all_text(path):
    doc = Document(str(path))
    parts = [p.text for p in doc.paragraphs]
    for t in doc.tables:
        for row in t.rows:
            parts += [c.text for c in row.cells]
    return "\n".join(parts)


@pytest.mark.parametrize("text,expected", [("595", "595"), ("£1,295.50", "1295.50"), (" 795.00 ", "795.00")])
def test_parse_fee_ok(text, expected):
    assert invoice.parse_fee(text) == Decimal(expected)


@pytest.mark.parametrize("text", ["0", "-10", "12.345", "abc", "", "250000", "NaN", "1e3", "£"])
def test_parse_fee_rejects(text):
    with pytest.raises(ValueError):
        invoice.parse_fee(text)


def test_format_gbp():
    assert invoice.format_gbp(Decimal("1295.5")) == "£1,295.50"


def test_fill_writes_all_fields(tmp_path):
    out = tmp_path / "out.docx"
    invoice.fill(filled_template(tmp_path), out, VALUES)
    text = all_text(out)
    assert "INV-0001" in text and "£595.00" in text and "Jane Smith" in text
    assert "<<" not in text


def test_fill_refuses_unfinished_template(tmp_path):
    raw = make_invoice_template.build(tmp_path / "raw.docx")
    with pytest.raises(ValueError, match="FILL"):
        invoice.fill(raw, tmp_path / "out.docx", VALUES)


def test_fill_refuses_missing_value(tmp_path):
    values = dict(VALUES)
    del values["FEE"]
    with pytest.raises(ValueError, match="<<FEE>>"):
        invoice.fill(filled_template(tmp_path), tmp_path / "out.docx", values)


def test_fill_refuses_overwrite(tmp_path):
    out = tmp_path / "out.docx"
    out.write_text("x")
    with pytest.raises(ValueError, match="already exists"):
        invoice.fill(filled_template(tmp_path), out, VALUES)


def test_to_pdf_without_converter(monkeypatch, tmp_path):
    monkeypatch.setattr(invoice, "_docx2pdf", lambda: None)
    monkeypatch.setattr(invoice.shutil, "which", lambda name: None)
    with pytest.raises(RuntimeError, match="Word or LibreOffice"):
        invoice.to_pdf(tmp_path / "x.docx")
