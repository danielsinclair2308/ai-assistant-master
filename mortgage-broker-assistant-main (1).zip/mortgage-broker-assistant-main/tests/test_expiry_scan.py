import datetime as dt

import expiry_scan as es

TODAY = dt.date(2026, 9, 24)


def test_due_inside_lead_window():
    rows = [{"case_ref": "C-1", "product_end": "2027-01-31", "erc_end": ""}]
    assert es.scan(rows, TODAY, 180) == ["DUE  C-1  product ends 2027-01-31 (129 days), contact from 2026-08-04"]


def test_erc_end_takes_priority():
    rows = [{"case_ref": "C-2", "product_end": "2027-06-30", "erc_end": "2027-01-31"}]
    assert es.scan(rows, TODAY, 180)[0].startswith("DUE  C-2  ERC ends 2027-01-31")


def test_not_yet_due():
    rows = [{"case_ref": "C-3", "product_end": "2028-01-01", "erc_end": ""}]
    assert es.scan(rows, TODAY, 180) == []


def test_passed():
    rows = [{"case_ref": "C-4", "product_end": "2026-09-01", "erc_end": ""}]
    assert es.scan(rows, TODAY, 180) == ["PASSED  C-4  product ended 2026-09-01, 23 days ago"]


def test_bad_date_flagged_not_guessed():
    rows = [{"case_ref": "C-5", "product_end": "31/01/2027", "erc_end": ""}]
    assert es.scan(rows, TODAY, 180) == ["CHECK  C-5  no readable product_end or erc_end"]


def test_sorted_by_key_date():
    rows = [{"case_ref": "B", "product_end": "2027-02-01", "erc_end": ""},
            {"case_ref": "A", "product_end": "2026-12-01", "erc_end": ""}]
    assert [l.split()[1] for l in es.scan(rows, TODAY, 180)] == ["A", "B"]


def test_bad_erc_end_flagged_not_fallback():
    rows = [{"case_ref": "C-6", "product_end": "2027-01-31", "erc_end": "31/01/2027"}]
    assert es.scan(rows, TODAY, 180) == ["CHECK  C-6  erc_end unreadable: 31/01/2027"]


def run_main(monkeypatch, path):
    monkeypatch.setattr("sys.argv", ["expiry_scan.py", "--input", str(path), "--today", "2026-09-24"])
    return es.main()


def test_main_reads_utf8_bom(tmp_path, monkeypatch, capsys):
    p = tmp_path / "exp.csv"
    p.write_text("case_ref,product_end,erc_end\nC-1,2027-01-31,\n", encoding="utf-8-sig")
    assert run_main(monkeypatch, p) == 0
    assert capsys.readouterr().out.startswith("DUE  C-1  product ends 2027-01-31")


def test_main_missing_column_exits_2(tmp_path, monkeypatch, capsys):
    p = tmp_path / "exp.csv"
    p.write_text("case_ref,product_end\nC-1,2027-01-31\n", encoding="utf-8")
    assert run_main(monkeypatch, p) == 2
    assert "expiry_scan: --input needs columns case_ref,product_end,erc_end" in capsys.readouterr().err
