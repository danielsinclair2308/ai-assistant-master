import csv
import subprocess
import sys
from pathlib import Path

SCRIPT = Path(__file__).resolve().parent.parent / "scripts/rollup.py"

METRICS_HEADER = ["date", "enquiries_new", "cases_live", "cases_waiting_client",
                  "cases_waiting_lender", "cases_overdue", "docs_requested",
                  "docs_received", "applications_prepared", "offers_issued",
                  "completions", "invoices_outstanding", "chasers_sent",
                  "approvals_pending", "messages_triaged"]

OLD_CLOSED = "- [x] 2026-06-01 | quote | C-1 | lender:Alpha | asked:2026-06-01 | replied:2026-06-02\n"
OLD_OPEN = "- [ ] 2026-06-01 | case | C-2 | waiting:client | requested:2026-06-01\n"
RECENT_CLOSED = "- [x] 2026-09-20 | chaser | C-3 | job:invoicing | every:3 | last:2026-09-20\n"


def run(root):
    return subprocess.run([sys.executable, str(SCRIPT), "--root", str(root), "--today", "2026-10-01"],
                          capture_output=True, text=True, check=True)


def test_trackers_roll_closed_old_lines_only(tmp_path):
    state = tmp_path / "state"
    state.mkdir()
    (state / "lender-quotes.md").write_text("# Lender quotes\n" + OLD_CLOSED, encoding="utf-8")
    (state / "cases.md").write_text("# Cases\n" + OLD_OPEN, encoding="utf-8")
    (state / "chasers.md").write_text("# Chasers\n" + RECENT_CLOSED, encoding="utf-8")
    run(tmp_path)
    assert OLD_CLOSED not in (state / "lender-quotes.md").read_text(encoding="utf-8")
    assert OLD_CLOSED in (state / "archive/lender-quotes-2026-06.md").read_text(encoding="utf-8")
    assert OLD_OPEN in (state / "cases.md").read_text(encoding="utf-8")
    assert RECENT_CLOSED in (state / "chasers.md").read_text(encoding="utf-8")


def test_metrics_aggregate_to_monthly_using_broker_columns(tmp_path):
    (tmp_path / "state").mkdir()
    data = tmp_path / "data"
    data.mkdir()
    with (data / "metrics.csv").open("w", encoding="utf-8", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=METRICS_HEADER)
        w.writeheader()
        w.writerow({"date": "2026-06-01", "enquiries_new": "2", "cases_live": "10"})
        w.writerow({"date": "2026-06-02", "enquiries_new": "3", "cases_live": "12"})
    run(tmp_path)
    with (data / "metrics-monthly.csv").open(encoding="utf-8", newline="") as fh:
        rows = {r["date"]: r for r in csv.DictReader(fh)}
    row = rows["2026-06"]
    assert row["enquiries_new"] == "5"
    assert row["cases_live"] == "12"
