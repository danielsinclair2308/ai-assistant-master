import datetime as dt

import trackers as t


def test_parse_open_line():
    e = t.parse_line("- [ ] 2026-09-20 | case | C-1 | waiting:client | requested:2026-09-19")
    assert e == {"open": True, "date": dt.date(2026, 9, 20), "kind": "case", "ref": "C-1",
                 "waiting": "client", "requested": "2026-09-19"}


def test_parse_closed_line_and_values_with_colons():
    e = t.parse_line("- [x] 2026-09-20 | quote | C-1 | lender:Big Bank: Intermediary Desk | note:terms-received")
    assert e["open"] is False
    assert e["lender"] == "Big Bank: Intermediary Desk"
    assert e["note"] == "terms-received"


def test_non_tracker_lines_ignored():
    assert t.parse_line("# Cases") is None
    assert t.parse_line("- [ ] 2026-09-20 | only-two | fields") is None


def test_load_filters_kind(tmp_path):
    p = tmp_path / "x.md"
    p.write_text("# x\n- [ ] 2026-09-20 | case | C-1 | a:1\n- [ ] 2026-09-20 | chaser | C-1 | a:2\n",
                 encoding="utf-8")
    assert [e["a"] for e in t.load(p, "case")] == ["1"]


def test_load_missing_file(tmp_path):
    assert t.load(tmp_path / "nope.md", "case") == []


def test_latest_last_wins():
    a = {"ref": "C-1", "v": "1"}
    b = {"ref": "C-1", "v": "2"}
    c = {"ref": "C-2", "v": "3"}
    assert t.latest([a, b, c]) == {"C-1": b, "C-2": c}


def test_as_date():
    assert t.as_date("2026-09-24") == dt.date(2026, 9, 24)
    assert t.as_date("-") is None
    assert t.as_date("") is None


def test_indented_line_is_not_an_entry():
    assert t.parse_line("  - [ ] 2026-09-20 | case | C-1042 | waiting:client") is None
    assert t.parse_line("\t- [ ] 2026-09-20 | case | C-1042 | waiting:client") is None


def test_line_with_trailing_newline_still_parses():
    assert t.parse_line("- [ ] 2026-09-20 | case | C-1 | waiting:client\r\n")["waiting"] == "client"
