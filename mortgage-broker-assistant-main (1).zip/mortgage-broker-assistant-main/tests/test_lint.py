import lint_template as lt

CAPS = "| Capability | Meaning |\n|---|---|\n| `email` | mail |\n| `case-system` | cases |\n"
AUT = ("| Skill | Starts | Ceiling | Note |\n|---|---|---|---|\n"
       "| `demo` | 3 | 2 | x |\n")
SKILL = """---
name: demo
description: A demo.
group: process
tier: 3
ceiling: 2
mode: trigger
needs: [email]
better-with: [case-system]
---

# Demo

## Steps
## Approval points
## Never
## Writes to
"""


def base(extra=None):
    files = {"knowledge/capabilities.md": CAPS, "AUTONOMY.md": AUT,
             ".claude/skills/demo/SKILL.md": SKILL}
    files.update(extra or {})
    return files


def test_parse_frontmatter_lists_and_scalars():
    fm = lt.parse_frontmatter(SKILL)
    assert fm["tier"] == "3"
    assert fm["needs"] == ["email"]
    assert fm["better-with"] == ["case-system"]


def test_parse_frontmatter_missing_returns_none():
    assert lt.parse_frontmatter("# no frontmatter") is None


def test_clean_tree_passes(tree):
    assert lt.run_checks(tree(base())) == []


def test_missing_key_reported(tree):
    root = tree(base({".claude/skills/demo/SKILL.md": SKILL.replace("mode: trigger\n", "")}))
    assert any("demo: missing frontmatter key 'mode'" in p for p in lt.run_checks(root))


def test_unknown_capability_reported(tree):
    root = tree(base({".claude/skills/demo/SKILL.md": SKILL.replace("[email]", "[fax]")}))
    assert any("unknown capability 'fax'" in p for p in lt.run_checks(root))


def test_ceiling_looser_than_allowed_is_fine_but_inverted_is_not(tree):
    bad = SKILL.replace("tier: 3", "tier: 2").replace("ceiling: 2", "ceiling: 3")
    root = tree(base({".claude/skills/demo/SKILL.md": bad,
                      "AUTONOMY.md": AUT.replace("| 3 | 2 |", "| 2 | 3 |")}))
    assert any("ceiling 3 is stricter than tier 2" in p for p in lt.run_checks(root))


def test_autonomy_mismatch_reported(tree):
    root = tree(base({"AUTONOMY.md": AUT.replace("| 3 | 2 |", "| 3 | 3 |")}))
    assert any("demo: AUTONOMY.md says 3/3, SKILL.md says 3/2" in p for p in lt.run_checks(root))


def test_skill_missing_from_autonomy(tree):
    root = tree(base({"AUTONOMY.md": "| Skill | Starts | Ceiling | Note |\n"}))
    assert any("demo: not in AUTONOMY.md" in p for p in lt.run_checks(root))


def test_autonomy_row_without_skill(tree):
    root = tree(base({"AUTONOMY.md": AUT + "| `ghost` | 1 | 1 | x |\n"}))
    assert any("ghost: in AUTONOMY.md but no skill" in p for p in lt.run_checks(root))


def test_process_skill_needs_headings(tree):
    root = tree(base({".claude/skills/demo/SKILL.md": SKILL.replace("## Never\n", "")}))
    assert any("demo: missing heading '## Never'" in p for p in lt.run_checks(root))


def test_vendor_name_in_process_skill(tree):
    root = tree(base({".claude/skills/demo/SKILL.md": SKILL + "\nUpload to Intelliflo.\n"}))
    assert any("names a case system vendor 'Intelliflo'" in p for p in lt.run_checks(root))


def test_vendor_name_allowed_in_case_system(tree):
    cs = SKILL.replace("name: demo", "name: case-system").replace("group: process", "group: adapter")
    root = tree(base({".claude/skills/case-system/SKILL.md": cs + "\nFor example Intelliflo.\n",
                      "AUTONOMY.md": AUT + "| `case-system` | 3 | 2 | x |\n"}))
    assert lt.run_checks(root) == []


def test_unknown_placeholder(tree):
    root = tree(base({"README.md": "Hello {{CLIENT_NAME}}\n"}))
    assert any("unknown placeholder {{CLIENT_NAME}}" in p for p in lt.run_checks(root))


def test_em_dash_reported(tree):
    root = tree(base({"README.md": "one \u2014 two\n"}))
    assert any("README.md:1: em dash" in p for p in lt.run_checks(root))


def test_personal_data_in_knowledge(tree):
    root = tree(base({"knowledge/x.md": "Call 07700 900123 or jane@gmail.com\n"}))
    probs = lt.run_checks(root)
    assert any("phone number" in p for p in probs)
    assert any("email address" in p for p in probs)


def test_example_email_allowed(tree):
    root = tree(base({"knowledge/x.md": "Write to hello@example.com\n"}))
    assert lt.run_checks(root) == []
