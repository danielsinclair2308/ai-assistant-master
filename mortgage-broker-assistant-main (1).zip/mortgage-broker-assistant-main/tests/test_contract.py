import re
from pathlib import Path

import lint_template as lt

ROOT = Path(__file__).resolve().parent.parent


def skills():
    return {p.parent.name: lt.parse_frontmatter(p.read_text(encoding="utf-8"))
            for p in lt.skill_files(ROOT)}


def test_repo_lints_clean():
    assert lt.run_checks(ROOT) == []


def test_every_process_skill_is_in_the_onboarding_walkthrough():
    onboarding = (ROOT / ".claude/skills/onboarding/SKILL.md").read_text(encoding="utf-8")
    missing = [n for n, fm in skills().items()
               if fm["group"] == "process" and "`%s`" % n not in onboarding]
    assert missing == []


def test_every_state_file_onboarding_writes_has_a_template():
    onboarding = (ROOT / ".claude/skills/onboarding/SKILL.md").read_text(encoding="utf-8")
    names = set(re.findall(r"state/([a-z-]+)\.md", onboarding))
    missing = [n for n in sorted(names) if not (ROOT / ("state/%s.template.md" % n)).exists()]
    assert names and missing == []


def test_every_process_skill_is_routed_in_claude_md():
    router = (ROOT / "CLAUDE.md").read_text(encoding="utf-8")
    missing = [n for n, fm in skills().items() if fm["group"] == "process" and n not in router]
    assert missing == []


def test_tracker_templates_exist_for_rollup():
    import rollup
    missing = [n for n in rollup.TRACKER_FILES if not (ROOT / ("state/%s.template.md" % n)).exists()]
    assert missing == []


def test_every_capability_used_is_explained():
    used = set()
    for fm in skills().values():
        used |= set(fm["needs"]) | set(fm["better-with"])
    assert used <= lt.load_capabilities(ROOT)


def test_no_client_documents_tracked():
    import subprocess
    tracked = subprocess.run(["git", "ls-files"], cwd=ROOT, capture_output=True,
                             text=True, check=True).stdout.split()
    import backup
    assert backup.document_like(tracked) == []


def test_state_templates_hold_no_live_tracker_entries():
    import trackers
    found = []
    for path in sorted((ROOT / "state").glob("*.template.md")):
        for kind in ("case", "chaser", "quote", "approval", "process"):
            found += ["%s: %s %s" % (path.name, kind, e["ref"]) for e in trackers.load(path, kind)]
    assert found == []
