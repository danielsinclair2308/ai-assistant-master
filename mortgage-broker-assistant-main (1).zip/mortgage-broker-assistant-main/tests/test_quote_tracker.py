import datetime as dt

import quote_tracker as qt

TODAY = dt.date(2026, 9, 24)
LINES = (
    "- [ ] 2026-09-20 | quote | C-1 | lender:Alpha | asked:2026-09-20 | replied:- | deadline:2026-09-26\n"
    "- [ ] 2026-09-20 | quote | C-1 | lender:Beta | asked:2026-09-20 | replied:- | deadline:2026-09-26\n"
    "- [x] 2026-09-20 | quote | C-1 | lender:Gamma | asked:2026-09-20 | replied:- | deadline:2026-09-26\n"
    "- [ ] 2026-09-22 | quote | C-1 | lender:Gamma | asked:2026-09-20 | replied:2026-09-22 | deadline:2026-09-26 | note:terms-received\n"
    "- [ ] 2026-09-21 | quote | C-2 | lender:Alpha | asked:2026-09-21 | replied:2026-09-23 | deadline:-\n"
)


def root(tmp_path, text=LINES):
    (tmp_path / "state").mkdir()
    (tmp_path / "state/lender-quotes.md").write_text(text, encoding="utf-8")
    return tmp_path


def test_waiting_case_lists_outstanding(tmp_path):
    out = qt.summary(root(tmp_path), TODAY, "C-1")
    assert out == [
        "C-1  WAITING  1 of 3 replied, deadline 2026-09-26",
        "  replied: Gamma",
        "  outstanding: Alpha (4 days), Beta (4 days)",
    ]


def test_all_replied_is_ready(tmp_path):
    out = qt.summary(root(tmp_path), TODAY, "C-2")
    assert out[0] == "C-2  READY  1 of 1 replied, no deadline"


def test_deadline_passed_is_ready_with_outstanding(tmp_path):
    out = qt.summary(root(tmp_path), dt.date(2026, 9, 27), "C-1")
    assert out[0] == "C-1  READY (deadline passed)  1 of 3 replied, deadline 2026-09-26"


def test_all_cases_when_no_filter(tmp_path):
    out = qt.summary(root(tmp_path), TODAY, None)
    assert [l for l in out if not l.startswith("  ")] == [
        "C-1  WAITING  1 of 3 replied, deadline 2026-09-26",
        "C-2  READY  1 of 1 replied, no deadline",
    ]


def test_closed_latest_lines_excluded(tmp_path):
    text = "- [x] 2026-09-21 | quote | C-9 | lender:Alpha | asked:2026-09-21 | replied:- | deadline:-\n"
    assert qt.summary(root(tmp_path, text), TODAY, None) == []
