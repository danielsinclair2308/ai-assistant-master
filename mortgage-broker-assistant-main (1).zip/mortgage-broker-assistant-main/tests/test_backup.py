import backup


def test_document_like_flags_client_documents():
    paths = ["state/cases.md", "passport.pdf", "state/x.JPG", "knowledge/templates/invoice.docx",
             "notes/offer.docx", "knowledge/templates/logo.png"]
    assert backup.document_like(paths) == ["passport.pdf", "state/x.JPG", "notes/offer.docx"]
