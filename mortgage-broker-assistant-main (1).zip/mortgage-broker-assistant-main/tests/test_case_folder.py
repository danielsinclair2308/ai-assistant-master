import pytest

import case_folder as cf


def test_folder_name_strips_unsafe_characters():
    assert cf.folder_name('Smith/Jones: "A"', "C-1") == "Smith Jones A (C-1)"


def test_creates_structure(tmp_path):
    root, repo = tmp_path / "clients", tmp_path / "repo"
    root.mkdir(); repo.mkdir()
    folder, created = cf.ensure_case_folder(root, "C-1", "Smith, Jane", repo)
    assert folder == root / "Smith, Jane (C-1)"
    assert created == list(cf.SUBFOLDERS)
    assert all((folder / s).is_dir() for s in cf.SUBFOLDERS)


def test_idempotent(tmp_path):
    root, repo = tmp_path / "clients", tmp_path / "repo"
    root.mkdir(); repo.mkdir()
    cf.ensure_case_folder(root, "C-1", "Smith, Jane", repo)
    _, created = cf.ensure_case_folder(root, "C-1", "Smith, Jane", repo)
    assert created == []


def test_refuses_missing_root(tmp_path):
    with pytest.raises(ValueError, match="does not exist"):
        cf.ensure_case_folder(tmp_path / "nope", "C-1", "A", tmp_path)


def test_refuses_root_inside_repo(tmp_path):
    inside = tmp_path / "clients"
    inside.mkdir()
    with pytest.raises(ValueError, match="inside the assistant folder"):
        cf.ensure_case_folder(inside, "C-1", "A", tmp_path)


def test_refuses_ref_reused_with_other_name(tmp_path):
    root, repo = tmp_path / "clients", tmp_path / "repo"
    root.mkdir(); repo.mkdir()
    cf.ensure_case_folder(root, "C-1", "Smith, Jane", repo)
    with pytest.raises(ValueError, match="already used"):
        cf.ensure_case_folder(root, "C-1", "Brown, Tom", repo)


def test_refuses_invalid_ref_with_double_dots(tmp_path):
    root, repo = tmp_path / "clients", tmp_path / "repo"
    root.mkdir(); repo.mkdir()
    with pytest.raises(ValueError, match="case reference"):
        cf.ensure_case_folder(root, "../escaped", "Smith, Jane", repo)


def test_refuses_invalid_ref_with_slash(tmp_path):
    root, repo = tmp_path / "clients", tmp_path / "repo"
    root.mkdir(); repo.mkdir()
    with pytest.raises(ValueError, match="case reference"):
        cf.ensure_case_folder(root, "C/1", "Smith, Jane", repo)


def test_refuses_ref_reused_case_insensitive(tmp_path):
    root, repo = tmp_path / "clients", tmp_path / "repo"
    root.mkdir(); repo.mkdir()
    cf.ensure_case_folder(root, "C-1", "Smith, Jane", repo)
    with pytest.raises(ValueError, match="already used"):
        cf.ensure_case_folder(root, "c-1", "Brown, Tom", repo)


def test_refuses_empty_sanitised_name(tmp_path):
    root, repo = tmp_path / "clients", tmp_path / "repo"
    root.mkdir(); repo.mkdir()
    with pytest.raises(ValueError, match="no usable characters"):
        cf.ensure_case_folder(root, "C-1", "///", repo)
