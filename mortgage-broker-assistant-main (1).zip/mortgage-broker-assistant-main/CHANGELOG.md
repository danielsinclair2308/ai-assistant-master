# Changelog

## 0.1.0 (2026-09-24)

First version of the mortgage broker template, built from the property assistant template
3.0.0.

- Root documents rewritten for a UK mortgage and finance broker: `CLAUDE.md`,
  `AUTONOMY.md`, `DATA-HANDLING.md`, `EFFICIENCY.md`, `SCHEDULE.md`, `START-HERE.md`,
  `README.md`, `PACKAGE.md`.
- `COMPLIANCE.md` added: Consumer Duty, record keeping, the advice boundary, financial
  promotions, credit data and marketing consent, as a working policy rather than legal
  advice.
- `knowledge/capabilities.md` added, listing what a skill can need without naming a
  product.
- Four autonomy tiers kept, mapped to the process and core skills this template will
  carry: submitting an application, declaring adverse credit, any regulated
  recommendation, spending money, refunds or fee waivers, anything contractual, and
  credentials are all tier 4.
- Data handling rewritten for a broker: client folders and the case system are the only
  homes for personal data, never `state/` or `data/`.
- Schedule kept as five batched daily runs, plus weekly, monthly and quarterly jobs, with
  the sequence itself left for onboarding to complete.
- 31 skills under `.claude/skills/`, covering the process, core and adapter groups, each
  with the required frontmatter and routed through `CLAUDE.md` and the onboarding
  walkthrough.
- Five case-type packs added under `.claude/packs/` (bridging, btl, commercial,
  development, residential), each a `PACK.md` describing its extra fields and documents.
- Twelve scripts under `scripts/`: `backup.py`, `case_folder.py`, `chase_due.py`,
  `expiry_scan.py`, `guard.py`, `index-knowledge.py`, `invoice.py`, `lint_template.py`,
  `make_invoice_template.py`, `quote_tracker.py`, `rollup.py` and `trackers.py`.
- Tracker and state templates added under `state/` for every file the skills and rollup
  write to, so a fresh install starts from a template rather than a blank file.
- Contract tests added (`tests/test_contract.py`) checking the template's promises hold
  across files: the lint stays clean, every process skill appears in the onboarding
  walkthrough and in `CLAUDE.md`'s router, every state file onboarding writes has a
  template, every tracker rollup reads from has a template, every capability a skill
  uses is documented, and no client documents are tracked in git.
