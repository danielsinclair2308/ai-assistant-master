# Open items

Things that need a human. Cleared by {{OPERATOR_NAME}}, carried into the weekly report
until they are.

Add items here rather than guessing. An unresolved question in this file is a good
outcome. A guessed answer in a statement is not.

**Case reference only. Values only for non-personal status, stage and date fields; never a
name, amount, fee, rate, address or contact detail.** This file is append only and
archived, never edited, so anything written here stays for good. See `DATA-HANDLING.md`.

Format:

- [ ] YYYY-MM-DD | job-name | what is unclear and what you need in order to proceed

---

## Known gaps at setup

## The window

Every open item stays here however old it is. Items closed more than 30 days ago move to
`state/archive/open-items-YYYY-MM.md`. `scripts/rollup.py` does the moving, monthly.

An old open item is not clutter, it is something nobody has dealt with, and it belongs in
front of a person until it is.
