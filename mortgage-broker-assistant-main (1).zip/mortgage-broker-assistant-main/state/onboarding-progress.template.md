# Onboarding progress

Status: NOT STARTED

The assistant updates this as it goes. It is what lets a setup conversation be
interrupted and picked up later without starting again.

| Phase | Status | Date |
|---|---|---|
| 1. Hello | not started | |
| 2. The business: role, firm, fees, product mix, packs enabled | not started | |
| 3. A normal week: tools listed | not started | |
| 4. Process walk-through | not started | |
| 5. Connections driven by the wanted processes | not started | |
| 6. Case system mapped | not started | |
| 7. Knowledge captured | not started | |
| 8. Schedule written and agreed | not started | |
| 9. Close: baseline, ledger, backup, summary given | not started | |

## Still outstanding

The assistant lists here anything asked but not answered, so it can be picked up in the
weekly report rather than by nagging.

## Notes from the conversation

Anything useful said in passing that does not belong in a knowledge file yet.
