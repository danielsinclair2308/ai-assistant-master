# Outcomes

Written by the attribution job. What actually happened after each decision.

Append only. Never revise an outcome because a later one looked better.

Format:

```
## D-YYYYMMDD-nn | checked YYYY-MM-DD

- Expected: (copied from the decision)
- Actual: what happened, with the figure
- Verdict: WORKED, DID NOT WORK, NO EFFECT, or CANNOT TELL
- Holdout comparison: what the comparable case did over the same period, if there was one
- Note: anything that makes the result unreliable
```

## The rules

**CANNOT TELL is a real answer and often the right one.** Use it whenever something else
plausibly caused the result. A chaser that got a reply the next day might have got one
anyway. Say so. A file full of confident WORKED verdicts is not evidence, it is marking
your own homework.

**Never bin a bad outcome.** DID NOT WORK entries are the most valuable thing in this
file, because they are what stops the same mistake being repeated and what makes the good
results believable when they are reported.

**Count the misses in the weekly report.** If the chasing job is right 60% of the time,
say 60%. {{OPERATOR_NAME}} can work with that. They cannot work with a number that is
quietly flattering.

---

## The window

Last 30 days here. Older verdicts move to `state/archive/outcomes-YYYY-MM.md`, each with
a summary at the top giving the hit rate for that month. `scripts/rollup.py` does the
moving, monthly. Nothing is deleted, and no verdict is ever revised on the way past.
