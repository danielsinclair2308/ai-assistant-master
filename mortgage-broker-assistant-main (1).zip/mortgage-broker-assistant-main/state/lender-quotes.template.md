# Lender quotes

Fan-out tracker: which lenders have been asked on a case, and who has come back. Case
reference only, never a client name or financial detail: see `DATA-HANDLING.md`.

Append only. To update an entry, tick the old line `[x]` and append a new one. The last
line for a case and lender wins. A value of `-` means empty.

Format, one entry per line:

```
- [ ] YYYY-MM-DD | quote | CASE-REF | lender:NAME | asked:YYYY-MM-DD | replied:YYYY-MM-DD or - | deadline:YYYY-MM-DD or - | note:<label>
```

`note:` is one short non-numeric label only: `no-reply`, `terms-received`, `declined` or
`more-info-needed`. Never a rate, fee, amount or any other figure, and never client
detail: live figures are never stored (`CLAUDE.md`). The terms themselves stay in the
lender's email, and the adviser is pointed to those emails when the case is ready.

Example (indented here so it is never read as a real entry):

```
  - [ ] 2026-09-24 | quote | C-1042 | lender:Example Bank | asked:2026-09-24 | replied:- | deadline:2026-10-01 | note:no-reply
```

## The window

Every open line stays here however old it is. Closed lines from more than 30 days ago
move to `state/archive/lender-quotes-YYYY-MM.md`. `scripts/rollup.py` does the moving,
monthly.
