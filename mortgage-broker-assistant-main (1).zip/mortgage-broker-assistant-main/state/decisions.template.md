# Decisions

Append only. Every decision that had a choice in it, written so it can be checked later.

**Every entry needs an ID and a review date.** Without them the attribution job cannot find
the decision again, and a decision nobody checks is just an opinion that got typed.

**Case reference only. Values only for non-personal status, stage and date fields; never a
name, amount, fee, rate, address or contact detail.** This file is append only and
archived, never edited, so anything written here stays for good. See `DATA-HANDLING.md`.

Format:

```
## D-YYYYMMDD-nn | job-name | APPLIED or PROPOSED or DECLINED

- What: the action taken, specifically. Case reference, dates, field names changed; values only if non-personal status/stage/date
- Why: the rule or comparison that drove it
- Source: which system or document, not the figures
- Expected: what should happen if this was the right call, in measurable terms
- Check on: YYYY-MM-DD
- Holdout: yes or no, and which comparable case was left alone
```

The **Expected** line is the one that matters. "The client will send the payslips within
three days" is checkable. "Improve the response rate" is not. If you cannot write a
checkable expectation, you do not understand the decision well enough to make it.

For decisions with no measurable outcome, write `Expected: none, judgement call` and
`Check on: none`. Be honest about which ones those are.

---

## The window

This file holds every **open** decision, however old, plus closed ones from the last
30 days. A decision is closed once `outcomes.md` carries a verdict for it, or it was
declined, or it was logged with `Check on: none`.

Older closed decisions live in `state/archive/decisions-YYYY-MM.md`, each with a summary
at the top. `scripts/rollup.py` does the moving, monthly. Nothing is ever deleted.

**An open decision is never archived, whatever its age.** Attribution has to be able to
find it on its check date, and a decision that got archived before anyone checked it is
the exact failure this file exists to prevent.
