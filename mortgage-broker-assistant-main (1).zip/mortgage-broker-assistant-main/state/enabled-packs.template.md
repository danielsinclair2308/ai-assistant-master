# Enabled packs

Status: NONE (onboarding not finished)

Onboarding rewrites this file when the product mix interview is done. Until then, load
**core skills only**. Do not load any folder under `.claude/packs/`.

| Pack id | Enabled | Notes |
|---|---|---|
| residential | no | |
| btl | no | |
| bridging | no | |
| commercial | no | |
| development | no | |

Primary contact role: `[[FILL: adviser / case administrator]]`

Product mix recorded in `knowledge/business.md`: `[[FILL]]`
