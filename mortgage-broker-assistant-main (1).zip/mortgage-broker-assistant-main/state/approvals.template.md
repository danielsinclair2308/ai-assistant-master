# Approvals

Pending approvals and their age. Reference only, never a client name or contact detail:
see `DATA-HANDLING.md`. Asking is always free, tier 1: see `AUTONOMY.md`.

Append only. To update an entry, tick the old line `[x]` and append a new one. The last
line for a reference wins. A value of `-` means empty.

Format, one entry per line:

```
- [ ] DATE | approval | <ref> | job:<skill> | asked:<who> | via:email|whatsapp | chased:- | answer:-
```

Example (indented here so it is never read as a real entry):

```
  - [ ] 2026-09-24 | approval | C-1042 | job:invoicing | asked:{{OWNER_NAME}} | via:whatsapp | chased:- | answer:-
```

## The window

Every open line stays here however old it is. Closed lines from more than 30 days ago
move to `state/archive/approvals-YYYY-MM.md`. `scripts/rollup.py` does the moving,
monthly.
