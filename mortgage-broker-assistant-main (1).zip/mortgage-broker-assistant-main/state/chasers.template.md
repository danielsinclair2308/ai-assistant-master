# Chasers

Active chase sequences and their stop conditions. Case reference only, never a client
name, address or contact detail: see `DATA-HANDLING.md`.

Append only. To update an entry, tick the old line `[x]` and append a new one. The last
line for a case and job wins. A value of `-` means empty.

Format, one entry per line:

```
- [ ] YYYY-MM-DD | chaser | CASE-REF | job:<skill> | to:client|lender | every:<days> | last:YYYY-MM-DD | stop:<condition>
```

`stop:` is one of `paid`, `received`, `accepted`, `replied`, `adviser`.

Example (indented here so it is never read as a real entry):

```
  - [ ] 2026-09-24 | chaser | C-1042 | job:client-documents | to:client | every:3 | last:2026-09-24 | stop:received
```

## The window

Every open line stays here however old it is. Closed lines from more than 30 days ago
move to `state/archive/chasers-YYYY-MM.md`. `scripts/rollup.py` does the moving, monthly.
