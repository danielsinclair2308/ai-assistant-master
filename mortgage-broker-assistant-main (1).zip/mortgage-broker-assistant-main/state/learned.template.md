# Learned

What the assistant has worked out for itself, as opposed to what it was told.

**This is not `knowledge/`.** Everything here is an inference and carries less weight than
anything a human wrote. It informs decisions. It never overrides a rule.

Something moves out of this file and into `knowledge/` only when a human confirms it, and
they write it, not the assistant.

Append only.

---

## Format

```
## L-YYYYMMDD-nn | topic

- Noticed: what the data shows
- Evidence: how many observations, over what period
- Confidence: low, medium or high, and why
- Would change: what decision this affects if true
- Status: OBSERVED / ASKED / CONFIRMED / CONTRADICTED / UNANSWERED
- Asked on: date, if it was put to a human
- Outcome: what they said
```

## Rules

**Label small samples as small samples.** Four cases out of five is a hint. Say so.
Presenting it as a pattern and being wrong costs credibility that is needed later for the
things that are real.

**Record contradictions.** Being told you were wrong is a stronger signal than being told
you were right, and should move confidence further.

**Unanswered is a real status.** A question that was ignored is not a question that was
agreed with. It waits a quarter, then may be raised once more.

**Never re-propose a declined idea in a different shape.** Logged as contradicted, with the
reason, and left alone.

---

## The window

Last 90 days here, plus anything marked `Permanent: yes`, plus anything still waiting on
a human, meaning any entry whose status is ASKED or UNANSWERED. Something a person has
not answered yet is not old, it is outstanding.

Everything else moves to `state/archive/learned-YYYY-Qn.md`, each with a summary at the
top. `scripts/rollup.py` does the moving, monthly.

Add `- Permanent: yes` to an entry that should never age out.
