# Processes

One line per skill, recording whether {{OWNER_NAME}} or {{OPERATOR_NAME}} actually wants
it running, how it is triggered, and who approved it. Append only, the same as every
other tracker here: to update an entry, tick the old line `[x]` and append a new one.
The last line for a given skill wins. A value of `-` means empty.

Format, one entry per line:

```
- [ ] DATE | process | <skill> | want:yes|no | mode:sequence|trigger|both | approver:<name> | slot:<run or event> | status:active|dormant | missing:<capability or -> [| every:<days>] [| overdue-days:<n>] [| lead-days:<n>] [| deadline-days:<n>] [| max-age-days:<n>] [| daily-limit:<n>] [| batch-size:<n>] [| stale-hours:<n>]
```

The bracketed keys are optional settings, written only when {{OWNER_NAME}} or
{{OPERATOR_NAME}} has stated them. Onboarding does not ask for them; they may be recorded
whenever someone states one. Each skill reads its setting from its own latest line here,
and when the key is absent it uses its stated default and mentions it in each weekly
report while the key is absent:

| Key | Meaning | Used by | Default when absent |
|---|---|---|---|
| `every:<days>` | Days between chasers | `client-documents`, `esis-pack`, `lender-requirements`, `invoicing` | 3 |
| `overdue-days:<n>` | Days a case may wait on someone before it is overdue | `case-tracking` | 2 |
| `lead-days:<n>` | Days before a product or ERC end date that a client is due a review | `remortgage-watch` | 180 |
| `deadline-days:<n>` | Working days lenders get to reply with terms, when the adviser gives no deadline | `lender-quotes` | 3 |
| `max-age-days:<n>` | Oldest post, in days, worth drafting a reply to | `social-engagement` | 7 |
| `daily-limit:<n>` | Most replies drafted in a day. More than ten at once still needs a yes first (`AUTONOMY.md`) | `social-engagement` | 10 |
| `batch-size:<n>` | Most campaign emails sent in one batch. Above ten only with {{OWNER_NAME}}'s yes in the campaign approval | `email-marketing` | 10 |
| `stale-hours:<n>` | Hours after which a WhatsApp command picked up late is confirmed again before acting | `whatsapp-command` | 3 |

Example (indented here so it is never read as a real entry):

```
  - [ ] 2026-09-24 | process | client-documents | want:yes | mode:trigger | approver:{{OWNER_NAME}} | slot:document received | status:active | missing:-
```

## The window

Every open line stays here however old it is. Closed lines from more than 30 days ago
move to `state/archive/processes-YYYY-MM.md`. `scripts/rollup.py` does the moving,
monthly.
