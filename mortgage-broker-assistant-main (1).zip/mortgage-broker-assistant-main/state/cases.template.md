# Cases

Only for the tracker fields below (waiting on, date requested, chase date, stage,
submission date, valuation date, case status, lead source, and outstanding actions as a
short label) when the case system cannot hold them. Personal or financial fields, such as
client name, property address, loan amount, proc fee or broker fee, the case system
cannot hold stay in the client folder, never here. If the case system holds them all, this
stays empty. Case reference only, never a client name, address, income or account
detail: see `DATA-HANDLING.md`.

Append only. To update an entry, tick the old line `[x]` and append a new one. The last
line for a case wins. A value of `-` means empty.

Format, one entry per line:

```
- [ ] YYYY-MM-DD | case | CASE-REF | waiting:client|lender|adviser|other | requested:YYYY-MM-DD | chase:YYYY-MM-DD | stage:pre-offer|pre-completion | submitted:YYYY-MM-DD | valuation:YYYY-MM-DD | status:<short status word> | source:<lead source label> | outstanding:<short action label>
```

`submitted` is the submission date, `valuation` is the valuation date, `status` is a short
non-personal status word such as `valuation-instructed` or `offer-issued`, and `source` is
a lead source label such as `website-bridging`, `instagram` or `referral`. `outstanding`
is a short non-personal action label such as `docs-outstanding` or `awaiting-valuation`,
never free text: an outstanding action written as a sentence could carry a client's name
or detail, and never belongs here. All of these are optional; write only the ones the
case system cannot hold.

Example (indented here so it is never read as a real entry):

```
  - [ ] 2026-09-24 | case | C-1042 | waiting:lender | requested:2026-09-20 | chase:2026-09-27 | stage:pre-offer | submitted:2026-09-10 | valuation:2026-09-18 | status:valuation-instructed | source:website-bridging | outstanding:awaiting-valuation
```

## The window

Every open line stays here however old it is. Closed lines from more than 30 days ago
move to `state/archive/cases-YYYY-MM.md`. `scripts/rollup.py` does the moving, monthly.
