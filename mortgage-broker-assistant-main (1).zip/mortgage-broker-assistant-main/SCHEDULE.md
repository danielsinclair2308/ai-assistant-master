# The week

Five runs a day at most, not twenty four. Each run wakes once, loads only the tools it
needs, and does several jobs in the same session. This is what keeps it affordable. The
reasoning is in `EFFICIENCY.md`.

{{OWNER_NAME}} changes anything here by editing this file, or by re-running onboarding.

Until onboarding finishes, do not invent a timetable. Run nothing outward-facing.

---

## Every day

### 07:00, Morning run
**Connections:** `[[FILL: connections placed here by onboarding]]`
**Jobs (fixed):** `scripts/chase_due.py`, `scripts/quote_tracker.py`

Where `case-tracking` is active, it runs `scripts/chase_due.py` with the live cases CSV
(`--cases-input`, see `case-system`) as its own step, and that output is the one used for
OVERDUE and CHASE DATE. Without it, the fixed run reads `state/` only and says when case
dates were not checked.

`[[FILL: sequence processes placed here by onboarding]]`

If nothing changed anywhere, log one line and stop.

### 11:00, Inbox run
**Connections:** `[[FILL: connections placed here by onboarding]]`

`[[FILL: sequence processes placed here by onboarding]]`

### 15:00, Inbox run
**Connections:** `[[FILL: connections placed here by onboarding]]`

`[[FILL: sequence processes placed here by onboarding]]`

Two inbox runs a day, not thirteen.

### 18:00, Evening run
**Connections:** `[[FILL: connections placed here by onboarding]]`

`[[FILL: sequence processes placed here by onboarding]]`

### 23:00, Nightly run
**Connections:** `[[FILL: connections placed here by onboarding]]`
**Jobs (fixed):** metrics snapshot, `scripts/guard.py`, verify, then last of all, `scripts/backup.py`

`[[FILL: sequence processes placed here by onboarding]]`

`scripts/backup.py` is the only job here that acts without asking. If the push fails it
says so and writes an open item.

---

## Every week

### Monday 07:00, Weekly run
**Connections:** `[[FILL: connections placed here by onboarding]]`
**Jobs (fixed):** attribution, learning, connections check, weekly report

`[[FILL: sequence processes placed here by onboarding]]`

Attribution first. Learning's question goes at the bottom of the report, if any.

---

## Every month, on the 1st

### Monthly run
**Connections:** `[[FILL: connections placed here by onboarding]]`
**Jobs (fixed):** `scripts/rollup.py`, first

`[[FILL: sequence processes placed here by onboarding]]`

Never send money documents without a yes.

---

## Every quarter

**The knowledge review.** Ask whether fees, the lender panel, compliance lists and
connected tools still hold.

**The proof pack.** Attribution against `data/baseline.md`.

---

## Trigger processes

Processes that fire on an event rather than a time of day.

`[[FILL: listed by onboarding with the event that fires each]]`

---

## Dormant

Processes not currently run for this business, kept in the repo in case they are switched
on later.

`[[FILL: listed by onboarding]]`

---

## Three rules about the schedule

**Silence is a valid output.** A run with nothing worth doing should log one line and stop.

**Adding a job means adding it to an existing run.** A sixth daily run needs a reason and
{{OWNER_NAME}}'s agreement.

**The monthly rollup is not optional.** See `EFFICIENCY.md`.
