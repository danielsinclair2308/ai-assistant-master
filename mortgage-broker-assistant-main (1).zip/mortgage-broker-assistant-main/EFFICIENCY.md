# Running cheaply

Every session starts with a fresh context window and reloads the tools it needs before it
does anything. That cost is paid per session, whether the job finds work to do or not. So
two things decide what this costs to run: **how many sessions there are**, and **how much
raw data gets read into them**.

Both are controlled here. Read this before adding anything to the schedule.

---

## Rule 1: batch jobs into shared sessions

Do not give every job its own session. A session that wakes up, loads eight sets of tools
and finds nothing to do has cost the same as one that did real work.

Jobs are grouped into five runs a day. Each run loads its tools once and does several jobs
in the same context. See `SCHEDULE.md`.

Adding a new job means adding it to an existing run. Adding a sixth run needs a reason.

## Rule 2: only load the tools the run needs

The morning run does not need the marketing platform. The evening run does not need the
lender portals. Each run in `SCHEDULE.md` lists its connections. Do not reach for one
that is not on the list. If a run genuinely needs something not listed, say so and it gets
added deliberately.

## Rule 3: write a script once, then run it

**This is the big one.**

Never read raw data into context to work something out. A mailbox of lender emails, or
four hundred cases scanned for a product expiring in ninety days, is tens of thousands of
tokens, and it is the same cost every single morning for the sake of a handful of
conclusions.

Instead:

1. The first time a job needs data, **write a script** that fetches it, does the
   calculation, and prints a short summary.
2. Save it in `scripts/`.
3. Every run after that, **run the script and read the summary.** Not the data.

A script that returns "6 cases due for a product review in 30 days" with the case
references is a hundred tokens. Reading the raw case system yourself to reach the same
conclusion is tens of thousands.

The rule in one line: **the model decides, the script fetches and counts.**

This is the same discipline as never doing arithmetic in your head, and for the same
reason. Code is cheaper, faster and more reliable at both.

## Rule 4: summarise at source

When a script cannot do the whole job, still narrow before reading. Ask the tool for
cases updated in the last day rather than the whole book, and only widen if something
needs it. Filter to unread rather than pulling the whole inbox. Request the fields you
need, not every field.

## Rule 5: silence is free

If a run finds nothing worth doing, it should stop, log one line, and say nothing. Do not
generate a summary of having found nothing. Do not email anyone. The weekly report is
where things get said.

## Rule 6: window what grows, and archive the rest

**This is the one that decides whether this still works in three years.**

Several files here are append only and grow every day: `state/decisions.md`,
`state/outcomes.md`, `state/runs.log`, `state/cases.md`, `state/chasers.md`,
`state/lender-quotes.md`, `state/approvals.md`, `state/processes.md` and
`data/metrics.csv`. Nothing about them is wrong. The problem is what happens at eighteen
months on a book of several hundred cases: long before that they stop fitting in a
session, and the failure is not a crash. The assistant simply stops being able to read its
own decision history, gives slightly worse answers, and nobody notices because there is no
error. It works, and then it does not.

So every one of those files keeps a **window** and archives the rest:

| File | Kept in the working file | Archived to |
|---|---|---|
| `state/decisions.md` | every open decision, whatever its age, plus 30 days of closed ones | `state/archive/decisions-YYYY-MM.md` |
| `state/outcomes.md` | 30 days | `state/archive/outcomes-YYYY-MM.md` |
| `state/learned.md` | 90 days, plus permanent, plus anything awaiting an answer | `state/archive/learned-YYYY-Qn.md` |
| `state/open-items.md` | every open item, plus 30 days of closed ones | `state/archive/open-items-YYYY-MM.md` |
| `state/runs.log` | 7 days | `state/archive/runs-YYYY-MM.log` |
| `state/cases.md`, `chasers.md`, `lender-quotes.md`, `approvals.md`, `processes.md` | open lines forever, closed lines 30 days | `state/archive/` per file, monthly |
| `data/metrics.csv` | 90 nightly rows | `data/archive/metrics-YYYY.csv` in full, and `data/metrics-monthly.csv` aggregated |

**Three things about this design are deliberate and should not be undone.**

**Windows are by status, not only by age.** A decision made in March with a check date in
June is not archived in April just because it is old. It stays until it has a verdict. The
whole point of writing a decision down is that somebody checks it later, and a window that
archived it first would have quietly reintroduced the failure this is here to prevent.
Same for an open item, an active chaser, a pending approval, and a learning nobody has
answered yet.

**Nothing is deleted, only relocated.** `state/` is still append only in the sense that
matters: an entry is never edited and never thrown away. `scripts/rollup.py` moves it, and
only it moves it. Every archive carries a summary at the top with the counts and the
patterns, so a question about last year is four summaries rather than four whole files.

**The rollup is a script.** Moving thousands of rows by reading them into a conversation
would cost more than the problem it solves, which would make this rule contradict rule 3.
The script moves the bytes and prints the counts.

The cost of getting this wrong is not gradual. `scripts/guard.py` runs nightly and writes
an open item when a working file passes 40KB, so the drift is visible before it matters.

## Rule 7: watch the cost

The nightly run records the day's session count and any run that failed or was skipped.
If the daily count creeps above what `SCHEDULE.md` expects, something is retrying in a
loop and it needs looking at.

---

## What this is worth

Twenty four separate sessions a day, each reading raw data, is somewhere over a million
tokens daily and will not survive a normal subscription.

Five batched runs a day reading script output is roughly a tenth of that, on a book this
size. Same jobs, same outcomes.

If a change would move things back towards the first number, it is the wrong change.
