# Package

| | |
|---|---|
| **Licence ID** | [[FILL: set by issuer]] |
| **Client ID** | [[FILL: set by issuer]] |
| **Package ID** | [[FILL: set by issuer]] |
| **Version** | 0.1.0 |
| **Issued** | [[FILL: set by issuer]] |
| **Business** | {{BUSINESS_NAME}} |

---

Proprietary. All rights reserved.

Use is permitted only under a current Agency Partner Licence. This package
contains identifiers used to establish provenance.
