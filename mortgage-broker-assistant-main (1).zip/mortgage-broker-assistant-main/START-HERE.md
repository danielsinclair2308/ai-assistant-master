# Start here

You do not need to read any of these files or fill anything in.

1. Open the Claude app and go to **Code**.
2. Click **New**, then **Open folder**, and choose **this folder**: the one with
   `START-HERE.md` in it. Not the folder around it, and not a new empty one.
3. Say hello.

It will introduce itself, find out what you open in a normal week, and only then
specialise. It writes everything down itself as you go.

If it answers hello with a general offer to help instead of introducing itself, the wrong
folder is open. Go back to step 2. Unzipping on Windows often puts the folder inside
another folder of the same name, so check that you are one level in.

It takes a short conversation, one question at a time. You can stop halfway and pick it
up later.

---

## Before you start, it helps to have

- Logins for the tools you actually use: email, the case system, WhatsApp Business, the
  business bank account (read-only is enough), and any socials you post from, in one
  place. This is the only genuinely fiddly bit.
- Your fee agreement and a recent invoice.
- Two or three emails you have actually sent to clients, so it can learn to write like you.
- The client folder location: where cases, documents and correspondence already live.

If you have not got those to hand, start anyway. It will work around gaps and come back.

---

## Who should do it

Whoever runs the case load day to day, ideally. The adviser is welcome to sit in. The
assistant will ask which hat you are wearing.

---

## What happens afterwards

It records which product packs to use, connects what it can, and starts the jobs that
match your business. Client and lender messages stay on drafts or ask-first until
{{OWNER_NAME}} decides otherwise, by name, for a specific job. Monday brings a short
report that will be thin at first and better each week.

Some of it will be wrong to begin with. Tell it when it is. That is what the first
fortnight is for.

---

## If you would rather fill things in by hand

You can. Everything lives in the `knowledge` folder as plain text and anything still
needed is marked with `[[FILL: ...]]`. Talking to it is faster, and usually more accurate,
because it asks better questions than a blank box does.
